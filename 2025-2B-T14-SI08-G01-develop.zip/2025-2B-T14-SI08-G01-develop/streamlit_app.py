import os
import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# Load .env
load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    st.error("DATABASE_URL não encontrada no .env")
    st.stop()

# SQLAlchemy engine
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

st.set_page_config(page_title="PoC: Expenses Insight by Cost Center", layout="wide")
st.title("PoC: Expenses Insight by Cost Center")
st.caption("MVP - SKZ Oberle | Gold Layer (Neon/Postgres)")

@st.cache_data(ttl=300)
def load_data():
    query = text(
        """
        SELECT desc_ccusto, desc_conta, valor_total, created_at
        FROM gold_expenses_insights
        ORDER BY valor_total DESC
        """
    )
    with engine.connect() as conn:
        df = pd.read_sql(query, conn)
    return df

try:
    df = load_data()
except Exception as e:
    st.error(f"Falha ao carregar dados: {e}")
    st.stop()

# Sidebar filters
st.sidebar.header("Filters")
cc_options = sorted(df["desc_ccusto"].dropna().unique().tolist())
selected_cc = st.sidebar.multiselect("Cost Centers", cc_options, default=cc_options[:5])

if selected_cc:
    df_filtered = df[df["desc_ccusto"].isin(selected_cc)].copy()
else:
    df_filtered = df.copy()

# KPIs
col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Total registros", f"{len(df_filtered):,}")
with col2:
    st.metric("Cost centers", f"{df_filtered['desc_ccusto'].nunique():,}")
with col3:
    st.metric("Account types", f"{df_filtered['desc_conta'].nunique():,}")

st.subheader("Top expenses - table")
st.dataframe(df_filtered, use_container_width=True)

st.subheader("Bar chart - sum by cost center")
df_cc = df_filtered.groupby("desc_ccusto", as_index=False)["valor_total"].sum().sort_values("valor_total", ascending=False)
st.bar_chart(df_cc.set_index("desc_ccusto"))

st.subheader("Bar chart - sum by account")
df_conta = df_filtered.groupby("desc_conta", as_index=False)["valor_total"].sum().sort_values("valor_total", ascending=False).head(20)
st.bar_chart(df_conta.set_index("desc_conta"))

st.subheader("Pie - top 10 cost centers")
try:
    import plotly.express as px
    pie_df = df_cc.head(10)
    fig = px.pie(pie_df, names="desc_ccusto", values="valor_total")
    st.plotly_chart(fig, use_container_width=True)
except Exception:
    st.info("Plotly não disponível; instale com: pip install plotly")

st.caption("Source: Neon/Postgres - gold_expenses_insights")


