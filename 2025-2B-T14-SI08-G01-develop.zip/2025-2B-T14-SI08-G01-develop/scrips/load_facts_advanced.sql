-- Sprint 3 — Carga de Fatos (avançados): estoque, contábil, folha
-- Pré-requisito: dimensões e fatos básicos carregados

USE DELIVERABLE_SPRINT_2;

-- INVENTORY MOVEMENTS (efmvepro)
INSERT INTO G01_fact_inventory_movements
SELECT
  dc.company_sk,
  ddm.document_sk,
  dp.product_sk,
  toInt32(JSONExtractInt(p.datavalue_json,'sequencia')) AS sequencia,
  toInt32(JSONExtractInt(p.datavalue_json,'quantidade')) AS quantidade,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_unitario'),2) AS valor_unitario,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_total'),2) AS valor_total
FROM G01_pipeline_results p
JOIN G01_dim_company dc
  ON dc.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
JOIN G01_dim_product dp
  ON dp.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND dp.codi_pdi = toInt32(JSONExtractInt(p.datavalue_json,'codi_pdi'))
JOIN G01_dim_document ddm
  ON ddm.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND ddm.doc_type = JSONExtractString(p.datavalue_json,'tipo_documento')
 AND ddm.doc_id = toInt64(JSONExtractInt(p.datavalue_json,'documento'))
WHERE p.data_tag LIKE 'batch%efmvepro_efmvepro%';

-- ACCOUNTING ENTRIES (ctlancto)
INSERT INTO G01_fact_accounting_entries
SELECT
  dc.company_sk,
  dd.date_sk,
  dcc.cost_center_sk,
  da_deb.account_sk AS account_debit_sk,
  da_cre.account_sk AS account_credit_sk,
  coalesce(JSONExtractString(p.datavalue_json,'nume_lan'), '') AS nume_lan,
  JSONExtractString(p.datavalue_json,'origem') AS origem,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor'),2) AS valor
FROM G01_pipeline_results p
JOIN G01_dim_company dc
  ON dc.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
LEFT JOIN G01_dim_cost_center dcc
  ON dcc.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND dcc.i_ccusto = toInt32(JSONExtractInt(p.datavalue_json,'i_ccusto'))
LEFT JOIN G01_dim_account da_deb
  ON da_deb.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND da_deb.conta_contabil = coalesce(JSONExtractString(p.datavalue_json,'conta_debito'),'')
LEFT JOIN G01_dim_account da_cre
  ON da_cre.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND da_cre.conta_contabil = coalesce(JSONExtractString(p.datavalue_json,'conta_credito'),'')
JOIN
(
  SELECT date AS d, date_sk FROM G01_dim_date
) dd
  ON dd.d = toDate(parseDateTimeBestEffortOrNull(JSONExtractString(p.datavalue_json,'data_lan')))
WHERE p.data_tag LIKE 'batch%ctlancto_ctlancto%';

-- PAYROLL (FOMOVTO)
INSERT INTO G01_fact_payroll
SELECT
  dc.company_sk,
  dd.date_sk,
  de.employee_sk,
  dpe.event_sk,
  dcc.cost_center_sk,
  JSONExtractString(p.datavalue_json,'origem') AS origem,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor'),2) AS valor
FROM G01_pipeline_results p
JOIN G01_dim_company dc
  ON dc.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
JOIN G01_dim_employee de
  ON de.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND de.i_empregados = toInt32(JSONExtractInt(p.datavalue_json,'i_empregados'))
LEFT JOIN G01_dim_cost_center dcc
  ON dcc.codi_emp = de.codi_emp
 AND dcc.i_ccusto = de.i_ccusto
JOIN G01_dim_payroll_event dpe
  ON dpe.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND dpe.i_eventos = toInt32(JSONExtractInt(p.datavalue_json,'i_eventos'))
JOIN
(
  SELECT date AS d, date_sk FROM G01_dim_date
) dd
  ON dd.d = toDate(parseDateTimeBestEffortOrNull(JSONExtractString(p.datavalue_json,'data')))
WHERE p.data_tag LIKE 'batch%FOMOVTO_FOMOVTO%';


