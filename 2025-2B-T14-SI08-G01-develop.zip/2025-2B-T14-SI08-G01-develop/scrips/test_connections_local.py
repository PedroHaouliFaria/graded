import os
from dotenv import load_dotenv
from clickhouse_driver import Client
import boto3
from botocore.client import Config

# Carrega as variáveis do arquivo .env para o ambiente
load_dotenv()
print("Arquivo .env carregado.")

# --- 1. Teste de Conexão com ClickHouse ---
print("\n--- Testando Conexão ClickHouse ---")
try:
    CH_HOST = os.environ.get('CLICKHOUSE_HOST')
    CH_PORT = os.environ.get('CLICKHOUSE_PORT')
    CH_USER = os.environ.get('CLICKHOUSE_USER')
    CH_PASS = os.environ.get('CLICKHOUSE_PASSWORD')
    CH_IFACE = os.environ.get('CLICKHOUSE_INTERFACE')

    client = Client(host=CH_HOST,
                    port=CH_PORT,
                    user=CH_USER,
                    password=CH_PASS,
                    interface=CH_IFACE)
    
    databases = client.execute('SHOW DATABASES')
    print(f"[SUCESSO] Conexão com ClickHouse ({CH_HOST}:{CH_PORT}) estabelecida.")
    print("Bancos de dados encontrados:")
    for db in databases:
        print(f"- {db[0]}")

except Exception as e:
    print(f"[FALHA] Não foi possível conectar ao ClickHouse.")
    print(f"Erro: {e}")


# --- 2. Teste de Conexão com MinIO (S3) ---
print("\n--- Testando Conexão MinIO ---")
try:
    MINIO_URL = os.environ.get('MINIO_ENDPOINT_URL')
    MINIO_KEY = os.environ.get('MINIO_ACCESS_KEY')
    MINIO_SECRET = os.environ.get('MINIO_SECRET_KEY')
    # Converte a string 'False' para o booleano False
    MINIO_SSL = (os.environ.get('MINIO_USE_SSL', 'False').lower() == 'true')

    s3_client = boto3.client(
        's3',
        endpoint_url=MINIO_URL,
        aws_access_key_id=MINIO_KEY,
        aws_secret_access_key=MINIO_SECRET,
        use_ssl=MINIO_SSL,
        config=Config(signature_version='s3v4') # Necessário para MinIO
    )

    print(f"Tentando listar 'buckets' no MinIO ({MINIO_URL})...")
    buckets = s3_client.list_buckets()
    
    print(f"[SUCESSO] Conexão com MinIO estabelecida.")
    print("Buckets (Pastas) encontrados:")
    for bucket in buckets['Buckets']:
        print(f"- {bucket['Name']}")
        
except Exception as e:
    print(f"[FALHA] Não foi possível conectar ao MinIO.")
    print(f"Erro: {e}")