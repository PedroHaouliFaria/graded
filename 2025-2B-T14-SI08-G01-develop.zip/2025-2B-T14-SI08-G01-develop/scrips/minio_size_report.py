import os
import sys
from typing import Dict, Tuple, List, Optional

import boto3
from botocore.client import Config
from dotenv import load_dotenv


def human_readable_size(num_bytes: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    size = float(num_bytes)
    unit_idx = 0
    while size >= 1024.0 and unit_idx < len(units) - 1:
        size /= 1024.0
        unit_idx += 1
    return f"{size:,.2f} {units[unit_idx]}"


def list_buckets(endpoint_url: str, access_key: str, secret_key: str) -> List[str]:
    s3 = boto3.client(
        "s3",
        endpoint_url=endpoint_url,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        use_ssl=endpoint_url.startswith("https"),
        config=Config(signature_version="s3v4"),
    )
    resp = s3.list_buckets()
    return [b["Name"] for b in resp.get("Buckets", [])]


def list_all_objects_sizes(
    bucket: str, endpoint_url: str, access_key: str, secret_key: str
) -> Tuple[int, int, Dict[str, int]]:
    """
    Returns:
      total_bytes, total_objects, per_top_prefix_bytes
    """
    s3 = boto3.client(
        "s3",
        endpoint_url=endpoint_url,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        use_ssl=endpoint_url.startswith("https"),
        config=Config(signature_version="s3v4"),
    )

    total_bytes = 0
    total_objects = 0
    per_prefix: Dict[str, int] = {}

    continuation_token = None
    while True:
        params = {"Bucket": bucket, "MaxKeys": 1000}
        if continuation_token:
            params["ContinuationToken"] = continuation_token
        resp = s3.list_objects_v2(**params)

        for obj in resp.get("Contents", []):
            key = obj["Key"]
            size = int(obj.get("Size", 0))
            total_bytes += size
            total_objects += 1

            # aggregate by top-level prefix (e.g., batch_001/)
            top_prefix = key.split("/", 1)[0] if "/" in key else key
            per_prefix[top_prefix] = per_prefix.get(top_prefix, 0) + size

        if resp.get("IsTruncated"):
            continuation_token = resp.get("NextContinuationToken")
        else:
            break

    return total_bytes, total_objects, per_prefix


def main() -> None:
    # Load .env from project root explicitly
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    dotenv_path = os.path.join(project_root, ".env")
    if os.path.isfile(dotenv_path):
        load_dotenv(dotenv_path=dotenv_path)

    endpoint = os.getenv("MINIO_ENDPOINT_URL") or ""
    access_key = os.getenv("MINIO_ACCESS_KEY") or ""
    secret_key = os.getenv("MINIO_SECRET_KEY") or ""
    # bucket can be overridden by CLI arg: python minio_size_report.py ALL|<bucket_name>
    bucket_arg: Optional[str] = sys.argv[1] if len(sys.argv) > 1 else None
    bucket_env = os.getenv("MINIO_BUCKET_NAME")
    bucket = bucket_arg or bucket_env or ""

    if not endpoint or not access_key or not secret_key:
        print(
            "Faltam variáveis no .env: MINIO_ENDPOINT_URL, MINIO_ACCESS_KEY, MINIO_SECRET_KEY"
        )
        sys.exit(1)

    print(f"[INFO] Endpoint: {endpoint}")

    # If bucket is empty or 'ALL', iterate over all buckets
    if not bucket or bucket.upper() == "ALL":
        names = list_buckets(endpoint, access_key, secret_key)
        if not names:
            print("[ERRO] Nenhum bucket encontrado no endpoint informado.")
            sys.exit(2)
        print(f"[INFO] Buckets encontrados: {', '.join(names)}")
        grand_bytes = 0
        grand_objects = 0
        per_bucket: Dict[str, int] = {}
        for b in names:
            tb, tobj, _ = list_all_objects_sizes(
                bucket=b,
                endpoint_url=endpoint,
                access_key=access_key,
                secret_key=secret_key,
            )
            grand_bytes += tb
            grand_objects += tobj
            per_bucket[b] = tb
        print("\n===== MINIO SIZE REPORT (ALL BUCKETS) =====")
        print(f"Total objects: {grand_objects:,}")
        print(f"Total size: {grand_bytes:,} bytes ({human_readable_size(grand_bytes)})")
        print("\nPor bucket:")
        for b, sz in sorted(per_bucket.items(), key=lambda x: x[0]):
            print(f"- {b:20s} {human_readable_size(sz)} ({sz:,} bytes)")
        return

    # Specific bucket
    print(f"[INFO] Bucket: {bucket}")
    try:
        total_bytes, total_objects, per_prefix = list_all_objects_sizes(
            bucket=bucket,
            endpoint_url=endpoint,
            access_key=access_key,
            secret_key=secret_key,
        )
    except Exception as e:
        # Fallback: show available buckets and suggest ALL
        print(f"[ERRO] Falha ao listar objetos do bucket '{bucket}': {e}")
        names = list_buckets(endpoint, access_key, secret_key)
        print(f"[INFO] Buckets disponíveis: {', '.join(names) if names else '(nenhum)'}")
        print("Dica: execute 'python scrips\\minio_size_report.py ALL' para somar todos.")
        sys.exit(3)

    print("\n===== MINIO SIZE REPORT (SINGLE BUCKET) =====")
    print(f"Total objects: {total_objects:,}")
    print(f"Total size: {total_bytes:,} bytes ({human_readable_size(total_bytes)})")

    if per_prefix:
        print("\nTop-level prefix breakdown (first 20):")
        for prefix, sz in sorted(per_prefix.items(), key=lambda x: x[0])[:20]:
            print(f"- {prefix:20s} {human_readable_size(sz)} ({sz:,} bytes)")


if __name__ == "__main__":
    main()


