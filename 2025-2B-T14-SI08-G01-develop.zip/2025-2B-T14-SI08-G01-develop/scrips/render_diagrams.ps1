Param(
    [string]$TargetDir = ".\assets\spritesheets_datacube"
)

Write-Host "Rendering Mermaid diagrams in $TargetDir"

if (-not (Get-Command npx -ErrorAction SilentlyContinue)) {
    Write-Warning "npx não encontrado no PATH. Instale Node.js (https://nodejs.org) para usar @mermaid-js/mermaid-cli."
    exit 1
}

$diagrams = @("cube_overview.mmd","star_schema.mmd","lineage.mmd")
foreach ($d in $diagrams) {
    $in = Join-Path $TargetDir $d
    if (Test-Path $in) {
        $out = [System.IO.Path]::ChangeExtension($in, ".png")
        Write-Host "mmdc -> $out"
        npx --yes @mermaid-js/mermaid-cli -i $in -o $out | Out-Null
    } else {
        Write-Warning "Arquivo não encontrado: $in"
    }
}

Write-Host "Concluído."


