# scrips/transform_json.py
import os
import sys
from dotenv import load_dotenv
from pyspark.sql import SparkSession
import pyspark.sql.functions as F 

# --- 0. Setup e Carregamento do .env ---
print("Carregando (T) Transform Pipeline...")
os.environ['PYSPARK_PYTHON'] = sys.executable
os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable

# --- Ajuste Windows/Hadoop: definir HADOOP_HOME e PATH para winutils ---
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
hadoop_home = os.path.join(project_root, 'hadoop')
hadoop_bin = os.path.join(hadoop_home, 'bin')
os.environ['HADOOP_HOME'] = hadoop_home
os.environ['hadoop.home.dir'] = hadoop_home
if os.path.isdir(hadoop_bin):
    os.environ['PATH'] = os.environ.get('PATH', '') + os.pathsep + hadoop_bin

dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path=dotenv_path)

# --- 1. (E) EXTRACT: Configuração do Spark para MinIO ---
print("Configurando Sessão Spark para MinIO (necessario para T)...")

MINIO_URL = os.environ.get('MINIO_ENDPOINT_URL')
MINIO_KEY = os.environ.get('MINIO_ACCESS_KEY')
MINIO_SECRET = os.environ.get('MINIO_SECRET_KEY')

if not MINIO_URL:
    raise ValueError("MINIO_ENDPOINT_URL nao definido no .env")

if MINIO_URL.startswith("http://"):
    MINIO_HOST_PORT = MINIO_URL[7:]
elif MINIO_URL.startswith("https://"):
    MINIO_HOST_PORT = MINIO_URL[8:]
else:
    MINIO_HOST_PORT = MINIO_URL

try:
    spark = SparkSession.builder \
        .appName("SKZ_ETL_Transform_Only") \
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.367") \
        .config("spark.hadoop.fs.s3a.endpoint", MINIO_HOST_PORT) \
        .config("spark.hadoop.fs.s3a.access.key", MINIO_KEY) \
        .config("spark.hadoop.fs.s3a.secret.key", MINIO_SECRET) \
        .config("spark.hadoop.fs.s3a.aws.credentials.provider", "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider") \
        .config("spark.hadoop.fs.s3a.path.style.access", "true") \
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
        .config("spark.hadoop.fs.s3a.connection.timeout", "60000") \
        .config("spark.hadoop.fs.s3a.connection.establish.timeout", "5000") \
        .config("spark.hadoop.fs.s3a.threads.keepalivetime", "60000") \
        .config("spark.hadoop.fs.s3a.threads.shutdown.timeout", "60000") \
        .config("spark.hadoop.fs.s3a.idle.connection.timeout", "300000") \
        .config("spark.hadoop.fs.s3a.multipart.purge", "true") \
        .config("spark.hadoop.fs.s3a.multipart.purge.age", "86400000") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .getOrCreate()

    print("[SUCESSO] Sessão Spark criada.")

    # --- 2. (E) EXTRACT: Leitura dos Dados (Input para o T) ---
    BUCKET_NAME = os.environ.get('MINIO_BUCKET_NAME')
    FILE_PATH = os.environ.get('MINIO_TEST_FILE_PATH')
    
    if not BUCKET_NAME or not FILE_PATH:
        raise ValueError("MINIO_BUCKET_NAME ou MINIO_TEST_FILE_PATH nao definidos no .env")

    s3_path = f"s3a://{BUCKET_NAME}/{FILE_PATH}"
    
    print(f"Iniciando leitura (E) do arquivo: {s3_path}")
    raw_df = spark.read.parquet(s3_path)
    
    print("\n[SUCESSO] (E) Extract concluído.")
    
    # --- 3. (T) TRANSFORM: Lógica Schema-on-Read ---
    print("\nIniciando (T) Transformacao para schema JSON...")
    
    data_tag = FILE_PATH.replace('.parquet', '').replace('/', '_')
    all_columns = raw_df.columns
    
    transformed_df = raw_df \
        .withColumn("datavalue_json", F.to_json(F.struct(*all_columns))) \
        .withColumn("data_tag", F.lit(data_tag)) \
        .withColumn("timestamp", F.current_timestamp()) \
        .select("timestamp", "data_tag", "datavalue_json")

    print("\n[SUCESSO] (T) Transform concluído. Schema final:")
    transformed_df.printSchema()
    
    print("\nAmostra dos dados transformados (JSON):")
    transformed_df.show(5, truncate=False)

    # --- 4. (Opcional) Persistência local do Transform (transacional_data/transform_data) ---
    try:
        local_base = os.path.join(project_root, 'transacional_data', 'transform_data', data_tag)
        os.makedirs(local_base, exist_ok=True)
        # JSON Lines (um por linha): usar formato json do Spark (gera part-*.json com 1 JSON/linha)
        output_path = os.path.join(local_base, 'jsonl')
        transformed_df.coalesce(1).write.mode('overwrite').json(output_path)
        print(f"\n[INFO] Transform salvo em JSONL em: {output_path}")
    except Exception as persist_err:
        print(f"[AVISO] Falha ao salvar Transform local: {persist_err}")

except Exception as e:
    print(f"\n[FALHA] Erro durante o processo de ETL (T).")
    print(f"Erro: {e}")

finally:
    if 'spark' in locals():
        spark.stop()
        print("Sessão Spark finalizada.")