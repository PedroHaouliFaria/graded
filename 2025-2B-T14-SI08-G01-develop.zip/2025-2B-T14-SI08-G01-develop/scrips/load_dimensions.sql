-- Sprint 3 — Carga de Dimensões (idempotente por DISTINCT; execute após a landing estar populada)
-- Fonte: DELIVERABLE_SPRINT_2.G01_pipeline_results (schema-on-read, JSON)

USE DELIVERABLE_SPRINT_2;

-- Helpers: funções de parsing
-- parse_dt(expr) → Date
-- Nota: parseDateTimeBestEffortOrNull lida com textos 'YYYY-MM-DD'/'YYYY-MM-DD HH:MM:SS'

-- 1) dim_company (geempre)
INSERT INTO G01_dim_company
SELECT DISTINCT
  CAST(cityHash64(toString(JSONExtractInt(datavalue_json,'codi_emp'))) % 2147483647 AS Int32) AS company_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  JSONExtractString(datavalue_json,'nome') AS nome,
  JSONExtractString(datavalue_json,'cnpj') AS cnpj,
  assumeNotNull(CAST(JSONExtractString(datavalue_json,'uf') AS FixedString(2))) AS uf,
  JSONExtractString(datavalue_json,'regime') AS regime
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%geempre_geempre%';

-- 2) dim_cost_center (ctccusto)
INSERT INTO G01_dim_cost_center
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|',toString(JSONExtractInt(datavalue_json,'i_ccusto')))) % 2147483647 AS Int32) AS cost_center_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  toInt32(JSONExtractInt(datavalue_json,'i_ccusto')) AS i_ccusto,
  JSONExtractString(datavalue_json,'descricao') AS descricao,
  JSONExtractString(datavalue_json,'tipo') AS tipo
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%ctccusto_ctccusto%';

-- 3) dim_account (ctcontas)
INSERT INTO G01_dim_account
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|',coalesce(JSONExtractString(datavalue_json,'conta_contabil'),''))) % 2147483647 AS Int32) AS account_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  coalesce(JSONExtractString(datavalue_json,'conta_contabil'),'') AS conta_contabil,
  JSONExtractString(datavalue_json,'descricao') AS descricao,
  JSONExtractString(datavalue_json,'natureza') AS natureza,
  toUInt8(JSONExtractInt(datavalue_json,'nivel')) AS nivel
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%ctcontas_ctcontas%';

-- 4) dim_product (efprodutos)
INSERT INTO G01_dim_product
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|',toString(JSONExtractInt(datavalue_json,'codi_pdi')))) % 2147483647 AS Int32) AS product_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  toInt32(JSONExtractInt(datavalue_json,'codi_pdi')) AS codi_pdi,
  JSONExtractString(datavalue_json,'desc_pdi') AS desc_pdi,
  JSONExtractString(datavalue_json,'ncm') AS ncm,
  JSONExtractString(datavalue_json,'unid_pdi') AS unid_pdi,
  toDecimal32OrNull(JSONExtractFloat(datavalue_json,'valor_referencia'), 2) AS valor_referencia,
  toDecimal32OrNull(JSONExtractFloat(datavalue_json,'aliquota_icms'), 4) AS aliquota_icms
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%efprodutos_efprodutos%';

-- 5) dim_customer (efsaidas/efservicos — thin)
INSERT INTO G01_dim_customer
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|',toString(JSONExtractInt(datavalue_json,'codi_cli')))) % 2147483647 AS Int32) AS customer_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  toInt64(JSONExtractInt(datavalue_json,'codi_cli')) AS codi_cli
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%efsaidas_efsaidas%'
   OR data_tag LIKE 'batch%efservicos_efservicos%';

-- 6) dim_supplier (efentradas — thin)
INSERT INTO G01_dim_supplier
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|',toString(JSONExtractInt(datavalue_json,'codi_for')))) % 2147483647 AS Int32) AS supplier_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  toInt64(JSONExtractInt(datavalue_json,'codi_for')) AS codi_for
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%efentradas_efentradas%';

-- 7) dim_document (normalizado de SAIDA/ENTRADA/SERVICO)
INSERT INTO G01_dim_document
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|','SAIDA','|',toString(JSONExtractInt(datavalue_json,'codi_sai')))) % 2147483647 AS Int32) AS document_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  'SAIDA' AS doc_type,
  toInt64(JSONExtractInt(datavalue_json,'codi_sai')) AS doc_id,
  JSONExtractString(datavalue_json,'cfop') AS cfop,
  JSONExtractString(datavalue_json,'chave_nfe') AS chave_nfe,
  JSONExtractString(datavalue_json,'municipio') AS municipio
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%efsaidas_efsaidas%'

UNION ALL
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|','ENTRADA','|',toString(JSONExtractInt(datavalue_json,'codi_ent')))) % 2147483647 AS Int32) AS document_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  'ENTRADA' AS doc_type,
  toInt64(JSONExtractInt(datavalue_json,'codi_ent')) AS doc_id,
  JSONExtractString(datavalue_json,'cfop') AS cfop,
  JSONExtractString(datavalue_json,'chave_nfe') AS chave_nfe,
  JSONExtractString(datavalue_json,'municipio') AS municipio
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%efentradas_efentradas%'

UNION ALL
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|','SERVICO','|',toString(JSONExtractInt(datavalue_json,'codi_ser')))) % 2147483647 AS Int32) AS document_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  'SERVICO' AS doc_type,
  toInt64(JSONExtractInt(datavalue_json,'codi_ser')) AS doc_id,
  JSONExtractString(datavalue_json,'cfop') AS cfop,
  JSONExtractString(datavalue_json,'chave_nfs') AS chave_nfe,
  JSONExtractString(datavalue_json,'municipio') AS municipio
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%efservicos_efservicos%';

-- 8) dim_employee (foempregados)
INSERT INTO G01_dim_employee
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|',toString(JSONExtractInt(datavalue_json,'i_empregados')))) % 2147483647 AS Int32) AS employee_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  toInt32(JSONExtractInt(datavalue_json,'i_empregados')) AS i_empregados,
  JSONExtractString(datavalue_json,'nome') AS nome,
  JSONExtractString(datavalue_json,'cpf') AS cpf,
  toDate(parseDateTimeBestEffortOrNull(JSONExtractString(datavalue_json,'data_nascimento'))) AS data_nascimento,
  toDate(parseDateTimeBestEffortOrNull(JSONExtractString(datavalue_json,'admissao'))) AS admissao,
  toDecimal32OrNull(JSONExtractFloat(datavalue_json,'salario'), 2) AS salario,
  JSONExtractString(datavalue_json,'cargo') AS cargo,
  JSONExtractString(datavalue_json,'cidade') AS cidade,
  CAST(JSONExtractString(datavalue_json,'estado') AS FixedString(2)) AS estado,
  toInt32(JSONExtractInt(datavalue_json,'i_ccusto')) AS i_ccusto
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%foempregados_foempregados%';

-- 9) dim_payroll_event (foeventos)
INSERT INTO G01_dim_payroll_event
SELECT DISTINCT
  CAST(cityHash64(concat(toString(JSONExtractInt(datavalue_json,'codi_emp')),'|',toString(JSONExtractInt(datavalue_json,'i_eventos')))) % 2147483647 AS Int32) AS event_sk,
  toInt32(JSONExtractInt(datavalue_json,'codi_emp')) AS codi_emp,
  toInt32(JSONExtractInt(datavalue_json,'i_eventos')) AS i_eventos,
  JSONExtractString(datavalue_json,'nome_evento') AS nome_evento,
  JSONExtractString(datavalue_json,'tipo') AS tipo,
  JSONExtractString(datavalue_json,'base_inss') AS base_inss,
  JSONExtractString(datavalue_json,'base_fgts') AS base_fgts,
  JSONExtractString(datavalue_json,'base_irrf') AS base_irrf
FROM G01_pipeline_results
WHERE data_tag LIKE 'batch%foeventos_foeventos%';

-- 10) dim_date (mapeia todas as datas conhecidas nas fontes)
INSERT INTO G01_dim_date
SELECT DISTINCT
  toInt32(toYYYYMMDD(d)) AS date_sk,
  d AS date,
  toYear(d) AS year,
  toQuarter(d) AS quarter,
  toMonth(d) AS month,
  formatDateTime(d, '%B') AS month_name,
  toDayOfMonth(d) AS day,
  toDayOfWeek(d) AS day_of_week
FROM
(
    -- datas de vendas
    SELECT toDate(parseDateTimeBestEffortOrNull(JSONExtractString(datavalue_json,'data_sai'))) AS d
    FROM G01_pipeline_results WHERE data_tag LIKE 'batch%efsaidas_efsaidas%'
    UNION ALL
    -- datas de compras
    SELECT toDate(parseDateTimeBestEffortOrNull(JSONExtractString(datavalue_json,'data_ent'))) AS d
    FROM G01_pipeline_results WHERE data_tag LIKE 'batch%efentradas_efentradas%'
    UNION ALL
    -- datas de serviços
    SELECT toDate(parseDateTimeBestEffortOrNull(JSONExtractString(datavalue_json,'data_ser'))) AS d
    FROM G01_pipeline_results WHERE data_tag LIKE 'batch%efservicos_efservicos%'
    UNION ALL
    -- datas contábeis
    SELECT toDate(parseDateTimeBestEffortOrNull(JSONExtractString(datavalue_json,'data_lan'))) AS d
    FROM G01_pipeline_results WHERE data_tag LIKE 'batch%ctlancto_ctlancto%'
    UNION ALL
    -- datas folha
    SELECT toDate(parseDateTimeBestEffortOrNull(JSONExtractString(datavalue_json,'data'))) AS d
    FROM G01_pipeline_results WHERE data_tag LIKE 'batch%FOMOVTO_FOMOVTO%'
) t
WHERE d IS NOT NULL;


