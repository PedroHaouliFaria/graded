-- Sprint 3 — Data Mart (views analíticas sobre o cubo)
USE DELIVERABLE_SPRINT_2;

-- Receita por mês e cliente
CREATE OR REPLACE VIEW vw_revenue_by_month_customer AS
SELECT
  d.year,
  d.month,
  c.codi_emp,
  fs.customer_sk,
  sum(fs.valor_total) AS revenue
FROM G01_fact_sales fs
JOIN G01_dim_date d      ON d.date_sk = fs.date_sk
JOIN G01_dim_company c   ON c.company_sk = fs.company_sk
GROUP BY d.year, d.month, c.codi_emp, fs.customer_sk;

-- Exposição tributária de compras (ICMS/IPI) por mês
CREATE OR REPLACE VIEW vw_purchases_tax_load AS
SELECT
  d.year,
  d.month,
  c.codi_emp,
  sum(fp.valor_total) AS total,
  sum(fp.valor_icms)  AS icms,
  sum(fp.valor_ipi)   AS ipi
FROM G01_fact_purchases fp
JOIN G01_dim_date d    ON d.date_sk = fp.date_sk
JOIN G01_dim_company c ON c.company_sk = fp.company_sk
GROUP BY d.year, d.month, c.codi_emp;

-- Giro/CMV aproximado por produto (movimentações)
CREATE OR REPLACE VIEW vw_inventory_by_product AS
SELECT
  c.codi_emp,
  p.codi_pdi,
  sum(im.quantidade)    AS qty_moved,
  sum(im.valor_total)   AS total_moved_value
FROM G01_fact_inventory_movements im
JOIN G01_dim_product p  ON p.product_sk = im.product_sk
JOIN G01_dim_company c  ON c.company_sk = im.company_sk
GROUP BY c.codi_emp, p.codi_pdi;

-- Lançamentos contábeis por dia e centro de custo
CREATE OR REPLACE VIEW vw_accounting_by_day_cost_center AS
SELECT
  d.date,
  c.codi_emp,
  cc.i_ccusto,
  sum(ae.valor) AS valor_total
FROM G01_fact_accounting_entries ae
JOIN G01_dim_date d        ON d.date_sk = ae.date_sk
JOIN G01_dim_company c     ON c.company_sk = ae.company_sk
LEFT JOIN G01_dim_cost_center cc ON cc.cost_center_sk = ae.cost_center_sk
GROUP BY d.date, c.codi_emp, cc.i_ccusto;

-- Folha: valor por mês, centro de custo e tipo de evento
CREATE OR REPLACE VIEW vw_payroll_by_month_cc_event AS
SELECT
  d.year,
  d.month,
  c.codi_emp,
  cc.i_ccusto,
  pe.tipo,
  sum(py.valor) AS valor_total
FROM G01_fact_payroll py
JOIN G01_dim_date d        ON d.date_sk = py.date_sk
JOIN G01_dim_company c     ON c.company_sk = py.company_sk
LEFT JOIN G01_dim_cost_center cc ON cc.cost_center_sk = py.cost_center_sk
JOIN G01_dim_payroll_event pe ON pe.event_sk = py.event_sk
GROUP BY d.year, d.month, c.codi_emp, cc.i_ccusto, pe.tipo;


