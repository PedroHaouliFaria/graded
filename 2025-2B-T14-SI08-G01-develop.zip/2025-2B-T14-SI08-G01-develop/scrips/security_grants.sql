
-- Sprint 3 — Segurança 
-- Papéis mínimos para consumo e operação do cubo do grupo G01

-- Leitura (consumo analítico)
CREATE ROLE IF NOT EXISTS G01_reader;
GRANT SELECT ON DELIVERABLE_SPRINT_2.* TO G01_reader;

-- Escrita (inserts no cubo/landing, se aplicável)
CREATE ROLE IF NOT EXISTS G01_writer;
GRANT INSERT ON DELIVERABLE_SPRINT_2.* TO G01_writer;

-- DDL do escopo do grupo (criar/alterar/apagar tabelas no schema do grupo) e criar DB
CREATE ROLE IF NOT EXISTS G01_ddl;
GRANT CREATE, ALTER, DROP ON DELIVERABLE_SPRINT_2.* TO G01_ddl;
GRANT CREATE DATABASE ON *.* TO G01_ddl;

-- possiveis atribuições:
-- GRANT G01_reader TO default;
-- GRANT G01_writer TO default;
-- GRANT G01_ddl    TO default;


