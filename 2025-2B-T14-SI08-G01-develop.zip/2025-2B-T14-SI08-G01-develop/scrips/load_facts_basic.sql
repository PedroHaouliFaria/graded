-- Sprint 3 — Carga de Fatos (básicos): vendas, compras, serviços
-- Pré-requisito: dimensões carregadas (company, date, customer/supplier, document)

USE DELIVERABLE_SPRINT_2;

-- SALES (efsaidas)
INSERT INTO G01_fact_sales
SELECT
  dc.company_sk,
  dd.date_sk,
  dcu.customer_sk,
  ddm.document_sk,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_total'),2) AS valor_total,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_icms'),2)  AS valor_icms,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_ipi'),2)   AS valor_ipi
FROM G01_pipeline_results p
JOIN G01_dim_company dc
  ON dc.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
JOIN G01_dim_customer dcu
  ON dcu.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND dcu.codi_cli = toInt64(JSONExtractInt(p.datavalue_json,'codi_cli'))
JOIN G01_dim_document ddm
  ON ddm.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND ddm.doc_type = 'SAIDA'
 AND ddm.doc_id = toInt64(JSONExtractInt(p.datavalue_json,'codi_sai'))
JOIN
(
  SELECT date AS d, date_sk FROM G01_dim_date
) dd
  ON dd.d = toDate(parseDateTimeBestEffortOrNull(JSONExtractString(p.datavalue_json,'data_sai')))
WHERE p.data_tag LIKE 'batch%efsaidas_efsaidas%';

-- PURCHASES (efentradas)
INSERT INTO G01_fact_purchases
SELECT
  dc.company_sk,
  dd.date_sk,
  ds.supplier_sk,
  ddm.document_sk,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_total'),2) AS valor_total,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_icms'),2)  AS valor_icms,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_ipi'),2)   AS valor_ipi
FROM G01_pipeline_results p
JOIN G01_dim_company dc
  ON dc.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
JOIN G01_dim_supplier ds
  ON ds.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND ds.codi_for = toInt64(JSONExtractInt(p.datavalue_json,'codi_for'))
JOIN G01_dim_document ddm
  ON ddm.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND ddm.doc_type = 'ENTRADA'
 AND ddm.doc_id = toInt64(JSONExtractInt(p.datavalue_json,'codi_ent'))
JOIN
(
  SELECT date AS d, date_sk FROM G01_dim_date
) dd
  ON dd.d = toDate(parseDateTimeBestEffortOrNull(JSONExtractString(p.datavalue_json,'data_ent')))
WHERE p.data_tag LIKE 'batch%efentradas_efentradas%';

-- SERVICES (efservicos)
INSERT INTO G01_fact_services
SELECT
  dc.company_sk,
  dd.date_sk,
  dcu.customer_sk,
  ddm.document_sk,
  toDecimal32OrNull(JSONExtractFloat(p.datavalue_json,'valor_servico'),2) AS valor_servico
FROM G01_pipeline_results p
JOIN G01_dim_company dc
  ON dc.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
JOIN G01_dim_customer dcu
  ON dcu.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND dcu.codi_cli = toInt64(JSONExtractInt(p.datavalue_json,'codi_cli'))
JOIN G01_dim_document ddm
  ON ddm.codi_emp = toInt32(JSONExtractInt(p.datavalue_json,'codi_emp'))
 AND ddm.doc_type = 'SERVICO'
 AND ddm.doc_id = toInt64(JSONExtractInt(p.datavalue_json,'codi_ser'))
JOIN
(
  SELECT date AS d, date_sk FROM G01_dim_date
) dd
  ON dd.d = toDate(parseDateTimeBestEffortOrNull(JSONExtractString(p.datavalue_json,'data_ser')))
WHERE p.data_tag LIKE 'batch%efservicos_efservicos%';


