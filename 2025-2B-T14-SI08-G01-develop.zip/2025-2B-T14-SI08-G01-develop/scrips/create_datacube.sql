
CREATE DATABASE IF NOT EXISTS DELIVERABLE_SPRINT_2;

-- Dimensions ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_date
(
  date_sk Int32,
  date Date,
  year UInt16,
  quarter UInt8,
  month UInt8,
  month_name String,
  day UInt8,
  day_of_week UInt8
) ENGINE=MergeTree ORDER BY (date_sk);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_company
(
  company_sk Int32,
  codi_emp Int32,
  nome String,
  cnpj String,
  uf FixedString(2),
  regime String
) ENGINE=MergeTree ORDER BY (codi_emp);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_cost_center
(
  cost_center_sk Int32,
  codi_emp Int32,
  i_ccusto Int32,
  descricao String,
  tipo String
) ENGINE=MergeTree ORDER BY (codi_emp, i_ccusto);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_account
(
  account_sk Int32,
  codi_emp Int32,
  conta_contabil String,
  descricao String,
  natureza String,
  nivel UInt8
) ENGINE=MergeTree ORDER BY (codi_emp, conta_contabil);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_product
(
  product_sk Int32,
  codi_emp Int32,
  codi_pdi Int32,
  desc_pdi String,
  ncm String,
  unid_pdi String,
  valor_referencia Decimal(18,2),
  aliquota_icms Decimal(9,4)
) ENGINE=MergeTree ORDER BY (codi_emp, codi_pdi);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_customer
(
  customer_sk Int32,
  codi_emp Int32,
  codi_cli Int64
) ENGINE=MergeTree ORDER BY (codi_emp, codi_cli);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_supplier
(
  supplier_sk Int32,
  codi_emp Int32,
  codi_for Int64
) ENGINE=MergeTree ORDER BY (codi_emp, codi_for);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_document
(
  document_sk Int32,
  codi_emp Int32,
  doc_type LowCardinality(String), -- SAIDA|ENTRADA|SERVICO
  doc_id Int64,
  cfop String,
  chave_nfe String,
  municipio String
) ENGINE=MergeTree ORDER BY (codi_emp, doc_type, doc_id);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_employee
(
  employee_sk Int32,
  codi_emp Int32,
  i_empregados Int32,
  nome String,
  cpf String,
  data_nascimento Date,
  admissao Date,
  salario Decimal(18,2),
  cargo String,
  cidade String,
  estado FixedString(2),
  i_ccusto Int32
) ENGINE=MergeTree ORDER BY (codi_emp, i_empregados);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_dim_payroll_event
(
  event_sk Int32,
  codi_emp Int32,
  i_eventos Int32,
  nome_evento String,
  tipo LowCardinality(String),
  base_inss LowCardinality(String),
  base_fgts LowCardinality(String),
  base_irrf LowCardinality(String)
) ENGINE=MergeTree ORDER BY (codi_emp, i_eventos);

-- Facts --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_fact_sales
(
  company_sk Int32,
  date_sk Int32,
  customer_sk Int32,
  document_sk Int32,
  valor_total Decimal(18,2),
  valor_icms Decimal(18,2),
  valor_ipi  Decimal(18,2)
) ENGINE=MergeTree ORDER BY (company_sk, date_sk, customer_sk, document_sk);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_fact_purchases
(
  company_sk Int32,
  date_sk Int32,
  supplier_sk Int32,
  document_sk Int32,
  valor_total Decimal(18,2),
  valor_icms Decimal(18,2),
  valor_ipi  Decimal(18,2)
) ENGINE=MergeTree ORDER BY (company_sk, date_sk, supplier_sk, document_sk);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_fact_services
(
  company_sk Int32,
  date_sk Int32,
  customer_sk Int32,
  document_sk Int32,
  valor_servico Decimal(18,2)
) ENGINE=MergeTree ORDER BY (company_sk, date_sk, customer_sk, document_sk);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_fact_inventory_movements
(
  company_sk Int32,
  document_sk Int32,
  product_sk Int32,
  sequencia Int32,
  quantidade Int32,
  valor_unitario Decimal(18,2),
  valor_total Decimal(18,2)
) ENGINE=MergeTree ORDER BY (company_sk, document_sk, product_sk, sequencia);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_fact_accounting_entries
(
  company_sk Int32,
  date_sk Int32,
  cost_center_sk Int32,
  account_debit_sk Int32,
  account_credit_sk Int32,
  nume_lan String,
  origem LowCardinality(String),
  valor Decimal(18,2)
) ENGINE=MergeTree ORDER BY (company_sk, date_sk, cost_center_sk, nume_lan);

CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_fact_payroll
(
  company_sk Int32,
  date_sk Int32,
  employee_sk Int32,
  event_sk Int32,
  cost_center_sk Int32,
  origem LowCardinality(String),
  valor Decimal(18,2)
) ENGINE=MergeTree ORDER BY (company_sk, date_sk, employee_sk, event_sk);