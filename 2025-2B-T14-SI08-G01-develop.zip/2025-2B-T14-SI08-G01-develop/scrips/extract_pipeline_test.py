# scrips/ingest_pipeline.py
import os
import sys
from dotenv import load_dotenv
from pyspark.sql import SparkSession

# --- 0. Setup e Carregamento do .env ---
print("Carregando (E) Extract Pipeline...")
os.environ['PYSPARK_PYTHON'] = sys.executable
os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable

# --- Ajuste Windows/Hadoop: definir HADOOP_HOME e PATH para winutils ---
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
hadoop_home = os.path.join(project_root, 'hadoop')
hadoop_bin = os.path.join(hadoop_home, 'bin')
os.environ['HADOOP_HOME'] = hadoop_home
os.environ['hadoop.home.dir'] = hadoop_home
if os.path.isdir(hadoop_bin):
    os.environ['PATH'] = os.environ.get('PATH', '') + os.pathsep + hadoop_bin

dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path=dotenv_path)

# --- 1. (E) EXTRACT: Configuração do Spark para MinIO ---
print("Configurando Sessão Spark para MinIO...")

MINIO_URL = os.environ.get('MINIO_ENDPOINT_URL')
MINIO_KEY = os.environ.get('MINIO_ACCESS_KEY')
MINIO_SECRET = os.environ.get('MINIO_SECRET_KEY')

if not MINIO_URL:
    raise ValueError("MINIO_ENDPOINT_URL nao definido no .env")

if MINIO_URL.startswith("http://"):
    MINIO_HOST_PORT = MINIO_URL[7:]
elif MINIO_URL.startswith("https://"):
    MINIO_HOST_PORT = MINIO_URL[8:]
else:
    MINIO_HOST_PORT = MINIO_URL

try:
    spark = SparkSession.builder \
        .appName("SKZ_ETL_Extract_Only") \
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.367") \
        .config("spark.hadoop.fs.s3a.endpoint", MINIO_HOST_PORT) \
        .config("spark.hadoop.fs.s3a.access.key", MINIO_KEY) \
        .config("spark.hadoop.fs.s3a.secret.key", MINIO_SECRET) \
        .config("spark.hadoop.fs.s3a.aws.credentials.provider", "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider") \
        .config("spark.hadoop.fs.s3a.path.style.access", "true") \
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
        .config("spark.hadoop.fs.s3a.connection.timeout", "60000") \
        .config("spark.hadoop.fs.s3a.connection.establish.timeout", "5000") \
        .config("spark.hadoop.fs.s3a.threads.keepalivetime", "60000") \
        .config("spark.hadoop.fs.s3a.threads.shutdown.timeout", "60000") \
        .config("spark.hadoop.fs.s3a.idle.connection.timeout", "300000") \
        .config("spark.hadoop.fs.s3a.multipart.purge", "true") \
        .config("spark.hadoop.fs.s3a.multipart.purge.age", "86400000") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .getOrCreate()

    print("[SUCESSO] Sessão Spark criada.")

    # --- 2. (E) EXTRACT: Leitura dos Dados (Parquet) ---
    BUCKET_NAME = os.environ.get('MINIO_BUCKET_NAME')
    FILE_PATH = os.environ.get('MINIO_TEST_FILE_PATH')
    
    if not BUCKET_NAME or not FILE_PATH:
        raise ValueError("MINIO_BUCKET_NAME ou MINIO_TEST_FILE_PATH nao definidos no .env")

    s3_path = f"s3a://{BUCKET_NAME}/{FILE_PATH}"
    
    print(f"Iniciando leitura (E) do arquivo: {s3_path}")
    raw_df = spark.read.parquet(s3_path)
    
    print("\n[SUCESSO] (E) Extract concluído. Schema dos dados brutos:")
    raw_df.printSchema()
    
    print("\nAmostra dos dados brutos:")
    raw_df.show(5)

    # --- 3. (Opcional) Persistência local da amostra (transacional_data/extract_data) ---
    try:
        data_tag = FILE_PATH.replace('.parquet', '').replace('/', '_')
        local_base = os.path.join(project_root, 'transacional_data', 'extract_data', data_tag)
        os.makedirs(local_base, exist_ok=True)
        # salva uma amostra limitada (ex.: até 1000 linhas) em parquet local
        sample_df = raw_df.limit(1000)
        sample_path = os.path.join(local_base, 'sample_parquet')
        sample_df.write.mode('overwrite').parquet(sample_path)
        print(f"\n[INFO] Amostra do Extract salva em: {sample_path}")
    except Exception as persist_err:
        print(f"[AVISO] Falha ao salvar amostra local do Extract: {persist_err}")

except Exception as e:
    print(f"\n[FALHA] Erro durante o processo de Extracao.")
    print(f"Erro: {e}")

finally:
    if 'spark' in locals():
        spark.stop()
        print("Sessão Spark finalizada.")