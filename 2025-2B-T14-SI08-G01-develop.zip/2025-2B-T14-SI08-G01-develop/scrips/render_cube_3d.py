"""
Render conceptual 3D cubes for each fact table, labeling the three primary
axes with relevant dimensions and the measures at the cube center.

Output: PNGs saved under assets/spritesheets_datacube/cubes/

Usage (venv recommended):
  pip install plotly kaleido
  python scrips/render_cube_3d.py
"""
from pathlib import Path

import plotly.graph_objects as go

OUTPUT_DIR = Path("assets/spritesheets_datacube/cubes")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def make_wire_cube(edge=1.0, color="rgba(30,30,30,0.6)") -> go.Scatter3d:
    # 12 edges of a cube
    e = edge
    lines = [
        ((0, 0, 0), (e, 0, 0)), ((0, e, 0), (e, e, 0)), ((0, 0, e), (e, 0, e)), ((0, e, e), (e, e, e)),
        ((0, 0, 0), (0, e, 0)), ((e, 0, 0), (e, e, 0)), ((0, 0, e), (0, e, e)), ((e, 0, e), (e, e, e)),
        ((0, 0, 0), (0, 0, e)), ((e, 0, 0), (e, 0, e)), ((0, e, 0), (0, e, e)), ((e, e, 0), (e, e, e)),
    ]
    xs, ys, zs = [], [], []
    for (x1, y1, z1), (x2, y2, z2) in lines:
        xs += [x1, x2, None]
        ys += [y1, y2, None]
        zs += [z1, z2, None]
    return go.Scatter3d(x=xs, y=ys, z=zs, mode="lines", line=dict(color=color, width=5), showlegend=False)


def render_cube_png(title: str, x_label: str, y_label: str, z_label: str, measures_label: str, out_png: Path):
    fig = go.Figure()
    fig.add_trace(make_wire_cube())

    # Axis labels
    fig.add_trace(go.Scatter3d(x=[1.05], y=[0], z=[0], mode="text", text=[x_label], textposition="middle right"))
    fig.add_trace(go.Scatter3d(x=[0], y=[1.05], z=[0], mode="text", text=[y_label], textposition="middle right"))
    fig.add_trace(go.Scatter3d(x=[0], y=[0], z=[1.05], mode="text", text=[z_label], textposition="middle right"))

    # Measures at cube center
    fig.add_trace(go.Scatter3d(x=[0.5], y=[0.5], z=[0.5], mode="markers+text",
                               text=[measures_label], textposition="top center",
                               marker=dict(size=6, color="#ffb84d")))

    fig.update_layout(
        title=title,
        scene=dict(
            xaxis=dict(title="", showbackground=False, showticklabels=False, zeroline=False),
            yaxis=dict(title="", showbackground=False, showticklabels=False, zeroline=False),
            zaxis=dict(title="", showbackground=False, showticklabels=False, zeroline=False),
            aspectmode="cube",
        ),
        margin=dict(l=0, r=0, t=40, b=0),
        showlegend=False,
    )
    fig.write_image(str(out_png), width=800, height=900, scale=2)


def main():
    # Define one 3D cube per fact, choosing three most salient dimensions
    cubes = [
        # title, x, y, z, measures, output file
        ("fact_sales — 3D view", "dim_date", "dim_company", "dim_customer", "valor_total / icms / ipi",
         OUTPUT_DIR / "fact_sales_cube.png"),
        ("fact_purchases — 3D view", "dim_date", "dim_company", "dim_supplier", "valor_total / icms / ipi",
         OUTPUT_DIR / "fact_purchases_cube.png"),
        ("fact_services — 3D view", "dim_date", "dim_company", "dim_customer", "valor_servico",
         OUTPUT_DIR / "fact_services_cube.png"),
        ("fact_inventory_movements — 3D view", "dim_document", "dim_company", "dim_product", "qtd / v_unit / v_total",
         OUTPUT_DIR / "fact_inventory_movements_cube.png"),
        ("fact_accounting_entries — 3D view", "dim_date", "dim_company", "dim_cost_center", "valor (deb/cred)",
         OUTPUT_DIR / "fact_accounting_entries_cube.png"),
        ("fact_payroll — 3D view", "dim_date", "dim_company", "dim_payroll_event", "valor",
         OUTPUT_DIR / "fact_payroll_cube.png"),
    ]

    for title, xl, yl, zl, ml, out_file in cubes:
        render_cube_png(title, xl, yl, zl, ml, out_file)
        print(f"Saved: {out_file}")


if __name__ == "__main__":
    main()


