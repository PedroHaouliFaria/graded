import os
import sys
from datetime import datetime
from urllib import request as urlrequest
from urllib.parse import quote
from dotenv import load_dotenv

"""
Teste rápido e verboso de comunicação HTTP com ClickHouse.
Valida: SELECT 1, SHOW DATABASES, CREATE DATABASE/TABLE, INSERT (2 modos) e SELECT COUNT.
"""

def http_get(url: str):
    req = urlrequest.Request(url, method="GET")
    with urlrequest.urlopen(req) as resp:
        body = resp.read().decode("utf-8", errors="ignore")
        return resp.status, dict(resp.headers), body

def http_post(url: str, body: str):
    data = body.encode("utf-8")
    req = urlrequest.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "text/plain; charset=utf-8")
    with urlrequest.urlopen(req) as resp:
        rb = resp.read().decode("utf-8", errors="ignore")
        return resp.status, dict(resp.headers), rb

def run():
    print("=== ClickHouse HTTP Connectivity Test ===")
    # carregar .env
    dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
    load_dotenv(dotenv_path=dotenv_path)

    host = os.environ.get("CLICKHOUSE_HOST")
    port = os.environ.get("CLICKHOUSE_PORT", "8787")
    user = os.environ.get("CLICKHOUSE_USER", "admin")
    password = os.environ.get("CLICKHOUSE_PASSWORD", "")
    database = os.environ.get("CLICKHOUSE_DATABASE", "default")
    table = os.environ.get("CLICKHOUSE_TABLE", "skz_pipeline_data")

    if not host:
        print("[FAIL] CLICKHOUSE_HOST não definido no .env")
        sys.exit(2)

    base = f"http://{host}:{port}/"

    def url_with_query(sql: str, db: str | None = None):
        q = f"query={quote(sql)}&user={quote(user)}&password={quote(password)}"
        if db:
            return f"{base}?database={quote(db)}&{q}"
        return f"{base}?{q}"

    # 1) SELECT 1
    try:
        u = url_with_query("SELECT 1")
        status, headers, body = http_get(u)
        print(f"[TEST] SELECT 1 → HTTP {status}, body='{body.strip()}'")
    except Exception as e:
        print(f"[FAIL] SELECT 1 → {e}")
        return

    # 2) SHOW DATABASES
    try:
        u = url_with_query("SHOW DATABASES")
        status, headers, body = http_get(u)
        print(f"[TEST] SHOW DATABASES → HTTP {status}")
        print(body.strip()[:300] + ("..." if len(body) > 300 else ""))
    except Exception as e:
        print(f"[FAIL] SHOW DATABASES → {e}")
        return

    # 3) CREATE DATABASE (idempotente)
    try:
        sql = f"CREATE DATABASE IF NOT EXISTS {database}"
        u = url_with_query(sql)
        status, headers, body = http_get(u)
        print(f"[TEST] CREATE DATABASE {database} → HTTP {status}")
    except Exception as e:
        print(f"[WARN] CREATE DATABASE {database} (query=) falhou: {e}")
        try:
            # fallback POST no corpo
            u = f"{base}?user={quote(user)}&password={quote(password)}"
            status, headers, body = http_post(u, sql)
            print(f"[TEST] CREATE DATABASE {database} (POST body) → HTTP {status}")
        except Exception as e2:
            print(f"[FAIL] CREATE DATABASE {database} → {e2}")
            return

    # 4) CREATE TABLE (idempotente)
    try:
        create_table = (
            f"CREATE TABLE IF NOT EXISTS {database}.{table} "
            f"( `timestamp` DateTime DEFAULT now(), `data_tag` String, `datavalue_json` String ) "
            f"ENGINE=MergeTree() ORDER BY (data_tag, timestamp)"
        )
        u = url_with_query(create_table)
        status, headers, body = http_get(u)
        print(f"[TEST] CREATE TABLE {database}.{table} → HTTP {status}")
    except Exception as e:
        print(f"[WARN] CREATE TABLE (query=) falhou: {e}")
        try:
            u = f"{base}?database={quote(database)}&user={quote(user)}&password={quote(password)}"
            status, headers, body = http_post(u, create_table)
            print(f"[TEST] CREATE TABLE {database}.{table} (POST body) → HTTP {status}")
        except Exception as e2:
            print(f"[FAIL] CREATE TABLE {database}.{table} → {e2}")
            return

    # 5) INSERT 1 linha — modo A (TSV body + query=INSERT FORMAT TSV)
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    demo_tag = "connectivity_test"
    demo_json = '{"ping": "ok"}'
    try:
        insert_q = f"INSERT INTO {database}.{table} (timestamp, data_tag, datavalue_json) FORMAT TSV"
        u = url_with_query(insert_q)
        tsv_body = f"{now}\t{demo_tag}\t{demo_json}"
        status, headers, body = http_post(u, tsv_body)
        print(f"[TEST] INSERT (FORMAT TSV) → HTTP {status}")
    except Exception as e:
        print(f"[WARN] INSERT (FORMAT TSV) falhou: {e}")
        # 5b) Fallback — INSERT VALUES via query=
        try:
            values_sql = (
                f"INSERT INTO {database}.{table} (timestamp, data_tag, datavalue_json) "
                f"VALUES ('{now}','{demo_tag}','{demo_json}')"
            )
            u = url_with_query(values_sql)
            status, headers, body = http_get(u)
            print(f"[TEST] INSERT (VALUES) → HTTP {status}")
        except Exception as e2:
            print(f"[FAIL] INSERT → {e2}")
            return

    # 6) SELECT COUNT(*) e últimas linhas
    try:
        u = url_with_query(f"SELECT count() FROM {database}.{table}")
        status, headers, body = http_get(u)
        print(f"[TEST] COUNT → HTTP {status}, count={body.strip()}")
    except Exception as e:
        print(f"[FAIL] COUNT → {e}")
        return

    try:
        u = url_with_query(f"SELECT * FROM {database}.{table} ORDER BY timestamp DESC LIMIT 3")
        status, headers, body = http_get(u)
        print(f"[TEST] TAIL(3) → HTTP {status}")
        print(body.strip())
    except Exception as e:
        print(f"[WARN] TAIL → {e}")

if __name__ == "__main__":
    run()


