-- Sprint 3 — QA do Cubo
-- Verificações de contagem, FKs órfãs, reconciliação e performance básica

USE DELIVERABLE_SPRINT_2;

-- 1) Contagens por dimensão
SELECT 'dim_company' AS tbl, count() AS rows FROM G01_dim_company
UNION ALL SELECT 'dim_cost_center', count() FROM G01_dim_cost_center
UNION ALL SELECT 'dim_account', count() FROM G01_dim_account
UNION ALL SELECT 'dim_product', count() FROM G01_dim_product
UNION ALL SELECT 'dim_customer', count() FROM G01_dim_customer
UNION ALL SELECT 'dim_supplier', count() FROM G01_dim_supplier
UNION ALL SELECT 'dim_document', count() FROM G01_dim_document
UNION ALL SELECT 'dim_employee', count() FROM G01_dim_employee
UNION ALL SELECT 'dim_payroll_event', count() FROM G01_dim_payroll_event
UNION ALL SELECT 'dim_date', count() FROM G01_dim_date;

-- 2) Contagens por fato
SELECT 'fact_sales', count() FROM G01_fact_sales
UNION ALL SELECT 'fact_purchases', count() FROM G01_fact_purchases
UNION ALL SELECT 'fact_services', count() FROM G01_fact_services
UNION ALL SELECT 'fact_inventory_movements', count() FROM G01_fact_inventory_movements
UNION ALL SELECT 'fact_accounting_entries', count() FROM G01_fact_accounting_entries
UNION ALL SELECT 'fact_payroll', count() FROM G01_fact_payroll;

-- 3) FKs órfãs (exemplos) — sales
SELECT count() AS orphan_company
FROM G01_fact_sales f
LEFT JOIN G01_dim_company d ON f.company_sk = d.company_sk
WHERE d.company_sk IS NULL;

SELECT count() AS orphan_customer
FROM G01_fact_sales f
LEFT JOIN G01_dim_customer d ON f.customer_sk = d.customer_sk
WHERE d.customer_sk IS NULL;

SELECT count() AS orphan_document
FROM G01_fact_sales f
LEFT JOIN G01_dim_document d ON f.document_sk = d.document_sk
WHERE d.document_sk IS NULL;

-- 4) Reconciliação simples — vendas por dia vs. soma no fato
SELECT dd.date AS dia,
       sum(f.valor_total) AS total_fact
FROM G01_fact_sales f
JOIN G01_dim_date dd ON dd.date_sk = f.date_sk
GROUP BY dd.date
ORDER BY dd.date
LIMIT 50;

-- 5) Null-rate em chaves de fatos (sanidade)
SELECT 'sales' AS fact,
       sumIf(1, company_sk IS NULL) AS null_company_sk,
       sumIf(1, date_sk IS NULL) AS null_date_sk,
       sumIf(1, document_sk IS NULL) AS null_document_sk
FROM G01_fact_sales;

-- 6) Performance básica — COUNT rápido por fatos
SELECT 'sales', count() FROM G01_fact_sales SETTINGS max_threads=4
UNION ALL SELECT 'purchases', count() FROM G01_fact_purchases SETTINGS max_threads=4
UNION ALL SELECT 'services', count() FROM G01_fact_services SETTINGS max_threads=4;


