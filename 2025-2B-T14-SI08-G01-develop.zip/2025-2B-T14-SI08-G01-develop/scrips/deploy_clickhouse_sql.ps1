Param(
    [Parameter(Mandatory = $true)]
    [string]$SqlFile,
    [string]$Host = $env:CLICKHOUSE_HOST,
    [string]$Port = $env:CLICKHOUSE_PORT,
    [string]$User = $env:CLICKHOUSE_USER,
    [string]$Password = $env:CLICKHOUSE_PASSWORD,
    [string]$Database = $env:CLICKHOUSE_DATABASE
)

if (-not (Test-Path $SqlFile)) {
    Write-Error "Arquivo SQL não encontrado: $SqlFile"
    exit 1
}

if (-not $Host) { $Host = "10.8.8.10" }
if (-not $Port) { $Port = "8123" }
if (-not $User) { $User = "default" }
if (-not $Password) { $Password = "" }

$base = "http://$Host`:$Port/"
$sql = Get-Content -Path $SqlFile -Raw

# Usa query= quando possível (evita 404). Para DDL longas, POST com body.
$uriQs = "$base?query="
if ($Database) { $uriQs += "/*db*/&database=$Database" }
if ($User)     { $uriQs += "&user=$User" }
if ($Password) { $uriQs += "&password=$Password" }

try {
    $resp = Invoke-WebRequest -Method Post -Uri $uriQs -Body $sql -ContentType "text/plain"
    Write-Host "OK - Enviado ($($resp.StatusCode))"
} catch {
    Write-Warning "Falha no envio com query=. Tentando alternativa (POST body simples)."
    $uriBody = "$base"
    $join = "?"
    if ($Database) { $uriBody += "${join}database=$Database"; $join="&" }
    if ($User)     { $uriBody += "${join}user=$User"; $join="&" }
    if ($Password) { $uriBody += "${join}password=$Password" }
    try {
        $resp2 = Invoke-WebRequest -Method Post -Uri $uriBody -Body $sql -ContentType "text/plain"
        Write-Host "OK - Enviado alternativa ($($resp2.StatusCode))"
    } catch {
        Write-Error ("Falha ao enviar SQL: " + $_.Exception.Message)
        exit 2
    }
}