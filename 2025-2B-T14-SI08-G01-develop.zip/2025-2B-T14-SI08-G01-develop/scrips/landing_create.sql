-- Sprint 3 — Landing DDL (idempotente)
-- Observação: pode exigir usuário com permissão de DDL no servidor alvo.

-- Database do sprint (ajuste se o professor instruir outro nome)
CREATE DATABASE IF NOT EXISTS DELIVERABLE_SPRINT_2;

-- Tabela canônica de landing (schema-on-read)
CREATE TABLE IF NOT EXISTS DELIVERABLE_SPRINT_2.G01_pipeline_results
(
  `timestamp`       DateTime DEFAULT now(),
  `data_tag`        String,
  `datavalue_json`  String
) ENGINE = MergeTree()
ORDER BY (data_tag, timestamp);


