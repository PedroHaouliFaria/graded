import os
import sys
from dotenv import load_dotenv
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from urllib import request as urlrequest
from urllib.parse import quote
import boto3
from botocore.client import Config
import time
import math
import time
import math


# --- 0. Setup & .env ---
print("Carregando (E+T+L) Load Pipeline...")
os.environ['PYSPARK_PYTHON'] = sys.executable
os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable

project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
hadoop_home = os.path.join(project_root, 'hadoop')
hadoop_bin = os.path.join(hadoop_home, 'bin')
os.environ['HADOOP_HOME'] = hadoop_home
os.environ['hadoop.home.dir'] = hadoop_home
if os.path.isdir(hadoop_bin):
    os.environ['PATH'] = os.environ.get('PATH', '') + os.pathsep + hadoop_bin

dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path=dotenv_path)

# --- 1. Config Spark S3A (MinIO) ---
MINIO_URL = os.environ.get('MINIO_ENDPOINT_URL')
MINIO_KEY = os.environ.get('MINIO_ACCESS_KEY')
MINIO_SECRET = os.environ.get('MINIO_SECRET_KEY')

if not MINIO_URL:
    raise ValueError("MINIO_ENDPOINT_URL nao definido no .env")

if MINIO_URL.startswith("http://"):
    MINIO_HOST_PORT = MINIO_URL[7:]
elif MINIO_URL.startswith("https://"):
    MINIO_HOST_PORT = MINIO_URL[8:]
else:
    MINIO_HOST_PORT = MINIO_URL

BUCKET_NAME = os.environ.get('MINIO_BUCKET_NAME')
FILE_PATH = os.environ.get('MINIO_TEST_FILE_PATH')
if not BUCKET_NAME or not FILE_PATH:
    raise ValueError("MINIO_BUCKET_NAME ou MINIO_TEST_FILE_PATH nao definidos no .env")

# --- 2. Config ClickHouse ---
CH_HOST = os.environ.get('CLICKHOUSE_HOST')
CH_PORT = os.environ.get('CLICKHOUSE_PORT')
CH_USER = os.environ.get('CLICKHOUSE_USER')
CH_PASS = os.environ.get('CLICKHOUSE_PASSWORD')
CH_DB = os.environ.get('CLICKHOUSE_DATABASE', 'default')
CH_TABLE = os.environ.get('CLICKHOUSE_TABLE', 'skz_pipeline_data')

def http_insert_tsv(rows):
    if not rows:
        return
    # Monta payload TSV: apenas linhas; o comando INSERT vai na query da URL
    lines = []
    for ts, data_tag, json_value in rows:
        # normaliza timestamp 'YYYY-MM-DD HH:MM:SS'
        try:
            ts = ts.replace(microsecond=0)
        except Exception:
            pass
        ts_str = ts.strftime("%Y-%m-%d %H:%M:%S")
        # escapar TAB e quebras em strings
        safe_tag = str(data_tag).replace("\t", "\\t").replace("\n", "\\n")
        safe_json = str(json_value).replace("\t", "\\t").replace("\n", "\\n")
        lines.append(f"{ts_str}\t{safe_tag}\t{safe_json}")
    tsv_body = "\n".join(lines)
    # Tentativa 1: query=INSERT ... FORMAT TSV na URL; corpo = TSV
    from urllib.parse import quote
    insert_q = f"INSERT INTO {CH_DB}.{CH_TABLE} (timestamp, data_tag, datavalue_json) FORMAT TSV"
    url_q = (
        f"http://{CH_HOST}:{CH_PORT}/?database={CH_DB}"
        f"&user={CH_USER}&password={CH_PASS}"
        f"&query={quote(insert_q)}"
    )
    req = urlrequest.Request(url_q, data=tsv_body.encode("utf-8"), method="POST")
    req.add_header("Content-Type", "text/plain; charset=utf-8")
    try:
        with urlrequest.urlopen(req) as resp:
            _ = resp.read()
            return
    except Exception:
        # Tentativa 2 (fallback): SQL completo + TSV no corpo; sem query=
        insert_sql = f"INSERT INTO {CH_DB}.{CH_TABLE} (timestamp, data_tag, datavalue_json) FORMAT TSV\n"
        body = insert_sql + tsv_body
        url_body = f"http://{CH_HOST}:{CH_PORT}/?database={CH_DB}&user={CH_USER}&password={CH_PASS}"
        req2 = urlrequest.Request(url_body, data=body.encode("utf-8"), method="POST")
        req2.add_header("Content-Type", "text/plain; charset=utf-8")
        with urlrequest.urlopen(req2) as resp2:
            _ = resp2.read()

def http_insert_values(rows):
    if not rows:
        return
    # Constrói INSERT ... VALUES (...),(...)
    values_sql_parts = []
    for ts, data_tag, json_value in rows:
        try:
            ts = ts.replace(microsecond=0)
        except Exception:
            pass
        ts_str = ts.strftime("%Y-%m-%d %H:%M:%S")
        tag_esc = str(data_tag).replace("'", "''")
        json_esc = str(json_value).replace("'", "''")
        values_sql_parts.append(f"('{ts_str}','{tag_esc}','{json_esc}')")
    insert_sql = f"INSERT INTO {CH_DB}.{CH_TABLE} (timestamp, data_tag, datavalue_json) VALUES " + ",".join(values_sql_parts)
    url = (
        f"http://{CH_HOST}:{CH_PORT}/?user={CH_USER}&password={CH_PASS}"
        f"&query={quote(insert_sql)}"
    )
    with urlrequest.urlopen(url) as resp:
        _ = resp.read()

def list_parquet_keys_for_batches(bucket: str, endpoint_url: str, access_key: str, secret_key: str, batch_ids: list[str]) -> list[str]:
    s3 = boto3.client(
        's3',
        endpoint_url=endpoint_url,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        use_ssl=endpoint_url.startswith('https'),
        config=Config(signature_version='s3v4')
    )
    # pequeno retry/backoff para chamadas de listagem
    def list_with_retry(**params):
        delay = 0.5
        for attempt in range(5):
            try:
                return s3.list_objects_v2(**params)
            except Exception:
                if attempt == 4:
                    raise
                time.sleep(delay)
                delay *= 2
        return {}
    keys = []
    for bid in batch_ids:
        prefix = f"batch_{int(bid):03d}/"
        token = None
        while True:
            params = dict(Bucket=bucket, Prefix=prefix, MaxKeys=1000)
            if token:
                params['ContinuationToken'] = token
            resp = list_with_retry(**params)
            for obj in resp.get('Contents', []):
                k = obj['Key']
                if k.endswith('.parquet'):
                    keys.append(k)
            if resp.get('IsTruncated'):
                token = resp.get('NextContinuationToken')
            else:
                break
    return keys

def discover_batch_ids(bucket: str, endpoint_url: str, access_key: str, secret_key: str) -> list[str]:
    s3 = boto3.client(
        's3',
        endpoint_url=endpoint_url,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        use_ssl=endpoint_url.startswith('https'),
        config=Config(signature_version='s3v4')
    )
    def list_with_retry(**params):
        delay = 0.5
        for attempt in range(5):
            try:
                return s3.list_objects_v2(**params)
            except Exception:
                if attempt == 4:
                    raise
                time.sleep(delay)
                delay *= 2
        return {}
    batch_ids = []
    token = None
    while True:
        params = dict(Bucket=bucket, Prefix="batch_", Delimiter='/', MaxKeys=1000)
        if token:
            params['ContinuationToken'] = token
        resp = list_with_retry(**params)
        for cp in resp.get('CommonPrefixes', []):
            p = cp.get('Prefix', '')
            # esperado 'batch_001/' → extrair 001
            try:
                num = p.strip('/').split('_', 1)[1]
                if num.isdigit():
                    batch_ids.append(str(int(num)))
            except Exception:
                pass
        if resp.get('IsTruncated'):
            token = resp.get('NextContinuationToken')
        else:
            break
    # único e ordenado
    batch_ids = sorted(set(batch_ids), key=lambda x: int(x))
    return batch_ids

def derive_tag_from_key(key: str) -> str:
    return key.replace('.parquet', '').replace('/', '_')

def ch_counts_for_tags(db: str, table: str, tags: list[str]) -> dict:
    if not tags:
        return {}
    counts: dict[str, int] = {}
    # fatiar em blocos para evitar URLs gigantes; usar POST no corpo
    def chunked(seq, n):
        for i in range(0, len(seq), n):
            yield seq[i:i+n]
    for chunk in chunked(tags, 300):
        esc = [t.replace("'", "''") for t in chunk]
        in_list = ",".join([f"'{t}'" for t in esc])
        sql = f"SELECT data_tag, count() FROM {db}.{table} WHERE data_tag IN ({in_list}) GROUP BY data_tag"
        url = f"http://{CH_HOST}:{CH_PORT}/?user={CH_USER}&password={CH_PASS}"
        req = urlrequest.Request(url, data=sql.encode('utf-8'), method="POST")
        req.add_header("Content-Type", "text/plain; charset=utf-8")
        with urlrequest.urlopen(req) as resp:
            body = resp.read().decode('utf-8', errors='ignore').strip()
        if body:
            for line in body.splitlines():
                parts = line.split('\t')
                if len(parts) == 2:
                    try:
                        counts[parts[0]] = int(parts[1])
                    except Exception:
                        pass
    return counts

try:
    # Prompt selecao de batches e amostragem
    sel = input("Batches? 'all', lista ex: 1,2,3 ou vazio p/ usar MINIO_TEST_FILE_PATH: ").strip().lower()
    pct_str = input("Informe a porcentagem de amostragem (ex.: 1, 10, 20, 30). Deixe em branco para 100%: ").strip()
    if pct_str == "":
        fraction = 1.0
    else:
        val = float(pct_str.replace('%', '').replace(',', '.'))
        if val <= 0 or val > 100:
            raise ValueError("Porcentagem invalida. Use 0 < p <= 100")
        fraction = val / 100.0

    spark = SparkSession.builder \
        .appName("SKZ_ETL_Load_Pipeline") \
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.367") \
        .config("spark.hadoop.fs.s3a.endpoint", MINIO_HOST_PORT) \
        .config("spark.hadoop.fs.s3a.access.key", MINIO_KEY) \
        .config("spark.hadoop.fs.s3a.secret.key", MINIO_SECRET) \
        .config("spark.hadoop.fs.s3a.aws.credentials.provider", "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider") \
        .config("spark.hadoop.fs.s3a.path.style.access", "true") \
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
        .config("spark.hadoop.fs.s3a.connection.timeout", "60000") \
        .config("spark.hadoop.fs.s3a.connection.establish.timeout", "5000") \
        .config("spark.hadoop.fs.s3a.idle.connection.timeout", "300000") \
        .config("spark.hadoop.fs.s3a.threads.keepalivetime", "60000") \
        .config("spark.hadoop.fs.s3a.threads.shutdown.timeout", "60000") \
        .config("spark.hadoop.fs.s3a.multipart.purge", "true") \
        .config("spark.hadoop.fs.s3a.multipart.purge.age", "86400000") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .getOrCreate()

    # Decide scope: single file or multi-batch
    if sel == "":
        # Single file from .env (legacy mode)
        keys = [FILE_PATH]
    else:
        if sel == "all":
            print("[INFO] Discovering batches with prefix scan (batch_*/)...")
            batch_ids = discover_batch_ids(BUCKET_NAME, MINIO_URL, MINIO_KEY, MINIO_SECRET)
            print(f"[INFO] Found {len(batch_ids)} batches. First 10: {batch_ids[:10]}")
        else:
            batch_ids = [x.strip() for x in sel.split(',') if x.strip()]
        keys = list_parquet_keys_for_batches(BUCKET_NAME, MINIO_URL, MINIO_KEY, MINIO_SECRET, batch_ids)
        if not keys:
            print("[WARN] No parquet keys found for selected batches.")
            keys = []

    # Pre-check existing loads
    tags = [derive_tag_from_key(k) for k in keys]
    existing = ch_counts_for_tags(CH_DB, CH_TABLE, tags) if tags else {}

    total_files = len(keys)
    print("\x1b[36m===== PLAN SUMMARY =====\x1b[0m")
    print(f"[PLAN] files={total_files} | target_db={CH_DB} | target_table={CH_TABLE}")
    if existing:
        loaded_cnt = sum(existing.values())
        done_files = sum(1 for t in tags if t in existing and existing[t] > 0)
        print(f"[PLAN] already loaded: files={done_files}/{total_files}, rows_loaded≈{loaded_cnt:,}")

    # Iterate files
    for idx, key in enumerate(keys, start=1):
        data_tag = derive_tag_from_key(key)
        if existing.get(data_tag, 0) > 0:
            print(f"\x1b[33m[SKIP]\x1b[0m {idx}/{total_files} {data_tag} already has rows in {CH_DB}.{CH_TABLE}")
            continue

        s3_path = f"s3a://{BUCKET_NAME}/{key}"
        print(f"\x1b[36m===== FILE {idx}/{total_files} =====\x1b[0m")
        print(f"[EXTRACT] {s3_path}")
        raw_df = spark.read.parquet(s3_path)

        if fraction < 1.0:
            print("\x1b[36m===== EXTRACT → SAMPLE =====\x1b[0m")
            print(f"[INFO] Sampling {fraction*100:.1f}% of rows")
            raw_df = raw_df.sample(withReplacement=False, fraction=fraction, seed=42)

        print("\x1b[36m===== TRANSFORM =====\x1b[0m")
        all_columns = raw_df.columns
        transformed_df = raw_df \
            .withColumn("datavalue_json", F.to_json(F.struct(*all_columns))) \
            .withColumn("data_tag", F.lit(data_tag)) \
            .withColumn("timestamp", F.current_timestamp()) \
            .select("timestamp", "data_tag", "datavalue_json")

        print("\x1b[36m===== PLAN & STATS =====\x1b[0m")
        total_rows = transformed_df.count()
        print(f"[STATS] data_tag={data_tag} | total_rows={total_rows:,}")

        print("\x1b[36m===== LOAD (HTTP batches) =====\x1b[0m")
        batch = []
        batch_size = 1000
        processed = 0
        start_ts = time.time()

        def print_progress(stage: str, processed_rows: int, total: int):
            elapsed = time.time() - start_ts
            rate = processed_rows / elapsed if elapsed > 0 else 0.0
            remaining = (total - processed_rows) / rate if rate > 0 else float('inf')
            pct = (processed_rows / total * 100.0) if total > 0 else 0.0
            def fmt(t):
                if not math.isfinite(t) or t < 0:
                    return "--:--:--"
                m, s = divmod(int(t), 60)
                h, m = divmod(m, 60)
                return f"{h:02d}:{m:02d}:{s:02d}"
            bar_w = 30
            filled = int(bar_w * pct / 100.0)
            bar = "#" * filled + "-" * (bar_w - filled)
            msg = (f"\r\x1b[32m[{stage}]\x1b[0m data_tag={data_tag} | "
                   f"{processed_rows:,}/{total:,} ({pct:5.1f}%) | "
                   f"[{bar}] | elapsed {fmt(elapsed)} / eta {fmt(remaining)} ")
            print(msg, end='', flush=True)

        for row in transformed_df.toLocalIterator():
            ts = row['timestamp']
            try:
                ts = ts.replace(microsecond=0)
            except Exception:
                pass
            batch.append((ts, row['data_tag'], row['datavalue_json']))
            if len(batch) >= batch_size:
                try:
                    http_insert_tsv(batch)
                except Exception:
                    http_insert_values(batch)
                processed += len(batch)
                batch.clear()
                print_progress('LOAD', processed, total_rows)
        if batch:
            try:
                http_insert_tsv(batch)
            except Exception:
                http_insert_values(batch)
            processed += len(batch)
            print_progress('LOAD', processed, total_rows)
        print()  # end line
        print("\x1b[32m[SUCESSO]\x1b[0m Load finished in {0:.1f}s".format(time.time()-start_ts))

    print("\x1b[36m===== DONE (ALL FILES) =====\x1b[0m")

except Exception as e:
    print("\n[FALHA] Erro durante o processo de Load Pipeline (E+T+L).")
    print(f"Erro: {e}")

finally:
    if 'spark' in locals():
        spark.stop()
        print("Sessão Spark finalizada.")


