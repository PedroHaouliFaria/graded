import os
import sys

print("--- FORÇANDO E VALIDANDO O AMBIENTE JAVA ANTES DO SPARK ---")

# 1. Definir o caminho do JAVA_HOME na marra
# (Usando o caminho que achamos no seu print)
# (Use \\ (duas barras) para caminhos no Windows dentro do Python)
java_path = 'C:\\Program Files\\Microsoft\\jdk-17.0.11.9-hotspot'

# 2. Forçar as variáveis de ambiente SÓ PARA ESTE NOTEBOOK
os.environ['JAVA_HOME'] = java_path
os.environ['Path'] = os.environ.get('Path', '') + ';' + java_path + '\\bin'

# 3. Validar se o Python agora enxerga (o que você pediu)
print(f"\nVALIDAÇÃO (Script em Py):")
print(f"JAVA_HOME (forçado): {os.environ.get('JAVA_HOME')}")
print(f"Java no Path (forçado): {java_path}\\bin")

# 4. Checa o executável do Python (só para garantir)
print(f"Executável Python: {sys.executable}")

print("\n--- AMBIENTE FORÇADO. Tente rodar a Célula 2 (SparkSession) AGORA. ---")