# Data Cube — G01 (Sprint 3)

Arquivos e documentação do Automated Data Cube integrado ao ClickHouse.

Estrutura:
- `spreadsheets/` — templates CSV das dimensões (camada de exploração).
- Ver DDL em `memory_banks/17_SPRINT3_DATACUBE_SQL.md` e requisitos em `memory_banks/14_SPRINT3_DATACUBE_REQUIREMENTS.md`.





