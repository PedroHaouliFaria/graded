import os
import sys
import platform

print("--- INICIANDO SCRIPT DE VALIDAÇÃO DE AMBIENTE SPARK (Windows) ---")
print("="*60)
print(f"Plataforma: {platform.system()} {platform.release()}")

# --- CHECK 1: Versão do Python ---
print("\n[CHECK 1: VERSÃO DO PYTHON]")
py_version = sys.version
print(f"Versão detectada: {py_version.split()[0]}")

if "3.12" in py_version:
    print(">>> FALHA, PORRA: Você está rodando com Python 3.12. O PySpark 3.5 NÃO é compatível.")
    print("    PARE AGORA. Ative o venv 3.9.7 (.\.venv-spark-3.9\Scripts\Activate.ps1) e rode este script DE NOVO.")
elif "3.9" in py_version:
    print(">>> SUCESSO: Python 3.9 detectado. Correto.")
else:
    print(f">>> ATENÇÃO: Versão de Python não verificada: {py_version.split()[0]}")
print(f"    Caminho do executável: {sys.executable}")

# --- CHECK 2: JAVA_HOME ---
print("\n[CHECK 2: VARIÁVEL JAVA_HOME]")
# Caminho que configuramos no PowerShell
java_home_esperado = 'C:\\Program Files\\Microsoft\\jdk-17.0.11.9-hotspot'
os.environ['JAVA_HOME'] = java_home_esperado # Força a variável, como fizemos na Célula 1

java_home_env = os.environ.get('JAVA_HOME')
if not java_home_env:
    print(">>> FALHA, PORRA: A variável de ambiente JAVA_HOME NÃO está definida.")
else:
    print(f">>> SUCESSO: JAVA_HOME (forçado): {java_home_env}")

# --- CHECK 3: Validação do Caminho JAVA_HOME ---
print("\n[CHECK 3: VALIDAÇÃO DO CAMINHO JAVA_HOME]")
if java_home_env and os.path.exists(java_home_env):
    print(">>> SUCESSO: O caminho do JAVA_HOME existe no sistema.")
    java_exe = os.path.join(java_home_env, 'bin', 'java.exe')
    if os.path.exists(java_exe):
        print(f">>> SUCESSO: java.exe encontrado em: {java_exe}")
    else:
        print(f">>> FALHA, PORRA: A pasta JAVA_HOME existe, mas 'bin\java.exe' NÃO foi encontrado dentro dela.")
else:
    print(f">>> FALHA, PORRA: O caminho definido em JAVA_HOME é INVÁLIDO ou não existe: {java_home_env}")

# --- CHECK 4: HADOOP_HOME (winutils) ---
print("\n[CHECK 4: VARIÁVEL HADOOP_HOME (winutils)]")
project_root = os.path.abspath(os.getcwd()) 
hadoop_home_esperado = os.path.join(project_root, 'hadoop')
os.environ['HADOOP_HOME'] = hadoop_home_esperado # Força a variável

hadoop_home_env = os.environ.get('HADOOP_HOME')

if not hadoop_home_env:
    print(">>> FALHA, PORRA: HADOOP_HOME não está no ambiente.")
else:
    print(f">>> SUCESSO: HADOOP_HOME (forçado): {hadoop_home_env}")

# --- CHECK 5: Validação do winutils.exe ---
print("\n[CHECK 5: VALIDAÇÃO DO 'winutils.exe']")
winutils_path = os.path.join(hadoop_home_env, 'bin', 'winutils.exe')
if os.path.exists(winutils_path):
    print(f">>> SUCESSO: winutils.exe encontrado em: {winutils_path}")
else:
    print(f">>> FALHA, PORRA: winutils.exe NÃO foi encontrado no caminho esperado.")
    print(f"    Caminho verificado: {winutils_path}")
    print("    Se falhou, rode o Passo 2 (download) do meu guia anterior.")

# --- CHECK 6: Validação do Path ---
print("\n[CHECK 6: VALIDAÇÃO DO 'Path' DO SISTEMA]")
os.environ['Path'] = os.environ.get('Path', '') + ';' + java_home_env + '\\bin' + ';' + os.path.join(hadoop_home_env, 'bin')
path_var = os.environ.get('Path', '')

if java_home_env and os.path.join(java_home_env, 'bin') in path_var:
    print(">>> SUCESSO: JAVA_HOME\\bin está no Path.")
else:
    print(">>> FALHA: JAVA_HOME\\bin NÃO está no Path.")
    
if hadoop_home_env and os.path.join(hadoop_home_env, 'bin') in path_var:
    print(">>> SUCESSO: HADOOP_HOME\\bin está no Path.")
else:
    print(">>> FALHA: HADOOP_HOME\\bin NÃO está no Path.")
    
print("\n" + "="*60)
print("--- VALIDAÇÃO CONCLUÍDA. Cole este log inteiro no chat. ---")