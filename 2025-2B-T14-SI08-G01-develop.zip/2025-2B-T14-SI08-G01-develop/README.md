# 2025-2B-T14-SI08-G01

# Inteli - Instituto de Tecnologia e Liderança 

<p align="center">
<a href= "https://www.inteli.edu.br/"><img src="https://www.inteli.edu.br/wp-content/uploads/2024/06/logo-inteli-3-768x420-1.png" alt="Inteli - Instituto de Tecnologia e Liderança" border="0" width="200"></a>
</p>

# Big Data Integration, Management and Analysis 

## Empresa: SKZ Oberle 

<p align="center">
<a href= "https://skzoberle.com/"><img src="https://skzoberle.vagas.solides.com.br/_next/image?url=https%3A%2F%2Fc5gwmsmjx1.execute-api.us-east-1.amazonaws.com%2Fprod%2Fdados_processo_seletivo%2Flogo_empresa%2F109134%2FLogotipo%2C%20nome%20da%20empresa__Descri%C3%A7%C3%A3o%20gerada%20automaticamente.png&w=828&q=100" alt="SKZOberle" border="0" width="200"></a>
</p>
  
## Group Name: The Boys

<p align="center">
<img src="./assets/theBoys.png" alt="Logo do Grupo" border="0" width="150">
</p>

## Integrantes:

<div align="center">
<table>
  <tr>
    <td align="center">
      <a href="https://www.linkedin.com/in/bernardofmeirelles/">
        <img src="https://media.licdn.com/dms/image/v2/D4D03AQF7RjThbvvV0g/profile-displayphoto-shrink_200_200/B4DZcKSdk8IEAY-/0/1748224302536?e=1762992000&v=beta&t=JVIICu13GTijGWmrWKOBR4YESfZbv2aQqfYUi-ARUnw" width="100px;" alt="Foto de Larissa Temoteo" style="border-radius:50%"/>
        <br />
        <b>Bernardo Meirelles   </b>
      </a>
      <br />
      <a href="https://github.com/Bernardomeirelles">
        <img src="https://img.shields.io/badge/GitHub-%23121011.svg?logo=github&logoColor=white)" alt="GitHub" height="25"/>
      </a>
      <a href="https://www.linkedin.com/in/bernardofmeirelles/">
        <img src="https://custom-icon-badges.demolab.com/badge/LinkedIn-0A66C2?logo=linkedin-white&logoColor=fff" alt="LinkedIn" height="25"/>
      </a>
    </td>
    <td align="center">
      <a href="https://www.linkedin.com/in/enzo-barci-a7631b2b4/">
        <img src="https://media.licdn.com/dms/image/v2/D4E03AQErLEB7DSEk6g/profile-displayphoto-scale_200_200/B4EZoCrAAXIoAY-/0/1760981418860?e=1762992000&v=beta&t=36UdBIIDEsL9vRm31hto0mzYH5W_6lEM2a-IBSwJni4" width="100px;" alt="Foto de Lucas Matheus Nunes" style="border-radius:50%"/>
        <br />
        <b>Enzo Salvador</b>
      </a>
      <br />
      <a href="https://github.com/EnzoBarci">
        <img src="https://img.shields.io/badge/GitHub-%23121011.svg?logo=github&logoColor=white)" alt="GitHub" height="25"/>
      </a>
      <a href="https://www.linkedin.com/in/enzo-barci-a7631b2b4/">
        <img src="https://custom-icon-badges.demolab.com/badge/LinkedIn-0A66C2?logo=linkedin-white&logoColor=fff" alt="LinkedIn" height="25"/>
      </a>
    </td>
    <td align="center">
      <a href="https://www.linkedin.com/in/david-deodato/">
        <img src="https://media.licdn.com/dms/image/v2/D4D03AQHf84J-MRhljQ/profile-displayphoto-scale_200_200/B4DZnamel6GsAY-/0/1760309149326?e=1762992000&v=beta&t=6-476WDWTti-8V07jNtUga5U37kcSCJhTe7bJO_yd3A" width="100px;" alt="Foto de Rafael Furtado" style="border-radius:50%"/>
        <br />
        <b>David Deodato</b>
      </a>
      <br />
      <a href="https://github.com/DavidDeodato">
        <img src="https://img.shields.io/badge/GitHub-%23121011.svg?logo=github&logoColor=white)" alt="GitHub" height="25"/>
      </a>
      <a href="https://www.linkedin.com/in/david-deodato/">
        <img src="https://custom-icon-badges.demolab.com/badge/LinkedIn-0A66C2?logo=linkedin-white&logoColor=fff" alt="LinkedIn" height="25"/>
      </a>
    </td>
  </tr>
  <tr>
    <td align="center">
      <a href="https://www.linkedin.com/in/pedro-haouli/">
        <img src="https://media.licdn.com/dms/image/v2/D4E03AQHFjVpi1plFKQ/profile-displayphoto-scale_200_200/B4EZl9e0D4KUAY-/0/1758746855528?e=1762992000&v=beta&t=eH5VPtYqohPU6bWLgoHC9PCkzYwlWdLk_dDc_XoAn68" width="100px;" alt="Foto de Ryan Gartlan" style="border-radius:50%"/>
        <br />
        <b>Pedro El Haouli</b>
      </a>
      <br />
      <a href="https://github.com/PedroHaouliFaria">
        <img src="https://img.shields.io/badge/GitHub-%23121011.svg?logo=github&logoColor=white)" alt="GitHub" height="25"/>
      </a>
      <a href="https://www.linkedin.com/in/pedro-haouli/">
        <img src="https://custom-icon-badges.demolab.com/badge/LinkedIn-0A66C2?logo=linkedin-white&logoColor=fff" alt="LinkedIn" height="25"/>
      </a>
    </td>
    <td align="center">
      <a href="https://www.linkedin.com/in/matheusfgs/">
        <img src="https://media.licdn.com/dms/image/v2/D4D03AQH7KR71O0bbmw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1709852826506?e=1762992000&v=beta&t=CXjcSJgyD0LtRSpKYfoQkIfYV9ujzombS2qZOjuyZ80" width="100px;" alt="Foto de Tainá Cortez" style="border-radius:50%"/>
        <br />
        <b>Matheus Fernandes</b>
      </a>
      <br />
      <a href="https://github.com/matheusfrn">
        <img src="https://img.shields.io/badge/GitHub-%23121011.svg?logo=github&logoColor=white)" alt="GitHub" height="25"/>
      </a>
      <a href="https://www.linkedin.com/in/matheusfgs/">
        <img src="https://custom-icon-badges.demolab.com/badge/LinkedIn-0A66C2?logo=linkedin-white&logoColor=fff" alt="LinkedIn" height="25"/>
      </a>
    </td>
    <td align="center">
      <a href="https://www.linkedin.com/in/sachakefif/">
        <img src="https://media.licdn.com/dms/image/v2/D4E03AQGDBeV05gXVfA/profile-displayphoto-scale_200_200/B4EZiZduJnHIAY-/0/1754921364494?e=1762992000&v=beta&t=cIWFqwVgaqMAevSDHUfLKVN5VfnjP64RhDkci51XzGY" width="100px;" alt="Foto de Thiago Gomes" style="border-radius:50%"/>
        <br />
        <b>Sacha Kefif</b>
      </a>
      <br />
      <a href="https://github.com/Sacharme">
        <img src="https://img.shields.io/badge/GitHub-%23121011.svg?logo=github&logoColor=white)" alt="GitHub" height="25"/>
      </a>
      <a href="https://www.linkedin.com/in/sachakefif/">
        <img src="https://custom-icon-badges.demolab.com/badge/LinkedIn-0A66C2?logo=linkedin-white&logoColor=fff" alt="LinkedIn" height="25"/>
      </a>
    </td>
  </tr>
</table>
</div>

## 📜 Descrição

&emsp;This MVP presents a Big Data pipeline developed to centralize and process operational and administrative data from SKZ Oberle. The project applies the ETL (Extract, Transform, and Load) process, in which data was extracted, transformed, and cleaned to ensure quality and consistency.

&emsp;From the processed data, analytical visualizations were created and displayed through a front-end interface. These visualizations enable the extraction of strategic insights, supporting operational optimization and data-driven decision-making within SKZ Oberle.

## 📁 Estrutura de pastas

&emsp; The repository's organization follows a modular structure, designed to facilitate the development, maintenance, and understanding of the project as a whole 

```

```

## ⚙️ Requirements

To participate in this module, you will need:

* A computer with internet access.
* Specific software and tools mentioned in the module instructions.

## 🛠 Instalation

## 👨‍🏫 Module Content

Sprint 1: Business Understanding; User Understanding; Exploratory Data Analysis.

Sprint 2: Low-fidelity prototyping of the project's data visualization, focusing on user experience; Data Ingestion Structure.

Sprint 3: Automated Data Cube; Ethical Impact Analysis Documentation.

Sprint 4: Creation of an infographic and an analysis report on its effectiveness with improvement suggestions; DataAPP – First Version; Project Financial Analysis and Communication Plan.

Sprint 5: Complete solution documentation; DataAPP – Refined Final Version; Final Evaluation and Module Closure.

## 🗃 Release History

0.1.0 – 24/10/2025
First delivery: Business Understanding, Exploratory Data Analysis, and UX Understanding.

0.2.0 – 07/11/2025
Second delivery: Low-Fidelity Wireframes, Data Ingestion.

0.3.0 - 19/11/2025
Third delivery: Ethical Impact Analysis Documentation, Automated Data Cube.

0.4.0 – 05/12/2025
Fourth delivery: DataAPP – First Version, Infographic Creation, Financial Analysis, and Communication Plan.

1.0.0 – 19/12/2025
Fifth delivery: Final Version of the DataAPP and Complete Documentation.

## 📋 Licença/License

<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/cc.svg?ref=chooser-v1"><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/by.svg?ref=chooser-v1"><p xmlns:cc="http://creativecommons.org/ns#" xmlns:dct="http://purl.org/dc/terms/"><a property="dct:title" rel="cc:attributionURL" href="https://github.com/Inteli-College/2025-1A-T14-SI05-G01">The boys</a> _by_ <a rel="cc:attributionURL dct:creator" property="cc:attributionName" href="https://www.inteli.edu.br/">Inteli, <a href="https://github.com/Bernardomeirelles">Bernardo Meirelles</a>, <a href="https://github.com/EnzoBarci">Enzo Salvador</a>, <a href="https://github.com/DavidDeodato">David Deodato</a>, <a href="https://github.com/https://github.com/matheusfrn">Matheus Fernandes</a>, <a href="https://github.com/PedroHaouliFaria">Pedro el Haouli</a></a> and <a href="https://github.com/https://github.com/Sacharme">Sacha Kefif</a></a> _is_ _licensed_ _under_ <a href="http://creativecommons.org/licenses/by/4.0/?ref=chooser-v1" target="_blank" rel="license noopener noreferrer" style="display:inline-block;">Attribution 4.0 International</a>.</p>
