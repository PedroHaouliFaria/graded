 # Big Data Integration, Management and Analysis - Module 8 (2025) - Inteli 

## Group 1
Bernardo Meirelles, David Deodato, Enzo Barci, Matheus Fernandes, Pedro Faria and Sacha Kefif


## Summary

[1. Market and Risk Analysis Workbook](#market-and-risk-analysis-workbook)  
- [1.1. Value Proposition Canvas](#11-value-proposition-canvas)  
- [1.2. Value Proposition](#12-value-proposition)  
 • [1.2.1. Products & Services](#121-products--services)  
 • [1.2.2. Gain Creators](#122-gain-creators)  
 • [1.2.3. Pain Relievers](#123-pain-relievers)  
- [1.3. Customer Segment](#13-customer-segment)  
 • [1.3.1. Customer Jobs](#131-customer-jobs)  
 • [1.3.2. Gains](#132-gains)  
 • [1.3.3. Pains](#133-pains)  
- [1.4. Market Sizing](#14-market-sizing)  
 • [1.4.1. TAM (Total Addressable Market)](#141-tam-total-addressable-market)  
 • [1.4.2. SAM (Service Addressable Market)](#142-sam-service-addressable-market)  
 • [1.4.3. SOM (Service Obtainable Market)](#143-som-service-obtainable-market)  
- [1.5. Risk Matrix](#15-risk-matrix)  
 • [Action Plan for Risks and Opportunities](#action-plan-for-risks-and-opportunities)

[2. Data Narrative Oriented to the DMC](#data-narrative-oriented-to-the-dmc)  
- [2.1. Persona](#21-persona)  
- [2.2. Data Storytelling](#22-data-storytelling)  
 • [2.2.1. The "Before" Journey: The Current Scenario at SKZ](#221-the-before-journey-the-current-scenario-at-skz)  
 • [2.2.2. The "After" Journey: The Future with the Big Data Platform](#222-the-after-journey-the-future-with-the-big-data-platform)

[3. Data Discovery with Data Model Canvas](#data-discovery-with-data-model-canvas)  
- [3.1. Data Sources and Structure](#31-data-sources-and-structure)  
- [3.2. Data Analysis (Spark)](#32-data-analysis-spark)  
- [Appendix A: Source Data Dictionary](#appendix-a-source-data-dictionary)

[4. Pipeline ETL (Extract, Transform and Launch)](#pipeline-etl-extract-transform-and-launch)  
- [4.1. Extract](#41-extract)  
- [4.2. Transform](#42-transform)  
- [4.3. Load](#43-load)
- [4.4. C4 Diagram](#44-c4-diagram)
- [4.5. Sequence Diagram](#45-sequence-diagram)
- [4.6. Dynamic Flowchart](#46-dynamic-flowchart)

[5. Strategic Data Analysis & Visualization](#5-strategic-data-analysis--visualization) 
- [5.1. Chart: Monthly Sales Evolution](#51-chart-monthly-sales-evolution)  
- [5.2. Chart: Top 10 Clients by Sales](#52-chart-top-10-clients-by-sales)  
- [5.3. Chart: Monthly Purchases Evolution](#53-chart-monthly-purchases-evolution)  
- [5.4. Chart: Purchase Tax Load (Net vs. ICMS vs. IPI)](#54-chart-purchase-tax-load-net-vs-icms-vs-ipi)  
- [5.5. Chart: Company Salary Distribution](#55-chart-company-salary-distribution)  
- [5.6. Chart: Employee Role Distribution](#56-chart-employee-role-distribution)
- [5.7. Conclusion](#57-conclusion)


[6. Data Cube and Spreadsheet](#6-data-cube-and-spreadsheet)
- [6.1. Data Cube Explanation](#61-data-cube-explanation)
- [6.1.1. What is a Data Cube](#611-what-is-a-data-cube)
- [6.1.2. How a Data Cube Works (Dimensions, Measures, Hierarchies)](#612-how-a-data-cube-works-dimensions-measures-hierarchies)
- [6.1.3. Why Data Cubes Matter in Analytics (OLAP Context)](#613-why-data-cubes-matter-in-analytics-olap-context)
- [6.1.4. Advantages and Limitations](#614-advantages-and-limitations)
- [6.1.5. Cube Overview (visual)](#615-cube-overview-visual)
- [6.2. Data Cube Applied to SKZ Oberle](#62-data-cube-applied-to-skz-oberle)
- [6.2.1. Dimensions Defined for SKZ Oberle](#621-dimensions-defined-for-skz-oberle)
- [6.2.2. Measures Relevant to SKZ Oberle](#622-measures-relevant-to-skz-oberle)
- [6.2.3. Example Cube Structure (From the Data Lake Inputs)](#623-example-cube-structure-from-the-data-lake-inputs)
- [6.2.4. Interpretation of the Cube for Business Decisions](#624-interpretation-of-the-cube-for-business-decisions)
- [6.2.5. Conclusion: Strategic Value for SKZ Oberle](#625-conclusion-strategic-value-for-skz-oberle)
- [6.3. Star Schema](#63-star-schema)
- [6.3.1. What is a Star Schema](#631-what-is-a-star-schema)
- [6.3.2. Components (Fact Table + Dimension Tables)](#632-components-fact-table--dimension-tables)
- [6.3.3. Difference Between Star and Snowflake Schemas](#633-difference-between-star-and-snowflake-schemas)
- [6.3.4. Benefits of Using a Star Schema](#634-benefits-of-using-a-star-schema)
- [6.3.5. Star Schema Applied to SKZ Oberle](#635-star-schema-applied-to-skz-oberle)
- [6.3.6. Conclusion: Why Star Schema Supports OLAP & Cube Analysis](#636-conclusion-why-star-schema-supports-olap--cube-analysis)
- [6.4. Spreadsheet (Spritesheets for Dimensions)](#64-spreadsheet-spritesheets-for-dimensions)
- [6.4.1. Purpose of the Spreadsheet in the Project](#641-purpose-of-the-spreadsheet-in-the-project)
- [6.4.2. Structure and Organization of the File](#642-structure-and-organization-of-the-file)
- [6.4.3. How the Spreadsheet Integrates with the Data Cube](#643-how-the-spreadsheet-integrates-with-the-data-cube)
- [6.4.4. Data Validation, Cleaning and Preparation Steps](#644-data-validation-cleaning-and-preparation-steps)
- [6.4.5. Key Insights Observed in the Spreadsheet](#645-key-insights-observed-in-the-spreadsheet)
- [6.4.6. Conclusion: Impact of the Spreadsheet on the Analytical Workflow](#646-conclusion-impact-of-the-spreadsheet-on-the-analytical-workflow)
- [6.4.7. Fact Spritesheets (QA snapshots)](#647-fact-spritesheets-qa-snapshots)
- [6.5. Data Mart](#65-data-mart)
- [6.5.1. Principles used in our Data Mart](#651-principles-used-in-our-data-mart)
- [6.5.2. Views published and why they matter](#652-views-published-and-why-they-matter)
- [6.5.3. Deploy and quick checks](#653-deploy-and-quick-checks)
- [6.6. Lineage & Procedures](#66-lineage--procedures)
- [6.7. Performance & Troubleshooting](#67-performance--troubleshooting)
- [6.8. Evidences & Reproducibility](#68-evidences--reproducibility)

# 1. Market and Risk Analysis Workbook

## 1.1. Value Proposition Canvas 

&nbsp;&nbsp;&nbsp;&nbsp;The **Value Proposition Canvas** is a strategic tool used to align customer needs with the products and services offered by a solution, ensuring it directly and effectively addresses market challenges. Structured into two main blocks, the model encompasses the **Customer Profile**, which maps the customer’s jobs, pains, and gains, and the **Value Proposition**, which presents the products, features, and approaches designed to meet those demands.  

&nbsp;&nbsp;&nbsp;&nbsp;**Customer jobs** refer to the activities customers want to accomplish or the problems they need to solve, which may include functional, social, or emotional objectives. **Pains** represent the obstacles that make it difficult to complete those jobs, such as risks, inefficiencies, or dissatisfactions. **Gains**, in turn, are the benefits expected or desired, ranging from practical advantages to improvements in experience or perceived image.  

&nbsp;&nbsp;&nbsp;&nbsp;On the solution side, **products and services** correspond to the tangible elements offered, such as platforms, technologies, or features. **Pain relievers** are mechanisms that alleviate or eliminate the previously identified pains, while **gain creators** are the resources that generate or enhance the desired benefits. Each of these components should be designed in a connected way so that the value proposition fully meets the real expectations of the target audience.

<div align="center">
  <sub>Figure 1 - Market Sizing </sub><br>
  <img src="../assets/CanvaSKZ.png" alt="Diagrama RM-ODP" style="width: 70%;"><br>
  <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <sup>Source: Material produced by the authors (2025).</sup>
</div>

&nbsp;&nbsp;&nbsp;&nbsp;The **SKZ Oberle Data Foundation Project** establishes a structured environment for the integration, storage, and governance of financial, accounting, and tax data.  
Its goal is to consolidate corporate information into a single, secure, and auditable data architecture that supports analytics and compliance.


## 1.2. Value Proposition

### 1.2.1. Products & Services
- Data pipeline integrating financial, accounting, and tax information.  
- Data Lake with traceability and controlled access, deployed in a containerized environment.

### 1.2.2. Gain Creators
- Architecture prepared for data-based automation and analytical systems.  
- Consistent data access through APIs and direct query endpoints.

### 1.2.3. Pain Relievers
- Unification of systems and spreadsheets through automated integrations.  
- Continuous monitoring and validation of data quality and standards.


## 1.3. Customer Segment

### 1.3.1. Customer Jobs
- Centralize accounting, tax, and financial data in a single environment.  
- Ensure compliance, traceability, and governance in data operations.

### 1.3.2. Gains
- Information ready for real-time decision-making.  
- Reduction of redundant manual processes and data rework.

### 1.3.3. Pains
- Fragmented and inconsistent data across systems.  
- Operational inefficiencies due to manual data handling.



## 1.2. Market Sizing

&emsp;A clear understanding of market size is essential for defining growth strategies, prioritizing target segments, and evaluating the potential impact of a solution. Market sizing provides a quantitative foundation for strategic decisions, investment planning, and go-to-market initiatives.

&emsp;In this analysis, we aim to assess the overall market opportunity, identify the specific segments that align with the company’s capabilities, and estimate the realistic share that can be captured in the short and medium term.

To structure this process, we break the market sizing down into three key layers:

* TAM (Total Addressable Market): Represents the total revenue opportunity if the solution reached 100% market share, without constraints.

* SAM (Service Addressable Market): Focuses on the portion of the market that is realistically targetable, considering geographic, demographic, and strategic factors.

* SOM (Service Obtainable Market): Estimates the share of the market that can be effectively captured, based on operational capacity, competitive landscape, and market positioning.

&emsp;This layered approach allows us to move from a broad view of the market potential to a focused and actionable opportunity, ensuring that growth expectations are both ambitious and achievable.

### 1.2.1. TAM (Total Adressable Market)

&emsp;For SKZ Oberle, the Total Addressable Market represents the maximum revenue opportunity for its core services including accounting, tax and fiscal advisory, financial BPO, corporate structuring, and international business support within the Brazilian market. The company operates in a space characterized by regulatory complexity, high compliance demand, and a strong reliance on specialized service providers, especially among medium and large enterprises.

&emsp;To estimate this potential, we focused on companies that are most likely to require structured corporate and financial support. According to SEBRAE and IBGE data, there are around 1.5 million medium and large businesses in Brazil that fall within SKZ Oberle’s target profile. These organizations typically outsource financial, accounting, and tax functions or hire specialized firms to ensure compliance and operational efficiency.

&emsp;Based on market benchmarks, we used an average annual contract value of R$ 30,000 per client, which reflects typical fees for ongoing accounting and corporate advisory services in Brazil.

**TAM = 1, 500, 00 x R$30, 000 ≈ R$45, 000, 000, 000**

**TAM = R$ 45 billion per  year**

&emsp;This number represents the upper limit of the company’s addressable market, assuming 100% market coverage with no operational or competitive constraints. It establishes a solid foundation for the next stages SAM and SOM which will refine this potential based on geographic focus, strategic positioning, and realistic capacity to capture market share.

### 1.2.2. SAM (Service Adressable Market)

&emsp;While the TAM provides a broad view of SKZ Oberle’s total potential market, the Service Addressable Market (SAM) focuses on the portion of that market the company can realistically target based on its current positioning, strategic priorities, and operational reach. This means narrowing the total universe of companies to those that SKZ Oberle can effectively serve in the near to mid term.

&emsp;In this case, we considered that SKZ Oberle’s current operations and commercial focus are primarily concentrated in Brazil’s key economic regions mainly São Paulo, Rio de Janeiro, Minas Gerais, and Paraná — where a large share of medium and large companies is located. According to IBGE data, these states together represent approximately 45% of all medium and large enterprises in the country.

&emsp;In addition to geography, SKZ Oberle’s service portfolio is better aligned with companies that operate in high-complexity sectors such as finance, technology, manufacturing, logistics, and international trade which are more likely to demand ongoing tax, accounting, and corporate structuring support. When segmenting by both location and sector, the addressable base is reduced from the total of 1.5 million companies to around 675,000 potential clients.

&emsp;Keeping the same average annual contract value of R$ 30,000 per client, the SAM can be estimated as:

**SAM = 675, 000 x R$30, 000 ≈ R$20, 250, 000, 000**

**SAM = R$ 20.25 billion per  year**

&emsp;This value reflects a more realistic and strategically focused opportunity, aligning SKZ Oberle’s market potential with its current operational footprint and commercial strategy, while still representing a significant growth horizon. It also sets the stage for the SOM analysis, where we’ll narrow down the market to the portion SKZ Oberle caan actually capture in the short to medium term.

## 1.2.3. SOM (Service Obtainable Market)

&emsp;After defining the TAM and SAM, the Service Obtainable Market (SOM) focuses on the portion of the market that SKZ Oberle can realistically capture, considering its current operational capacity, competitive environment, and go-to-market strategy. This step moves from strategic opportunity to tangible business potential over the short and medium term.

&emsp;Although SKZ Oberle serves a large and economically relevant segment, it is still one player in a highly competitive market. In Brazil, the accounting and corporate services sector includes both traditional firms and technology-driven players, which means capturing the entire SAM is not feasible. For a realistic scenario, we estimated an initial achievable market penetration of 3% over the target segment. This percentage reflects a conservative but strategic growth plan for a company with established expertise and reputation but still expanding its operational base.

&emsp;Applying this 3% capture rate to the SAM of approximately R$ 20.25 billion yields:

**SOM = R$20, 250, 000, 000 x 0,03 ≈ R$607, 500, 000**

**SOM = R$ 607.5 million per  year**

&emsp;This result represents the realistic annual revenue opportunity for SKZ Oberle under its current positioning and expected market penetration in its priority regions and sectors. It provides a clear and measurable target, which can be adjusted upward as the company expands its capacity, differentiates its service offerings, or increases its presence in new markets.

### Conclusion from TAM SAM SOM

In conclusion, the market sizing analysis provides a clear view of the scale and strategic potential of SKZ Oberle’s business. With a TAM of R$ 45 billion, the company operates in a market with significant growth opportunities. By focusing on key economic regions and high-complexity sectors, the SAM narrows to R$ 20.25 billion, reflecting a more realistic addressable opportunity. Finally, the SOM of R$ 607.5 million represents the achievable market share SKZ Oberle can realistically capture in the short to medium term based on its current positioning. This structured estimation serves as a strategic foundation for growth planning, guiding commercial strategies, expansion priorities, and investment decisions.

<div align="center">
  <sub>Figure X - Market Sizing </sub><br>
  <img src="../assets/marketSizing.png" alt="Market Sizing" style="width: 100%;"><br>
  <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <sup>Source: Material produced by the authors (2025).</sup>
</div>

## 1.3. Risk Matrix

&ensp;  The Risk and Opportunity Matrix is a fundamental tool for a Big Data project, as it seeks to foresee problems and identify points for improvement that could directly impact data quality, technological infrastructure, and the achievement of analytical objectives. The goal is to ensure that, during and after implementation, the solution operates with data security, integrity, and compliance, while maintaining processing performance and leveraging Big Data capabilities to extract insights that bring strategic value and competitive advantage to the organization.

<div align="center">
  <sub>Figure X - Risk Matrix </sub><br>
  <img src="../assets/riskMatrix.jpg" alt="Risk and Opportunities Matrix" style="width: 100%;"><br>
  <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <sup>Source: Material produced by the authors (2025).</sup>
</div>

&ensp; The mapped opportunities show that the Big Data project can go beyond simple data collection and storage, transforming into an engine of strategic and business intelligence. Predictive and prescriptive analytics, real-time data processing, and visualization in advanced dashboards (Business Intelligence) enable the identification of market trends, the personalization of the customer experience, and the optimization of operational efficiency (e.g., Logistics, Manufacturing). The adoption of these improvements strengthens SKZ Oberle's data-driven decision-making process and increases its ability to respond agilely and proactively to market challenges and opportunities.

### Action Plan for Risks and Opportunities

&ensp;Aiming for faster decision-making and a better interpretation of the risk matrix, the group developed an action plan for each risk and opportunity in the matrix, along with its justification, as seen below:

## Threats (Risks)

#### A. Technical failures and bugs
- *Strategy*: Mitigate
- *Action*: **Implement mandatory, continuous unit and end-to-end testing. Enforce peer code reviews.**
- *Justification*: To ensure application stability and data pipeline integrity, minimizing downtime and development disruption.
- *Responsible*: Product Owner and all the team members.
- *Probability*: 5 (Very High)
- *Impact*: 5 (Very High)

#### B. Slower progression due to difficulty with the English language
- *Strategy*: Mitigate
- *Action*: **Study english and practice**
- *Justification*: To reduce ambiguity, improve team confidence in the language, and ensure high-quality, standardized deliverables.
- *Responsible*: All team members.
- *Probability*: 5 (Very High)
- *Impact*: 4 (High)

#### C. Communication among group members and lack of alignment on problems
- *Strategy*: Mitigate
- *Action*: **Make the daily meetings (15 min) focused on obstacles.**
- *Justification*: To ensure swift problem identification and resolution, keeping all six team members aligned on priorities and constraints.
- *Responsible*: Scrum Master and all team members.
- *Probability*: 4 (High)
- *Impact*: 4 (High)

#### D. Unforeseen in the personal lives of the group members
- *Strategy*: Plan
- *Action*: **Plan the activity distribution with the team**
- *Justification*: To ensure business continuity and prevent single points of failure, safeguarding the project timeline against individual availability issues.
- *Responsible*: All team members.
- *Probability*: 3 (Medium)
- *Impact*: 5 (Very High)

#### E. Incompatibility or limitation of the dockerized environment
- *Strategy*: Mitigate
- *Action*: **Conduct a minimal viability test of the container platform (Docker) during the first setup. Review resource allocation limits.**
- *Justification*: To confirm the environment can support basic Big Data workloads before complex implementation begins.
- *Responsible*: Product Owner
- *Probability*: 2 (Low)
- *Impact*: 5 (Very High)

#### F. Possible data leak
- *Strategy*: Mitigate
- *Action*: **Do not attach the files in LLM's prompts.**
- *Justification*: To comply with data privacy regulations (LGPD) and protect the project's and partner's reputation.
- *Responsible*: Product Owner and all the team members.
- *Probability*: 3 (Medium)
- *Impact*: 4 (High)

#### G. High cost of continuous storage and monitoring and observability
- *Strategy*: Mitigate
- *Action*: **Talk with Inteli and the partner.**
- *Justification*: To ensure project financial viability and avoid unexpected overruns.
- *Responsible*: Product Owner and all the team members.
- *Probability*: 4 (High)
- *Impact*: 2 (Low)

#### H. Lack of continuous monitoring and observability
- *Strategy*: Mitigate
- *Action*: **Define essential logs and metrics.**
- *Justification*: To ensure proactive detection of issues and minimize the mean time to repair.
- *Responsible*: Scrum Master and all the team members.
- *Probability*: 3 (Medium)
- *Impact*: 2 (Low)

#### I. Integration/Restoration limiting the MVP's potential
- *Strategy*: Mitigate
- *Action*: **Execute a data restoration test and integration.**
- *Justification*: To validate critical functional requirements, ensuring the MVP delivers reliable results.
- *Responsible*: Product Owner and all the team members.
- *Probability*: 2 (Low)
- *Impact*: 3 (Medium)

#### J. Inadequate choice of tools and strategies for the pipeline
- *Strategy*: Mitigate
- *Action*: **Hold a formal Architecture Review session with the entire team.**
- *Justification*: To validate the technology stack before implementation, reducing long-term technical debt.
- *Responsible*: Product Owner and all the team members.
- *Probability*: 2 (Low)
- *Impact*: 4 (High)

#### K. Idea not appealing to the partner
- *Strategy*: Mitigate
- *Action*: **Maintain continuous engagement with the partner via weekly demos/feedback sessions, focusing on validating the business value of key deliverables.**
- *Justification*: To ensure continuous alignment between the team and the partner's business strategy, maximizing acceptance.
- *Responsible*: Product Owner and all the team members.
- *Probability*: 1 (Very Low)
- *Impact*: 5 (Very High)

# 2. Data Narrative Oriented to the DMC

## 2.1. Persona

#### Our persona
A persona is a user archetype that represents a typical end user of a product or service. It is a semi-fictional profile grounded in research and data, developed to humanize and contextualize design decisions.

In this project, the persona of <b>Mariana Silva</b>, an Operations Analyst at SKZ, was carefully crafted to embody the characteristics, challenges, and expectations of our target users within the operational management domain. Her persona functions as a strategic design tool that ensures the system we build directly responds to user needs rather than abstract assumptions or purely technical requirements.

#### Profile
Each section of the persona serves a specific purpose. The <b>Profile</b> defines the demographic and professional context, such as education, occupation, and years of experience, which situates Mariana within a realistic work environment. This foundational information helps the design and development teams visualize the level of expertise, decision-making authority, and technical proficiency that the end user likely possesses.

#### Goals
The <b>Goals</b> represent the tangible outcomes Mariana aims to achieve through the system. In Mariana’s case, goals such as optimizing daily tasks, improving data management, and enhancing interdepartmental communication reflect both her personal success metrics and the organizational priorities of SKZ. These goals guide the prioritization of functionalities and shape how success is measured from a user perspective.

#### Motivations
The <b>Motivations</b> section captures the underlying drivers that influence Mariana’s engagement with technology. Understanding motivations informs how users emotionally and cognitively connect with a system. Mariana values clarity, consistency, and efficiency, basically traits that suggest she is inclined toward tools that simplify processes and provide autonomy. By mapping these intrinsic motivators, designers can create interfaces and workflows that reinforce positive user experiences and long-term adoption.

#### Frustrations
The <b>Frustrations</b> highlight the main pain points that currently hinder Mariana’s productivity or satisfaction. Identifying frustrations helps prevent the repetition of past design failures. For example, her issues with disconnected tools, data inconsistencies, and poorly designed interfaces indicate where usability improvements are most needed.

#### Scenario
The <b>Scenario</b> situates the persona in a narrative context, describing how she interacts with the system in her everyday workflow. This scenario bridges the gap between static data and practical application. It helps us to anticipate real usage conditions, such as when Mariana accesses the platform, what tasks she performs, and what challenges she encounters, so that we can design workflows that integrate naturally into her professional routine. The scenario also helps in defining test cases for usability evaluations, ensuring that prototypes and final solutions are validated against realistic behaviors.

#### Personality
Finally, the <b>Personality</b> traits offer additional insight into how Mariana approaches problem-solving, communication, and decision-making. Her inclination toward introversion, thinking, judging, and intuition indicates a structured yet analytical mindset, suggesting that she appreciates well-organized interfaces, logical feedback, and precise data visualization.

#### Why do we build a persona
In essence, constructing Mariana’s persona allows to maintain a user-centered mindset throughout the design and development process. It transforms abstract project requirements into human-centered narratives that guide empathy, communication, and prioritization. By continuously referencing Mariana, we ensure that every system feature contributes to her goals, alleviates her frustrations, and enhances her experience, ultimately aligning the project’s outcomes with genuine user value and organizational impact.</p>

<div align="center">
  <sub>Figure 3 - User Persona </sub><br>
  <img src="../assets/Persona.png" alt="Diagrama RM-ODP" style="width: 70%;"><br>
  <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <sup>Source: Material produced by the authors (2025).</sup>
</div>

## 2.2 Data Storytelling


<p align="justify">&emsp;&emsp; The purpose of this data narrative is to illustrate the tangible impact of our Big Data project on Mariana's routine. It serves as a bridge between the project's technical objectives (such as "establish a robust corporate data platform") and the business objectives (such as "optimize daily tasks"). Below, we demonstrate the "Before" and "After" data flow, aligned with the Data Model Canvas (DMC) blocks.
</p>

### 2.2.1. The "Before" Journey: The Current Scenario at SKZ

<p align="justify">&emsp;&emsp; This scenario, where Mariana needs to create an internal report on the operational efficiency of the Financial BPO clients, reflects the project's central problem: fragmented, inaccessible data that generates manual work.
</p>

- **Collection:** Mariana begins her data search. She accesses the ERP system to extract a billing report. In parallel, she accesses shared spreadsheets on the server to find data on allocated hours. Finally, she must send an email to the IT team requesting an SQL database extraction with client support ticket records.

- **Processing:** Mariana receives the three dataset files and manually consolidates them in a large Excel file. She spends hours cleaning data, correcting inconsistencies, and trying to cross-reference information that doesn't match, which is one of her biggest frustrations.

- **Organization:** The "official data" now resides in an Excel file on Mariana's local machine or in a shared folder. It is disconnected from the original sources and quickly becomes obsolete.

- **Visualization:** She creates pivot tables and charts in Excel for her presentation.

- **Decision-Making:** During the meeting, a director asks, "Can we see this filtered only for clients from Portugal?" Mariana cannot answer on the spot. She needs to go back to her desk, redo the manual process, and send the updated report, perhaps the next day.

- **Business Impact:** The process is slow, inefficient, and prone to errors. SKZ cannot make agile, reliable data-driven decisions, and Mariana spends her time on low-value tasks instead of strategic analysis.

### 2.2.2. The "After" Journey: The Future with the Big Data Platform

<p align="justify">&emsp;&emsp; This scenario, where Mariana needs to create the same operational efficiency report, reflects the proposed solution: a centralized, automated, and auditable data pipeline, following the Medallion Architecture.
</p>

- **Collection / Ingestion (Bronze Layer):** The Big Data pipeline, invisible to Mariana, runs automatically. It ingests raw data from the ERP, spreadsheets, and the SQL database, centralizing them in a Data Lake (the Bronze layer).

- **Processing / Transformation (Silver Layer):** The platform applies predefined business rules. The data is cleaned, standardized, validated, and enriched. Operational data is cross-referenced with financial data, creating a reliable and auditable Silver layer.

- **Organization / Exposure (Gold Layer):** The processed data is aggregated and modeled into specific Data Marts for business areas (the Gold layer). This layer is optimized and ready for consumption.

- **Visualization:** Mariana opens her dashboard (which consumes data from the Gold layer via secure APIs). She sees the efficiency data in real-time.

- **Decision-Making:** Mariana generates the report with one click. During the meeting, the director asks, "Can we see this filtered only for clients from Portugal?" Mariana applies the filter on the dashboard, and the answer appears instantly on the screen. She can access and manage data quickly without needing assistance.

- **Business Impact:** Mariana saves hours of manual work, achieving her goal of optimizing daily tasks. She now uses her time to analyze insights and propose improvements. Communication between departments improves, and SKZ begins to operate in a truly data-driven manner, fulfilling its mission to assist clients with the highest governance standards.

<br>

<p align="justify">&emsp;&emsp; The comparison of the "Before" and "After" journeys validates the project's purpose. The "Before" narrative mirrors the persona's exact frustrations (disconnected tools, data errors, poor interfaces) and the business problem SKZ faces.
</p>

<p align="justify">&emsp;&emsp; The "After" narrative demonstrates how implementing a centralized Big Data pipeline is not just a technical exercise but a direct solution to Mariana's pain points. By automating the collection, processing, and organization of data, the project frees her from manual tasks and allows her to achieve her professional goals, generating real value and driving efficiency and a data-driven culture at SKZ Oberle.
</p>

# 3. Data Discovery with Data Model Canvas

## 3.1 Data Sources and Structure

The foundation of our Big Data project for SKZ Oberle lies in the integration of 13 distinct data sources, currently available in Parquet format in MinIO. These sources cover the main business areas: Accounting (`ct...`), Tax/Inbound and Outbound (`ef...`), Payroll (`fo...`), General Registry (`ge...`), and Assets (`PM...`).

The detailed structure of each file, including columns, inferred data types, and descriptions, is documented in **3.2.1 Source Data Dictionary**.

**Identified Source Files:**

*   **Accounting (Core):**
    *   `ctlancto.parquet`: Main FACT table, containing all accounting entries (debit/credit).
    *   `ctcontas.parquet`: DIMENSION table with the company's chart of accounts.
    *   `ctccusto.parquet`: DIMENSION table with the cost centers.
*   **Tax (Inbound/Outbound):**
    *   `efentradas.parquet`: Inbound invoices.
    *   `efsaidas.parquet`: Outbound invoices.
    *   `efservicos.parquet`: Invoices for services rendered.
    *   `efprodutos.parquet`: Product registry.
    *   `efmvepro.parquet`: Product movements (invoice items).
*   **Payroll:**
    *   `foempregados.parquet`: Employee registry.
    *   `foeventos.parquet`: Payroll events table (e.g., Base Salary, INSS).
    *   `FOMOVTO.parquet`: Payroll movements (entries per employee).
*   **General and Assets:**
    *   `geempre.parquet`: Registry of group companies (branches/CNPJs).
    *   `PMBEM.parquet`: Registry of fixed assets.

**Initial Processing Plan (MVP):**

For the initial delivery (MVP), the focus will be on the accounting core. The plan is:

1.  **Ingestion:** Read the 13 Parquet files from the source (MinIO/`amostras/`).
2.  **Treatment (Core):**
    *   Process and convert date fields (e.g., `ctlancto.data_lan`, `foempregados.admissao`).
    *   Clean and standardize keys (e.g., `conta_debito`, `conta_credito`, `i_ccusto`).
3.  **Structuring (Gold Layer in Neon/Postgres):**
    *   Create a main FACT table in Postgres, joining `ctlancto.parquet` with descriptions from `ctcontas.parquet` (for accounts) and `ctccusto.parquet` (for cost centers).
    *   The goal is to generate an analytical view that can answer: **"How much was spent/received per cost center and by account type (description) over time?"**
    *   The remaining tables (Tax, Payroll) will be loaded into Postgres for enrichment and future analysis.

**High-Level Architecture Diagram (MVP):**

Below is the high-level architecture diagram illustrating the planned data flow for the Minimum Viable Product (MVP):

<div align="center">
  <sub>Figure 2 - MVP Architecture Diagram</sub><br>
  <img src="../src/diagram1.png" alt="MVP Architecture Diagram" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material produced by the authors (2025).</sup>
</div>

**Technical Data Flow Narrative:**

Figure 2 illustrates the core data pipeline designed to transform raw SKZ Oberle data into actionable insights for the MVP. The process unfolds as follows:

1.  **Data Source (MinIO):** The journey begins at the MinIO bucket, acting as the initial data lake holding raw business data structured in Parquet files within batch directories (e.g., `amostras/batches_*/`). This repository serves as the single source of truth for incoming data.

2.  **Processing & Analysis (Spark Notebook):** The Jupyter Notebook (`documentacao e tratamento.ipynb`) orchestrates the core ETL (Extract, Transform, Load) logic using Apache Spark. Spark connects to MinIO (or reads from local samples `../amostras/batch_*` initially), ingests the Parquet files from potentially numerous batch directories efficiently, performs necessary data cleaning (like date conversions), validation, and crucially, executes the required joins (e.g., linking `ctlancto` entries with `ctcontas` and `ctccusto` dimensions) and aggregations to generate business insights (like total value per cost center and account).

3.  **Storage - Gold Layer (Neon/Postgres):** The processed, cleaned, and aggregated data, representing the "Gold" layer ready for consumption in this MVP, is then loaded into a structured format within a Postgres database hosted on Neon. This relational database serves as the analytical endpoint, providing reliable and performant access to the curated data.

4.  **Visualization (React Application):** Finally, the React application (developed and managed separately by David) connects directly to the Neon/Postgres database. It queries the structured "Gold" data to populate visualizations, replicate the final infographic, and potentially offer additional interactive features, delivering the insights derived from the pipeline directly to the end-users.

This flow ensures that raw, potentially complex data from MinIO is systematically processed by Spark and made readily available in a clean, structured format in Postgres, enabling efficient consumption by the front-end application.

## 3.2 Data Analysis (Spark)

As required by Artifact 3, a core data analysis was performed using Apache Spark within the `notebooks/documentacao_e_tratamento.ipynb` notebook. The primary goal was to process the core accounting data (Entries, Accounts, Cost Centers) and derive a meaningful business insight to validate the project's value proposition.

**Process Overview:**

1.  **Environment Setup:** A SparkSession was initialized locally, configured to handle potential Windows environment issues (Java path, Hadoop home/winutils, network binding) and run on Python 3.9.7.
2.  **Data Loading:** The 13 Parquet sample files from the `../amostras/batch_001/` directory were loaded into Spark DataFrames. Schemas were validated against the Data Dictionary (Appendix A).
3.  **Initial Cleaning:** Date columns (e.g., `data_lan`) were identified and converted/renamed to the appropriate `Date` type (e.g., `data_lan_dt`).
4.  **Core Integration (Join):** The cleaned entries DataFrame (`df_ctlancto_limpo`) was joined with the accounts (`df_ctcontas`) and cost centers (`df_ctccusto`) DataFrames using `conta_debito` and `i_ccusto` as keys, respectively. This created a unified analytical DataFrame (`analise_df`) containing transaction details along with descriptive names for accounts and cost centers.
5.  **Aggregation & Insight Generation:** The `analise_df` was grouped by cost center description (`desc_ccusto`) and account description (`desc_conta`), and the transaction `valor` was summed for each group. This produced the primary insight DataFrame (`insight_df`).
6.  **Refinement (Filtering):** Initial results were dominated by non-expense accounts ("Clientes", "Impostos Recuperáveis") when joining on `conta_debito`. Filters were applied based on keywords and specific account exclusion to create `refined_expenses_df`, focusing on potential operational expenses.

**Key Insight:**

The analysis revealed the distribution of expenses across different cost centers and account types. As shown in the refined results and the chart below, "Despesas De Pessoal" (Personnel Expenses) represent a significant portion of the recorded debits across various cost centers like Logistics, Marketing, and Operations.


<div align="center">
  <sub>Figure 3 - Top 20 Expenses by Cost Center & Account</sub><br>
  *(You might need to save the plot from the notebook as an image file, e.g., in `/assets/data_analysis1.png` and adjust the path below)*
  <img src="../assets/data_analysis1.png" alt="Top Expenses Chart" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Analysis performed in `documentacao_e_tratamento.ipynb`.</sup>
</div>

This insight, derived directly from the partner's data using Spark, confirms the feasibility

### 3.2.1 Source Data Dictionary

This section details the inferred structure of the 13 source Parquet files.

#### 3.2.1.1 ctccusto.parquet (Cost Centers)
Dimension table containing the cost center registry.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `i_ccusto` | Integer | Cost Center ID (Primary Key) |
| `descricao` | Text | Cost Center Name/Description |
| `tipo` | Text | Cost Center Type (e.g., OPERATIONAL) |

---


#### 3.2.1.2 ctcontas.parquet (Chart of Accounts)
Dimension table containing the accounting chart of accounts.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `conta_contabil` | Text (Key) | Account Code (Primary Key) |
| `descricao` | Text | Account Name/Description |
| `natureza` | Text | Account Nature (e.g., A = Asset) |
| `nivel` | Integer | Hierarchical level of the account in the chart |

---

#### 3.2.1.3 ctlancto.parquet (Accounting Entries)
Main FACT table with debit/credit movements.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `nume_lan` | Text (Key) | Entry ID (Primary Key) |
| `data_lan` | Text (Date) | Entry Date (Needs conversion to Date) |
| `valor` | Decimal (Float) | Entry Amount |
| `conta_debito` | Text (Key) | Debited account (FK to ctcontas.conta_contabil) |
| `conta_credito` | Text (Key) | Credited account (FK to ctcontas.conta_contabil) |
| `i_ccusto` | Integer | Cost Center ID (FK to ctccusto.i_ccusto) |
| `historico` | Text | Entry Description/History |
| `origem` | Text | Source module of the entry (e.g., NF_SAIDA) |


#### 3.2.1.4 efentradas.parquet (Inbound Invoices)
FACT table with the headers of inbound invoices.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `codi_ent` | Integer | Entry ID (Primary Key) |
| `codi_for` | Integer | Supplier ID |
| `cfop` | Text | Fiscal Code of Operations and Services (CFOP) |
| `data_ent` | Text (Date) | Entry Date (Needs conversion to Date) |
| `valor_total` | Decimal (Float) | Total invoice value |
| `valor_icms` | Decimal (Float) | ICMS Tax Value |
| `valor_ipi` | Decimal (Float) | IPI Tax Value |
| `chave_nfe` | Text (Key) | Electronic Invoice Key |


#### 3.2.1.5 efmvepro.parquet (Product Movements)
FACT table with invoice items (inventory movement).

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `documento` | Integer | Document ID (FK to efentradas or efsaidas) |
| `tipo_documento` | Text | Type (e.g., SAIDA, ENTRADA) |
| `sequencia` | Integer | Item sequence within the invoice |
| `codi_pdi` | Integer | Product ID (FK to efprodutos.codi_pdi) |
| `quantidade` | Integer | Quantity moved |
| `valor_unitario` | Decimal (Float) | Unit price of the product |
| `valor_total` | Decimal (Float) | Total item value (Qty * Unit Price) |


#### 3.2.1.6 efprodutos.parquet (Product Registry)
DIMENSION table with the product registry.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `codi_pdi` | Integer | Product ID (Primary Key) |
| `desc_pdi` | Text | Product Description |
| `ncm` | Text | Mercosur Common Nomenclature (Fiscal Code) |
| `unid_pdi` | Text | Unit of Measurement (e.g., BOX, UN, KG) |
| `valor_referencia` | Decimal (Float) | Product reference value |
| `aliquota_icms` | Decimal (Float) | Standard ICMS tax rate for the product |


#### 3.2.1.7 efsaidas.parquet (Outbound Invoices)
FACT table with the headers of outbound invoices (sales).

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `codi_sai` | Integer | Outbound ID (Primary Key) |
| `codi_cli` | Integer | Customer ID |
| `cfop` | Text | Fiscal Code of Operations and Services (CFOP) |
| `data_sai` | Text (Date) | Outbound Date (Needs conversion to Date) |
| `valor_total` | Decimal (Float) | Total invoice value |
| `valor_icms` | Decimal (Float) | ICMS Tax Value |
| `valor_ipi` | Decimal (Float) | IPI Tax Value |
| `chave_nfe` | Text (Key) | Electronic Invoice Key |



#### 3.2.1.8 efservicos.parquet (Service Invoices)
FACT table with invoices for services rendered.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `codi_ser` | Integer | Service ID (Primary Key) |
| `codi_cli` | Integer | Customer ID |
| `data_ser` | Text (Date) | Service Date (Needs conversion to Date) |
| `valor_servico` | Decimal (Float) | Total service value |
| `municipio` | Text | Municipality where the service was provided |
| `chave_nfs` | Text (Key) | Service Invoice Key |


#### 3.2.1.9 foempregados.parquet (Employee Registry)
DIMENSION table with employee data.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `i_empregados` | Integer | Employee ID (Primary Key) |
| `nome` | Text | Employee's full name |
| `cpf` | Text (Sensitive) | Employee's CPF (Needs anonymization?) |
| `data_nascimento` | Text (Date) | Date of Birth (Needs conversion to Date) |
| `admissao` | Text (Date) | Hire Date (Needs conversion to Date) |
| `salario` | Decimal (Float) | Employee's base salary |
| `cargo` | Text | Employee's position/role |
| `cidade` | Text | Employee's city |
| `estado` | Text | Employee's state |
| `i_ccusto` | Integer | Cost Center ID (FK to ctccusto.i_ccusto) |


#### 3.2.1.10 foeventos.parquet (Payroll Events)
DIMENSION table with payroll event types (Earnings/Deductions).

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `i_eventos` | Integer | Event ID (Primary Key) |
| `nome_evento` | Text | Event Name (e.g., BASE SALARY, INSS) |
| `tipo` | Text | Type (P = Earning, D = Deduction) |
| `base_inss` | Text (Boolean) | Applies to INSS? (Y/N) |
| `base_fgts` | Text (Boolean) | Applies to FGTS? (Y/N) |
| `base_irrf` | Text (Boolean) | Applies to IRRF? (Y/N) |


#### 3.2.1.11 FOMOVTO.parquet (Payroll Movements)
FACT table with payroll entries per employee.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `i_empregados` | Integer | Employee ID (FK to foempregados.i_empregados) |
| `data` | Text (Date) | Movement Date (Needs conversion to Date) |
| `i_eventos` | Integer | Event ID (FK to foeventos.i_eventos) |
| `valor` | Decimal (Float) | Event value (Positive for Earning, Negative for Deduction) |
| `origem` | Text | Movement source (e.g., PAYROLL) |


#### 3.2.1.12 geempre.parquet (Company Registry)
Main DIMENSION table, with the registry of companies/branches.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company ID (Primary Key) |
| `nome` | Text | Company Name/Legal Name |
| `cnpj` | Text (Sensitive) | Company CNPJ (Needs anonymization?) |
| `uf` | Text | State (UF) of the Company |
| `regime` | Text | Tax Regime (e.g., Simples Nacional) |



#### 3.2.1.13 PMBEM.parquet (Assets - Goods)
DIMENSION table with the registry of fixed assets.

| Column | Inferred Type | Proposed Description |
| :--- | :--- | :--- |
| `codi_emp` | Integer | Company Code (FK to geempre) |
| `i_bem` | Integer | Asset ID (Primary Key) |
| `identificador` | Text | Asset Code/Identifier (e.g., PM-201900001) |
| `descricao` | Text | Asset Description |
| `data_aquisicao` | Text (Date) | Acquisition Date (Needs conversion to Date) |
| `valor_aquisicao` | Decimal (Float) | Purchase value of the asset |
| `vida_util_meses` | Integer | Useful life in months |
| `valor_depreciacao_mensal` | Decimal (Float) | Monthly depreciation value |

# 4. Pipeline ETL (Extract, Transform and Launch)

&emsp;An ETL (Extract, Transform, Load) pipeline is a process that automates the movement and transformation of data from various sources to a destination, typically a database or data warehouse. The ETL pipeline is essential for organizing and preparing data for analysis and reporting, especially in Business Intelligence (BI) and Big Data environments. This process consists of three stages: extracting data from the source, transforming it to adjust the format and enrich the content, and finally loading it into a storage system where the data is used for analysis.  

&emsp;In this case, the ETL pipeline extracts `.parquet` files from an S3 Bucket, transforms them to match the structure of an OLAP table, and finally loads the transformed data into the OLAP table of a data warehouse in Clickhouse.

&emsp;The pipeline runs in a package called etl_bronze, which contains an `__init__.py`. This file is responsible for initializing the pipeline and connecting all three stages.

## 4.1. Extract
&emsp;This step is implemented in the Spark-based extractor located in `scrips/` and connects directly to MinIO (S3-compatible) to read Parquet files without modifying their structure. The extractor loads configuration from the project `.env` and initializes a `SparkSession` with S3A settings to enable secure access to the object store.

- **Environment variables (.env) used**:
  - `MINIO_ENDPOINT_URL` (e.g., `http://localhost:9000`)
  - `MINIO_ACCESS_KEY`
  - `MINIO_SECRET_KEY`
  - `MINIO_BUCKET_NAME`
  - `MINIO_TEST_FILE_PATH` (relative path to the Parquet within the bucket, e.g., `amostras/batch_001/ctlancto.parquet`)

- **Spark/MinIO configuration**:
  - The extractor strips the URL scheme from `MINIO_ENDPOINT_URL` to obtain `host:port` for `spark.hadoop.fs.s3a.endpoint`.
  - Sets `spark.hadoop.fs.s3a.access.key`, `spark.hadoop.fs.s3a.secret.key`, `spark.hadoop.fs.s3a.path.style.access = true` and `spark.hadoop.fs.s3a.impl = org.apache.hadoop.fs.s3a.S3AFileSystem`.

- **Read path**:
  - After configuration, the extractor constructs the full read path in the format: `s3a://{MINIO_BUCKET_NAME}/{MINIO_TEST_FILE_PATH}` The prefix s3a:// tells Spark to use the S3A connector, a specialized interface for reading and writing data from S3-compatible storage systems such as MinIO. This allows Spark to access large Parquet files directly from object storage in a distributed manner.

  - Then, the data is then loaded with: df = spark.read.parquet("s3a://data-lake/amostras/batch_001/ctlancto.parquet")

- **Runtime behavior**:
  - Prints the raw schema and a small sample (`show(5)`) to validate connectivity and data health.
  - No mutation or schema enforcement is performed in Extract; it delivers a raw `DataFrame` for the subsequent Transform step.

- **Example DataFrame sample**:
<table>
  <thead>
    <tr>
      <th>transaction_id</th>
      <th>account_id</th>
      <th>amount</th>
      <th>date</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>1001</td><td>ACC-001</td><td>250.00</td><td>2025-01-05</td><td>credit</td></tr>
    <tr><td>1002</td><td>ACC-002</td><td>-50.00</td><td>2025-01-06</td><td>debit</td></tr>
    <tr><td>1003</td><td>ACC-001</td><td>120.00</td><td>2025-01-07</td><td>credit</td></tr>
    <tr><td>1004</td><td>ACC-003</td><td>-75.00</td><td>2025-01-08</td><td>debit</td></tr>
    <tr><td>1005</td><td>ACC-002</td><td>300.00</td><td>2025-01-09</td><td>credit</td></tr>
  </tbody>
</table>


### 4.1.1. Purpose & Business Foundations
- Role of Extract: establish a reliable, repeatable bridge from the source of truth (MinIO) into the analytical runtime, without mutating records.
- Business value: guarantees that all subsequent insights are anchored on the authoritative files while keeping lineage to the original batch/company/period.

### 4.1.2. Method Overview
- Spark connects to MinIO via S3A (path‑style access, credentials, and explicit endpoint).
- Files are read as‑is (Parquet) and materialized into a DataFrame for schema validation and sampling.

### 4.1.3. Runtime Behavior
- Schema print + small `show(5)` provide fast feedback on connectivity, data health, and column drift.
- No schema enforcement or mutation here; it intentionally feeds the Transform step with the original column set.

### 4.1.4. Governance & Lineage
- The MinIO path is the immutable origin of truth for each batch. Downstream, we encode this in `data_tag` (derived from the path) so every record remains traceable to its source.

### 4.1.5. Troubleshooting (Windows/S3A)
- Hadoop on Windows: ensure `HADOOP_HOME` and `winutils.exe` are available (the scripts set this automatically using the repo’s `hadoop/bin`).
- S3A durations like `60s/24h`: use millisecond configs only (already set in scripts).
- “No FileSystem for scheme s3a”: confirm `hadoop-aws` and AWS SDK bundles are loaded (the scripts pin compatible versions).

### 4.1.6. How to Run
1) Configure `.env` (see variables above).
2) `python scrips/extract_pipeline_test.py`
3) Expect schema + sample; if it fails, see 4.1.5.

## 4.2. Transform
&emsp; The Transform stage reshapes, enriches, and prepares the data for analytical storage. This step is executed with Apache Spark (PySpark) to enable distributed and parallel computation across multiple nodes.

Instead of normalizing data into multiple relational tables, this stage adopts a Schema-on-Read approach. Each record from the Parquet file is converted into a single JSON object, allowing flexible querying without predefined table structures. This design supports evolving schemas and heterogeneous data sources without requiring database migrations.

To ensure traceability and facilitate auditing across different data batches, two metadata columns are added:

timestamp: the time when the batch was processed
data_tag: a label identifying the batch or data source (e.g., batch1_accounts)

After transformation, the dataset typically looks like this:

| timestamp           | data_tag        | datavalue_json                                                                 |
| ------------------- | --------------- | ------------------------------------------------------------------------------ |
| 2025-01-10 10:23:45 | batch1_accounts | {"transaction_id":1001,"account_id":"ACC-001","amount":250.00,"type":"credit"} |
| 2025-01-10 10:23:45 | batch1_accounts | {"transaction_id":1002,"account_id":"ACC-002","amount":-50.00,"type":"debit"}  |
| 2025-01-10 10:23:45 | batch1_accounts | {"transaction_id":1003,"account_id":"ACC-001","amount":120.00,"type":"credit"} |


### 4.2.1. Target Shape (Canonical Schema)
- Output columns: `timestamp` (processing time), `data_tag` (batch/source identifier), `datavalue_json` (full record payload as JSON).
- The Transform preserves the entire source record (no early projection), enabling downstream models to evolve without re‑ingesting files.

### 4.2.2. Business Foundations
- Stability under change: source schemas evolve; keeping the payload intact prevents loss of fields before accounting/tax logic is finalized.
- Traceability: pairing `timestamp` and `data_tag` guarantees we can answer “when did this enter?” and “from which client/period did it come?”.

### 4.2.3. Column Semantics
- `timestamp`: single source of truth for ingestion time; supports audit windows and incremental rebuilds.
- `data_tag`: derived from the MinIO path (slashes → underscores, `.parquet` removed); encodes company/batch/period.
- `datavalue_json`: JSON serialization of `struct(*all_columns)`; schema‑on‑read with ClickHouse JSON functions.

### 4.2.4. Implementation Notes
- Spark functions used:
  - `to_json(struct(*all_columns))` → `datavalue_json`
  - `lit(data_tag)` → `data_tag`
  - `current_timestamp()` → `timestamp`
- Output selection in the canonical order: `timestamp`, `data_tag`, `datavalue_json`.

### 4.2.5. Troubleshooting
- Same S3A considerations from 4.1.5 apply.
- If memory pressure occurs while inspecting wide rows, prefer `show(5, truncate=false)` (already used) and avoid materializing large samples.

### 4.2.6. How to Run
1) Configure `.env` (MinIO settings, bucket, and test file path).
2) `python scrips/extract_transform_json.py`
3) Validate the canonical schema + sample JSON lines.

## 4.3. Load
&emsp; In the Load stage, the transformed data is inserted into ClickHouse, the analytical data warehouse. ClickHouse is optimized for high-performance analytical queries, making it ideal for processing large volumes of JSON data.

The target table in ClickHouse is intentionally simple and universal, containing only three columns:

| Column Name      | Type     | Description                                |
| ---------------- | -------- | ------------------------------------------ |
| `timestamp`      | DateTime | Time when the data was processed           |
| `data_tag`       | String   | Identifier for the batch or data source    |
| `datavalue_json` | String   | JSON representation of the original record |

Example ClickHouse table after loading:
| timestamp           | data_tag        | datavalue_json                                                                 |
| ------------------- | --------------- | ------------------------------------------------------------------------------ |
| 2025-01-10 10:23:45 | batch1_accounts | {"transaction_id":1001,"account_id":"ACC-001","amount":250.00,"type":"credit"} |
| 2025-01-10 10:23:45 | batch1_accounts | {"transaction_id":1002,"account_id":"ACC-002","amount":-50.00,"type":"debit"}  |
| 2025-01-10 10:23:45 | batch1_accounts | {"transaction_id":1003,"account_id":"ACC-001","amount":120.00,"type":"credit"} |

By centralizing data in this format, the pipeline ensures high query performance and easy traceability while maintaining flexibility. Analysts can efficiently query the JSON structure using ClickHouse’s native JSON functions to extract, filter, or aggregate specific fields as needed.

### 4.3.1. Target Table (Schema & Naming)
- Database: `G01_DATABASE` (group‑scoped to avoid collisions)
- Table: `skz_pipeline_data`
- Engine/ordering: `MergeTree() ORDER BY (data_tag, timestamp)` to support range scans by batch and time.

### 4.3.2. Configuration (.env)
- `CLICKHOUSE_HOST`, `CLICKHOUSE_PORT` (HTTP, e.g., `8787`)
- `CLICKHOUSE_USER`, `CLICKHOUSE_PASSWORD`
- `CLICKHOUSE_DATABASE` (e.g., `G01_DATABASE`)
- `CLICKHOUSE_TABLE` (e.g., `skz_pipeline_data`)

### 4.3.3. Insertion Strategy (HTTP)
ClickHouse is accessed over HTTP. We adopted two robust paths for inserts:

- FORMAT TSV (preferred): the SQL command travels in `query=` and the data goes in the request body as TSV (one record per line). This is efficient and resilient to special characters when escaped properly.
- Fallback VALUES: when FORMAT TSV is not accepted by the server route in use, we switch to `INSERT ... VALUES (...)` with URL‑encoded SQL, batching small groups to respect URL limits.

Both modes write the canonical trio of columns (`timestamp`, `data_tag`, `datavalue_json`). Timestamps are normalized to seconds on insert; `data_tag` derives from the MinIO path (`/` replaced by `_` and `.parquet` removed); `datavalue_json` is produced via `to_json(struct(*cols))` in the Transform stage.

### 4.3.4. Runtime Behavior (Load Pipeline)
- The loader asks for a sampling percentage (e.g., `1`, `10`, blank for `100`) and applies it at read time to control the insert volume.
- Data flows E → T → L in a single execution:
  1) Read Parquet from MinIO (`s3a://{bucket}/{path}`)
  2) Build `timestamp`, `data_tag`, `datavalue_json`
  3) Insert into `CLICKHOUSE_DATABASE.CLICKHOUSE_TABLE` over HTTP in batches
- Batching is handled driver‑side to avoid Python worker crashes in Windows environments and to surface clear HTTP errors.

### 4.3.5. Verification (Smoke Tests)
- Row count:
  - `SELECT count() FROM G01_DATABASE.skz_pipeline_data` (should increase after each run)
- Sample rows:
  - `SELECT timestamp, data_tag, substring(datavalue_json, 1, 120) FROM G01_DATABASE.skz_pipeline_data ORDER BY timestamp DESC LIMIT 5`.

### 4.3.6. Operational Tips & Troubleshooting
- HTTP 404 on insert: ensure the `query=` parameter is present when sending SQL; for TSV mode, only the data (not the SQL) goes in the body.
- HTTP 500 on DDL: retry using POST with SQL in the body and `?database=...&user=...&password=...` in the URL.
- Python worker crashes in foreachPartition: avoid executor‑side clients; perform driver‑side batching over HTTP.
- Keep `CLICKHOUSE_INTERFACE` set to `http` wherever applicable; our loader speaks HTTP directly and does not rely on a binary protocol.

### 4.3.7. How to Run (Local)
1) Fill `.env` with ClickHouse variables listed above.
2) Execute: `python scrips/load_pipeline.py` and enter a sampling percentage (e.g., `1`).
3) Validate with the queries shown in 4.3.5 or via DBeaver under `G01_DATABASE › Tabelas › skz_pipeline_data`.

### 4.3.8. Why This Design
- One canonical table keeps the MVP focused and auditable; JSON payload preserves source fidelity without hard coupling to fixed schemas.
- HTTP insert avoids driver compatibility issues and works in constrained environments.
- Ordering by `(data_tag, timestamp)` supports typical operational queries (per batch, per time window) with good locality.

### 4.3.9. Business Foundations — What “Load” Solves
- Mission: turn raw, heterogeneous operational data into one reliable, queryable landing zone that any stakeholder can use immediately (auditors, analysts, partners).
- Constraint: the partner’s files evolve (columns change, new sources appear). A rigid, columnar gold schema at the “load” step would break often and delay work.
- Decision: “Load” is a stabilization boundary. We ingest once, preserve 100% of source content, and guarantee temporal and source traceability. Every downstream artifact (dashboards, fiscal reports, data marts) originates here.

### 4.3.10. Column Design and Rationale
- `timestamp` (processing time):
  - Business: provides evidence of when each record entered the platform; enables audit windows and controlled rollbacks.
  - Operations: supports incremental reloads (reprocess X→Y) and SLA tracking from event to availability.
- `data_tag` (batch/source identifier):
  - Business: answers “from which client/period did this record come?”. Encodes company/batch/period semantics.
  - Operations: acts as a logical partition key. Fast batch‑scoped queries; simplifies selective reprocessing/deletion.
- `datavalue_json` (complete payload):
  - Business: preserves the full record without premature projection; no field is lost before accounting/tax rules are applied.
  - Operations: schema‑on‑read. ClickHouse JSON functions extract keys/measures on demand—no migrations required.

Single‑table landing zone
- Simplifies governance (one monitored/versioned entry‑point), accelerates onboarding of new sources, and avoids a proliferation of technical tables that confuse consumers.
- The canonical format is stable; business rules live downstream (marts/projections) where change cadence is expected.

### 4.3.11. Efficiency, Cost and Scale
- ClickHouse + JSON String:
  - Fast analytical reads with `data_tag`/time filters; JSON functions fetch only needed fields.
  - No DDL churn when sources evolve; lower operational cost during the MVP.
- Batching & sampling:
  - Sampling protects the DW in tests and shortens feedback loops.
  - Sized HTTP batches prevent URL limits and sustain steady throughput.

### 4.3.12. Governance, Audit & Risk
- Lineage: `data_tag` maps directly to the MinIO file/batch; `timestamp` records ingestion time.
- Reproducibility: raw content preserved in JSON enables rebuilding views even after schema evolution.
- Audit: window/batch queries provide evidence for inspections and accounting reconciliations.

### 4.3.13. Limitations & Evolution
- Limitation: JSON as String is not a per‑field optimized storage. For large‑scale reporting, we will project case‑specific columnar marts (e.g., normalized accounting entries) while keeping this table as the official landing zone.
- Next steps: automate projections (views/materialized views) and retention policies by `data_tag`/time.

## 4.4. C4 Diagram

&ensp; A C4 Model, consists of a hierarchical documentation approach that uses multiple levels of zoom to progressively describe software architecture. It starts with a high-level view (Context) and delves into Containers (applications, databases), allowing different audiences, from business stakeholders to developers, to understand the system at the level of detail relevant to them.

<div align="center">
  <sub>Figure X - C4 Diagram</sub><br>
  <img src="../assets/c4Diagramm.jpg" alt="UML Components Diagram" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material produced by the authors (2025)`.</sup>
</div>

## 4.5. Sequence Diagram

&ensp; We also developed a Sequence Diagram, a type of UML behavioral diagram that focuses on the temporal order of interactions between system objects. It illustrates how operations are carried out over time, showing the exact sequence of messages exchanged between participants (such as scripts and databases) to complete a specific process, like the Extract, Transform, and Load (ETL) flow.

<div align="center">
  <sub>Figure X - Sequence Diagram</sub><br>
  <img src="../assets/sequenceDiagramm.jpg" alt="UML Components Diagram" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material produced by the authors (2025)`.</sup>
</div>

### 4.5.1 Possible Positive Scenario

&ensp; This architecture is highly robust, leveraging PySpark across all ETL phases (Extract, Transform, Load) to ensure scalable and distributed data processing of high volumes. The system benefits from flexible schema management by serializing data to JSON strings during transformation and storing them in the analytical ClickHouse Data Warehouse, offering resilience to source schema changes. Furthermore, the use of C4 Models and UML Sequence Diagrams provides exceptional architectural clarity, validating a well-defined, traceable flow where data integrity is guaranteed by metadata enrichment and a clear sequential execution of the pipeline.

### 4.5.2 Possible Negative Scenario

&ensp;  Despite the modern toolset, the pipeline faces significant risks in performance and architectural coupling. The choice to convert Parquet (columnar format) to JSON String is a potential serialization bottleneck, introducing substantial processing overhead during the Transform phase, thus limiting PySpark's maximum throughput. Additionally, the direct connection of the React/JavaScript DataApp to the ClickHouse Data Warehouse exposes the database and creates a concurrency bottleneck between ETL operations and user queries, posing both security risks and scalability concerns that could be mitigated by introducing a dedicated API layer.

## 4.6 Dynamic Flowchart

&ensp; In order to further support the project's development and an architecture capable of encompassing all requirements, the team developed a dynamic flowchart with the purpose of illustrating the application's flow among the tools and components.

<div align="center">
  <sub>Figure X - Flowchart </sub><br>
  <img src="../assets/flowchart1.png" alt="Flowchart" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material produced by the authors (2025)`.</sup>
</div>

# 5. Strategic Data Analysis & Visualization

&emsp;After validating our ETL pipeline (MinIO → Spark → ClickHouse), this section demonstrates the analytical power unlocked by the platform. We present a case study based on a single SKZ Oberle client batch to illustrate the level of Business Intelligence that the platform can now deliver once the data is unified in ClickHouse.

&emsp;This section is organized into multiple subsections, each dedicated to a specific type of visualization. Every chart was selected not only for its clarity and interpretability but also for the valuable business insights it provides to SKZ Oberle. For each visualization, we include:

* A description of what the chart represents and the data it relies on;

* An interpretation explaining why this visualization was chosen and how it supports decision-making;

* A technical justification for our academic supervisor, detailing the design choices and how they align with visualization best practices.

&emsp;All visuals are designed to be persuasive yet ethical, following Professor Julia’s principles, avoiding misleading scales, unnecessary chart types, and visual clutter, ensuring transparency and credibility in the analytical narrative.

&emsp;By consolidating data and applying structured, ethical visualization techniques, SKZ Oberle can transform raw operational information into actionable insights. These visualizations enable the company to identify behavioral patterns, detect inefficiencies, and uncover new business opportunities across clients and markets. Beyond supporting decision-making, this analytical layer strengthens SKZ’s positioning as a data-driven partner, capable of offering predictive, transparent, and high-impact intelligence to its customers. Ultimately, the strategic use of data visualization empowers both internal teams and clients to move from intuition to evidence-based management, fostering innovation and measurable value creation.

## 5.1 Chart: Monthly Sales Evolution
&emsp;This subsection presents the monthly revenue evolution of a sample client company of SKZ Oberle, based on data sourced from the Data Lake built with information provided by potential clients. The objective is to illustrate variations in revenue throughout the analyzed period, enabling the identification of growth and decline trends that support SKZ Oberle’s financial and strategic analyses within its Accounting and Business consulting services.  

![Monthly Sales Evolution](../assets/data_visualization/03_monthly_sales_evolution.png)

**1. Business Insight (The "What")**
This line chart shows the client’s monthly revenue trend. We observe steady growth from January (~R$31M) to a peak in May (~R$41.5M), followed by a noticeable decline in June (~R$37.3M).

**2. Strategic Value (The "Why" for SKZ)**
Cash flow planning depends on anticipating revenue cycles. With this view, SKZ can proactively alert the client about June’s downturn and coordinate actions with purchasing and expense planning to protect working capital.

**3. Design Rationale (The "How" – Justification)**
Time series are best communicated with a line chart; the Y‑axis starts at zero to maintain proportional scale. Axis labels are abbreviated to millions (e.g., “R$ 40.0M”) to reduce cognitive load and visual clutter. A restrained palette prioritizes clarity over decoration.

## 5.2 Chart: Top 10 Clients by Sales
&emsp;This subsection displays the ranking of the top ten client companies by total sales value, derived from the SKZ Oberle Data Lake built with data provided by potential clients. The objective is to highlight the concentration of revenue among key accounts, illustrating dependency risks and identifying which clients represent the largest share of sales within SKZ Oberle’s Accounting and Business consulting analyses.  

![Top 10 Clients](../assets/data_visualization/04_top_10_clients.png)

**1. Business Insight (The "What")**
This ranking reveals revenue concentration. Client “104052” accounts for nearly R$1.0M, significantly above the second place, indicating dependency risk.

**2. Strategic Value (The "Why" for SKZ)**
SKZ can advise on concentration risk and mitigation: diversify acquisition, design retention strategies for the top client, and stress‑test the financial plan against the loss of the top account.

**3. Design Rationale (The "How" – Justification)**
A horizontal bar chart fits long client IDs along the Y‑axis. Bars are sorted descending to enable a quick Pareto read. The X‑axis starts at zero to preserve proportionality, and a sequential blue palette guides attention from higher to lower values without noise.

## 5.3 Chart: Monthly Purchases Evolution
&emsp;This subsection presents the monthly evolution of purchase values for a client company assisted by SKZ Oberle, based on data from the organization’s Data Lake, which consolidates information provided by potential clients. The objective is to demonstrate the fluctuation of purchase costs over time, allowing the identification of spending peaks and reductions that assist SKZ Oberle in analyzing cash flow behavior and optimizing financial planning within its Accounting and Business consulting practices.  

![Monthly Purchases Evolution](../assets/data_visualization/05_monthly_purchases_evolution.png)

**1. Business Insight (The "What")**
This series shows the trend of purchase costs (inbound). There is a trough in February (~R$21.3M) and a peak in May (~R$25.8M), broadly aligned with the sales peak.

**2. Strategic Value (The "Why" for SKZ)**
By pairing this with the sales trend, SKZ can analyze spreads month‑by‑month and advise on working capital and inventory policies, anticipating pressure points before they affect liquidity.

**3. Design Rationale (The "How" – Justification)**
The Y‑axis starts at zero to avoid overstating month‑to‑month variation. A red hue encodes cost/outflow consistently, and the time granularity matches the sales chart to support side‑by‑side reasoning.

## 5.4 Chart: Purchase Tax Load (Net vs. ICMS vs. IPI)
&emsp;This subsection presents the composition of total purchase costs for a client company assisted by SKZ Oberle, dividing values into net amount and tax components (ICMS and IPI). The data comes from the organization’s Data Lake, built from information provided by potential clients. The objective is to show the proportional weight of each tax within the total cost structure, supporting SKZ Oberle’s Accounting and Business consulting practices focused on tax credit recovery, financial efficiency, and strategic cost management.  

![Purchase Tax Load](../assets/data_visualization/06_purchase_tax_load.png)

**1. Business Insight (The "What")**
The total purchase cost is decomposed into net value and taxes. Nearly 11% (9.9% ICMS + 1.0% IPI) of all spending is tax credit exposure.

**2. Strategic Value (The "Why" for SKZ)**
This is SKZ’s core advisory territory: plan and recover credits (ICMS/IPI). Quantifying the tax weight justifies proactive tax planning and demonstrates measurable ROI for the client.

**3. Design Rationale (The "How" – Justification)**
A pie chart was intentionally avoided. A stacked bar communicates the part‑to‑whole relationship with accurate component comparison. Showing percentages (89.1%, 9.9%, 1.0%) emphasizes the question “what is the weight of taxes?” while remaining easy to read.

&emsp;The IPI tax represents only 1% of the total purchase cost, standing in sharp contrast to the higher ICMS share and the dominant net value. This discrepancy arises from the nature of the tax structure: IPI applies selectively to industrialized products, while ICMS is a broader state tax affecting most transactions. Highlighting this imbalance visually helps SKZ Oberle identify where tax burdens concentrate, enabling more strategic procurement and pricing decisions.

## 5.5 Chart: Company Salary Distribution
&emsp;This subsection illustrates the salary distribution of a client company assisted by SKZ Oberle, using data sourced from the organization’s Data Lake composed of information from potential clients. The objective is to analyze payroll concentration and identify salary bands, providing insights that support SKZ Oberle’s Accounting and Business consulting in financial planning, workforce structure assessment, and cost management strategies.  

![Salary Distribution](../assets/data_visualization/09_salary_distribution.png)

**1. Business Insight (The "What")**
The histogram reveals two centers of gravity: a large operational cohort around ~R$2k and an even larger technical/analyst cohort around ~R$5k. The median at ~R$5k is the main takeaway.

**2. Strategic Value (The "Why" for SKZ)**
Understanding pay distribution enables SKZ to project payroll provisions (vacation, 13th salary, social charges) and simulate cost scenarios by role bands, supporting proactive HR financial planning.

**3. Design Rationale (The "How" – Justification)**
A histogram is appropriate for continuous salary data. The vertical reference line highlights the median, turning the graphic into an action‑oriented takeaway. Bin width is tuned for readability, and a neutral palette prevents exaggeration.

## 5.6 Chart: Employee Role Distribution
&emsp;This subsection presents the distribution of employees by role within a client company assisted by SKZ Oberle, using data obtained from the organization’s Data Lake built from potential client information. The objective is to illustrate the internal composition of the workforce across different job functions, enabling SKZ Oberle to analyze payroll structure, identify proportional imbalances, and support strategic recommendations in Accounting and Business consulting.  

![Employee Role Distribution](../assets/data_visualization/10_employee_role_distribution.png)

**1. Business Insight (The "What")**
Headcount is evenly distributed across the seven main roles; the organization is not disproportionately heavy on administration or sales.

**2. Strategic Value (The "Why" for SKZ)**
This structure informs payroll cost analysis by role. If specialists drive most of the cost, SKZ can focus event‑level analysis (e.g., `foeventos.parquet`) on that band for optimization opportunities.

**3. Design Rationale (The "How" – Justification)**
We replaced the previous pie (unsuitable for near‑equal slices) with a horizontal bar chart that enables precise comparisons (e.g., 14.3% vs 14.1%). Sorting and aligned baselines improve rank perception, and labels remain legible without clutter.

&emsp;We applied a higher scale to make subtle variations between roles perceptible without altering their true proportions. Since the distribution among the top roles is relatively uniform, a standard scale would flatten the visual differences, making interpretation harder. By extending the axis range and refining the tick intervals, we preserved proportional accuracy while highlighting relative distinctions in headcount. This choice enhances the analytical readability of the chart, allowing SKZ Oberle to identify small yet potentially meaningful variations in team composition across roles.

## 5.7 Conclusion

&emsp;These six visuals operationalize the platform’s promise: replicable, transparent, and business‑ready insights for any SKZ client. Because the data model and visual patterns are standardized, the same dashboards can be auto‑generated per batch, turning accounting from reactive reporting into proactive advisory.

&emsp;The visualizations were built ethically and transparently, accurately representing the data without visual manipulation. Scales and proportions were kept true, and axes start at zero whenever possible to ensure fair comparisons. All titles, labels, and units are clearly identified to avoid ambiguous interpretations. Additionally, elements such as the median line and percentages were included to enhance understanding without distorting the analysis.

&emsp;A visualization would be unethical if it used truncated scales, colors that evoke emotions or false conclusions, omitted relevant values, or presented data in a way that exaggerated variations or trends. Such practices could lead viewers to incorrect conclusions about distribution, growth, or data composition.

&emsp;The design choices made avoided these practices by maintaining consistent colors and scales, using clear labels, and selecting appropriate chart types for each data category. The focus was on ensuring clarity, objectivity, and accurate interpretation, allowing viewers to understand the information without being influenced by visual bias.

# 6. Data Cube and Spreadsheet 

## 6.1 Data Cube Explanation  

### 6.1.1 What is a Data Cube

A Data Cube is the curated analytical layer modeled with a star schema. It organizes business processes as fact tables (measures at a defined grain) connected to descriptive dimension tables (entities used for slicing/dicing).  
In this project, the cube lives in ClickHouse under `DELIVERABLE_SPRINT_2` and is the authoritative “Gold” layer for analytics.

### 6.1.2 How a Data Cube Works (Dimensions, Measures, Hierarchies) 
A data cube is defined by three core components:

**Dimensions :** These are the categorical "who, what, where, when" attributes of the data. They provide the context for the numbers. In the example above, Time, Geography, and Product are the dimensions.

**Measures :** These are the quantitative, numerical values to analyze. They are the data points contained in the cell, and measured by the dimensions.

**Hierarchies :** This is the logical organization of data within a dimension. Hierarchies are what enable "drilling down" and "rolling up."

Example of a Hierarchy :

The Geography dimension might have a hierarchy:
- Country (Roll-up)
- Region / State
- City (Drill-down)

The Time dimension might have a hierarchy:
- Year
- Quarter
- Month

When the data cube is built, it pre-aggregates (pre-calculates) the measures for all possible combinations of dimensions and hierarchy levels. For instance, it calculates the total sales for "USA," "Q3," and "Electronics" before the question is even asked. When the cube is queried, it simply find this pre-calculated answer, which is why it is so fast.

### 6.1.3 Why Data Cubes Matter in Analytics (OLAP Context)  
Data cubes are the foundational technology behind OLAP (Online Analytical Processing).

The primary goal of OLAP is to enable high-speed, interactive, multidimensional data analysis for business users.

Cubes are essential for this:

**Speed :** Traditional databases (called OLTP, for Transaction Processing) are optimized for writing data (like recording a single sale). They are very slow at complex analytical queries ("Show me the percent change in sales for all products, in all regions, for the last three years"). The pre-aggregated nature of a data cube means these queries are returned in seconds, not hours.

**Enabling OLAP Operations :** The cube's structure is what allows OLAP operations :

- **Slice :** Viewing data for a single element of a dimension (sales for "2024" only).

- **Dice :** Selecting a "sub-cube" by filtering on multiple dimensions (sales between "2020" and "2024" in the "Northeast" and "Est" region for "Electronics").

- **Drill-Down / Roll-Up :** Navigating the dimension hierarchies (starting at "Total 2024 Sales" and drilling down to see sales by quarter, then month, etc).

- **Pivot :** Rotating the dimensions to see a different view of the data (swapping "Products" from the rows to the columns).

In short, data cubes transform raw transactional data into a structure optimized for high-speed business intelligence and reporting.

### 6.1.4 Advantages and Limitations

#### Advantages
**Extreme Speed :** Query performance is obviously the biggest advantage here. Complex analytical queries are exceptionally fast because the answers are pre-calculated.

**Consistent Analysis :** All users query the same pre-defined cube, ensuring that the results are consistent across all reports and dashboards. It acts as a "single source of truth."

**User-Friendly :** The cube's structure is quite intuitive for business users, enabling self-service analytics (slice, dice, drill-down) in tools like Power BI, Tableau, or Excel without needing to write complex SQL.

**Optimized for "Read-Heavy" Workloads :** A data cube is perfect for business intelligence environments, where the vast majority of the activity is reading and analyzing data, rather than writing new data.

#### Limitations
**Rigidity :** Cubes are not flexible. The dimensions, measures, and hierarchies must be defined in advance. If a business user wants to analyze a new dimension that wasn't part of the original cube design, than it's a major effort to add it.

**Processing Time :** The initial build of the cube can be very time-consuming and resource-intensive, often requiring overnight data loads.

**Potential for "Data Explosion" :** A cube with many dimensions, or dimensions with many unique members (e.g., millions of customers), can become astronomically large, because it stores all possible aggregations. The number of individual cells grow exponentially with the number of dimensions

**Not for Real-Time Data :** Because they need to be processed, cubes are almost always based on historical data (even recent, but still historical), so they are not suitable for real-time, up-to-the-second operational analysis.

### 6.1.5 Cube Overview (visual)
High‑level relationship among facts and dimensions:

**Conceptual Visualization:**
In our Star Schema architecture, the data model resembles a star shape with central **Fact Tables** (e.g., `fact_sales`, `fact_services`) surrounded by **Dimension Tables** (e.g., `dim_customer`, `dim_document`).
- **Facts** hold the quantitative metrics (metrics like revenue, quantity) and foreign keys.
- **Dimensions** hold the descriptive attributes (who, what, where, when).
The facts are linked to dimensions via surrogate keys, allowing for efficient joining and querying across different business perspectives.

To make the idea concrete, we can conceptualize the data as a multidimensional structure (often called a Data Cube):

**Multidimensional "Voxel" Concept:**
Imagine a 3D (or N-dimensional) space where each axis corresponds to a business dimension (such as Time, Customer, or Product).
- Each intersection of these coordinates represents a "cell" or "voxel".
- Inside each cell lies the measured value (e.g., total sales amount).
This mental model illustrates how we can "slice and dice" the data: locking one dimension (e.g., filtering for Year=2025) effectively takes a slice of the cube, allowing us to analyze the remaining dimensions (e.g., Sales by Customer) in that context.

<div align="center">
  <sub>Figure — Multidimensional Data Cube Concept</sub><br>
  <img src="../assets/ilustration_datacube.png" alt="Data Cube Concept" style="width: 60%;"><br>
  <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <sup>Source: material produced by the authors (2025).</sup>
  </div>

## 6.2 Data Cube Applied to SKZ Oberle  

### 6.2.1 Dimensions Defined for SKZ Oberle  
Dimensions and keys follow the catalog: [document/22_DATACUBE_STAR_SCHEMA_CATALOG.md](../document/22_DATACUBE_STAR_SCHEMA_CATALOG.md).  
Physical DDL: [scrips/create_datacube.sql](../scrips/create_datacube.sql) (tables `G01_dim_*`).  
Loads/mappings: [scrips/load_dimensions.sql](../scrips/load_dimensions.sql).  
SKs: deterministic hashes of business keys to guarantee stable joins across loads.

- dim_company — Grain `(codi_emp)`, attributes `nome`, `cnpj`, `uf`, `regime`.  
  SK rule: hash of `(codi_emp)`. Used by all facts for multi‑company cuts.
- dim_cost_center — Grain `(codi_emp, i_ccusto)`, attributes `descricao`, `tipo`.  
  SK rule: hash of `(codi_emp, i_ccusto)`. Governs controllership (facts: accounting, payroll).
- dim_account — Grain `(codi_emp, conta_contabil)`, attributes `descricao`, `natureza`, `nivel`.  
  SK rule: hash of `(codi_emp, conta_contabil)`. Enables hierarchical roll‑ups in accounting analyses.
- dim_product — Grain `(codi_emp, codi_pdi)`, attributes `desc_pdi`, `ncm`, `unid_pdi`, `aliquota_icms`.  
  SK rule: hash of `(codi_emp, codi_pdi)`. Backbone for inventory and profitability views.
- dim_customer — Grain `(codi_emp, codi_cli)` (thin).  
  SK rule: hash of `(codi_emp, codi_cli)`. Segmentation in sales.
- dim_supplier — Grain `(codi_emp, codi_for)` (thin).  
  SK rule: hash of `(codi_emp, codi_for)`. Segmentation in purchases.
- dim_document — Grain `(codi_emp, doc_type, doc_id)`, attributes `cfop`, `chave_nfe`, `municipio`.  
  SK rule: hash of `(codi_emp, doc_type, doc_id)`. Links invoices across modules and to inventory lines.
- dim_employee — Grain `(codi_emp, i_empregados)`, attributes HR + `i_ccusto`.  
  SK rule: hash of `(codi_emp, i_empregados)`. Joins payroll with cost centers. 
- dim_payroll_event — Grain `(codi_emp, i_eventos)`, attributes `nome_evento`, `tipo`, flags de base.  
  SK rule: hash of `(codi_emp, i_eventos)`. Standardizes event taxonomy in payroll. 
- dim_date — Grain `date_sk`, attributes derived (`year`, `month`, etc.).  
  Calendar axis shared by all facts and Data Mart views.

### 6.2.2 Measures Relevant to SKZ Oberle  
- Sales/Purchases: `valor_total`, `valor_icms`, `valor_ipi`.  
- Services: `valor_servico`.  
- Inventory movements: `quantidade`, `valor_unitario`, `valor_total`.  
- Accounting entries: `valor` per entry (`nume_lan`) with debit/credit and optional cost center.  
- Payroll: `valor` per (employee, event, date), with cost center attribution.

### 6.2.3 Example Cube Structure (From the Data Lake Inputs)  
Source Parquet files are first landed as JSON rows in `DELIVERABLE_SPRINT_2.G01_pipeline_results` (`timestamp`, `data_tag`, `datavalue_json`).  
Loaders materialize the cube using `JSONExtract*` to parse keys/attributes and compute SKs:
- Dimensions: [scrips/load_dimensions.sql](../scrips/load_dimensions.sql)  
- Facts (basic): [scrips/load_facts_basic.sql](../scrips/load_facts_basic.sql)  
- Facts (advanced): [scrips/load_facts_advanced.sql](../scrips/load_facts_advanced.sql)  
Quality checks: [scrips/qa_checks.sql](../scrips/qa_checks.sql)

### 6.2.4 Interpretation of the Cube for Business Decisions  
Examples: revenue mix and tax exposure by period/customer/CFOP/UF (sales vs purchases); services as a separate line of business; inventory movements and CMV at item level; accounting reconciliations by plan of accounts and cost center; payroll provisions and event‑level analysis per cost center.

### 6.2.5 Conclusion: Strategic Value for SKZ Oberle  
The cube is a governed analytical backbone: repeatable, auditable, and performant. It standardizes metrics and dimensions, enabling self‑service and advisory work with consistent semantics.

## 6.3 Star Schema  

<p align="justify">&emsp;&emsp;In this section, we detail the dimensional modeling methodology chosen for the analytical layer of the SKZ Oberle data project, in accordance with the Medallion Architecture requirements. The Star Schema structure was defined for our data cube database.
</p>

### 6.3.1 What is a Star Schema

The Star Schema is the most fundamental design model for a Data Warehouse. It consists of a central Fact Table, which stores the quantitative metrics of a business process, surrounded by a set of Dimension Tables.

These dimension tables contain the descriptive and contextual attributes related to the event. The name "star" is derived from this structure, with the dimensions "radiating" from the central fact, like the points of a star.

We chose this model for its simplicity and high performance in analytical queries, serving as the foundation for creating Business Intelligence solutions and for SKZ's future AI assistant.

### 6.3.2 Components (Fact Table + Dimension Tables)  

The star model is composed of two types of tables:

**Fact Tables:**

- Purpose: They store the indicators of a business process. This is the data we want to sum, average, or count.

- Characteristics: They are generally "deep" (millions or billions of rows) and "narrow" (few columns).

- Keys: They contain foreign keys that connect to the primary keys of the dimension tables.

**Dimension Tables:**

  - Purpose: They provide the descriptive context for the facts. They answer the questions "who, what, where, when, how, and why."

  - Characteristics: They are "shallow" (fewer rows) and "wide" (many columns/descriptive attributes).

  - Keys: They contain a single primary key, usually an integer surrogate key, which is referenced by the fact table.

### 6.3.3 Difference Between Star and Snowflake Schemas  

The main difference between the Star and Snowflake models is the level of normalization of the dimension tables.

Star Schema (Our Model): It is denormalized. Each dimension is represented by a single table. For example, in G01_dim_company, all company attributes (like nome, cnpj, uf) are in the same table. This creates some data redundancy but results in much faster queries, as it requires fewer join operations.

Snowflake Schema: It is normalized. Dimensions are broken down into smaller tables. For example, the G01_dim_company dimension could be split into dim_company and dim_location, which in turn could link to dim_state. This saves space but makes queries slower and more complex.

We chose the Star Schema to prioritize read performance and analytical simplicity, which are crucial for the project's goal of facilitating data consumption.


### 6.3.4 Benefits of Using a Star Schema  

Adopting the Star Schema as the final (Gold) layer of our data pipeline offers direct benefits to SKZ Oberle:

- Simplicity: The model is intuitive and mirrors how business analysts think.

- Query Performance: With fewer joins and an optimized structure, analytical (OLAP) queries are exponentially faster.

- Ease of Use: the future AI can navigate and aggregate data much more efficiently.

- Agility: It is easy to add new metrics to the fact table or new attributes to the dimensions without breaking the existing structure.


### 6.3.5 Star Schema Applied to SKZ Oberle

To meet the objective of unifying SKZ's accounting, tax, and financial data, our working group (G01) modeled the company's main business processes into six distinct star schemas.

Each schema focuses on a specific business area, allowing for granular analysis of the services SKZ provides to its clients, such as Accounting, Payroll, and Financial BPO.

Below are the conceptual diagrams for each process, with a brief explanation of their purpose.

 #### 1. Fact: Accounting Entries (G01_fact_accounting_entries)

The following schema illustrates the "heart" of the accounting system, the G01_fact_accounting_entries table. 

Each row in this fact table represents a single entry in the general ledger (debit or credit) for an SKZ client. The diagram shows how this fact connects to its main dimensions, enabling multidimensional accounting analysis.

<div align="center">
  <sub>Figure X - </sub><br>
  <img src="../assets/starSchema/fact_accouting_entries.png" alt="Top Expenses Chart" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material made by the group.</sup>
</div>

Schema Explanation:

Business Process: General Accounting.

Main Metric: valor (value) of the entry.

Context (Dimensions): Allows analysis of which G01_dim_company (client) made the entry, when (G01_dim_date), where (G01_dim_cost_center) the value was allocated, and what (G01_dim_account) was debited and credited. Note the dual relationship with G01_dim_account (for account_debit_sk and account_credit_sk).

Business Question Answered: "What is the total value of operating expenses for Company X in the last quarter, grouped by cost center?"

#### 2. Fact: Payroll (G01_fact_payroll)

This diagram details the Payroll process (G01_fact_payroll). Each record in the fact table corresponds to a specific event (earning or deduction) on an employee's payslip for an SKZ client. This is one of the richest schemas, connecting five different dimensions.

<div align="center">
  <sub>Figure X - </sub><br>
  <img src="../assets/starSchema/fact_payroll.png" alt="Top Expenses Chart" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material made by the group.</sup>
</div>


Schema Explanation:

Business Process: Payroll Management (HR/BPO).

Main Metric: valor (value) of the event (e.g., salary, bonus, INSS deduction).

Context (Dimensions): Links the value to the G01_dim_employee (employee), the G01_dim_payroll_event (type of event), the G01_dim_date (date), the G01_dim_company (company/client), and the employee's G01_dim_cost_center.

Business Question Answered: "What is the evolution of the total cost of 'Overtime Hours' for Company Y, divided by cost center, over the last 12 months?"


#### 3. Fact: Sales (G01_fact_sales)

The Sales schema (G01_fact_sales) models the product sales invoices issued by SKZ's clients. The fact table stores the total values and taxes for each invoice, serving as the basis for analyzing revenue and tax obligations.

<div align="center">
  <sub>Figure X - </sub><br>
  <img src="../assets/starSchema/fact_sales.png" alt="Top Expenses Chart" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material made by the group.</sup>
</div>

Schema Explanation:

Business Process: Invoicing and Tax Analysis (Product Sales).

Main Metrics: valor_total, valor_icms, valor_ipi.

Context (Dimensions): Connects the sale to the G01_dim_company (who sold), G01_dim_date (when they sold), G01_dim_customer (to whom they sold), and G01_dim_document (the invoice details).

Business Question Answered: "What is the total revenue and ICMS tax due for Company Z last month, grouped by the customer's state (UF)?"


#### 4. Fact: Services (G01_fact_services)

Similar to the Sales schema, G01_fact_services focuses on service provision invoices. The structure is similar but optimized to capture service-specific metrics and attributes, such as valor_servico and the municipio (city) (via G01_dim_document).


<div align="center">
  <sub>Figure X - </sub><br>
  <img src="../assets/starSchema/fact_services.png" alt="Top Expenses Chart" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material made by the group.</sup>
</div>
Schema Explanation:

Business Process: Invoicing and Tax Analysis (Services).

Main Metric: valor_servico.

Context (Dimensions): G01_dim_company, G01_dim_date, G01_dim_customer, and G01_dim_document (with specific NFS-e data).

Business Question Answered: "What is the total ISS tax withheld on service invoices issued to Customer W in the current year?"

#### 5. Fact: Purchases (G01_fact_purchases)

This schema (G01_fact_purchases) completes the fiscal overview by modeling the incoming/purchase invoices received by SKZ's clients. It is fundamental for Financial BPO (accounts payable) and for calculating tax credits (like ICMS).

<div align="center">
  <sub>Figure X - </sub><br>
  <img src="../assets/starSchema/fact_purchase.png" alt="Top Expenses Chart" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material made by the group.</sup>
</div>

Schema Explanation:

Business Process: Tax Management (Entries) and Accounts Payable (Financial BPO).

Main Metrics: valor_total, valor_icms, valor_ipi.

Context (Dimensions): G01_dim_company (who purchased), G01_dim_date (when they purchased), G01_dim_supplier (from whom they purchased), and G01_dim_document (data from the incoming NF-e).

Business Question Answered: "What is the total purchase value from Supplier K by Company X in the last 6 months, and what is the corresponding ICMS credit?"


#### 6. Fact: Inventory Movements (G01_fact_inventory_movements)

Finally, the G01_fact_inventory_movements schema tracks every product item that enters or leaves the stock. This is a more granular schema where each row is an item within a fiscal document, making it crucial for cost analysis and inventory management.

<div align="center">
  <sub>Figure X - </sub><br>
  <img src="../assets/starSchema/fact_inventory_movements.png" alt="Top Expenses Chart" style="width: 80%;">
  <br><small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <br>
  <sup>Source: Material made by the group.</sup>
</div>

Schema Explanation:

Business Process: Inventory and Cost Control.

Main Metrics: quantidade, valor_unitario, valor_total.

Context (Dimensions): G01_dim_company, G01_dim_product (which item), and G01_dim_document (which invoice generated the movement).

Business Question Answered: "How many units of Product P were sold last month, and what was its total cost of goods sold (COGS)?"

### 6.3.6 Conclusion: Why Star Schema Supports OLAP & Cube Analysis  

The ultimate goal of this modeling is to enable On-Line Analytical Processing (OLAP). OLAP is the ability to query and analyze data multidimensionally, quickly, and interactively. 

The Data Cube is the central concept of OLAP. The Cube's metrics (the numbers filling the cells) come from our fact tables. The Cube's dimensions (the "tabs" that allow filtering and grouping) are our dimension tables (e.g., G01_dim_date, G01_dim_company, G01_dim_product). Therefore, the Star Schema is not just a diagram; it is the relational implementation of an OLAP Cube. 

By building these six star schemas in the Gold Layer of our Medallion Architecture, we have effectively delivered a set of ready-made "Data Cubes" to SKZ Oberle. Now, the company can "slice" sales data by a single month, "dice" it by customer and state, and "drill down" from a year to a specific day, all with extremely high performance.

## 6.4 Spreadsheet (Spritesheets for Dimensions)  

### 6.4.1 Purpose of the Spreadsheet in the Project  
Spritesheets and spreadsheets provide a readable, offline lens to validate the cube’s dimensions (codes, names, hierarchies). They are review artifacts; ClickHouse remains the source of truth.

### 6.4.2 Structure and Organization of the File  
For each dimension we provide:
- PNG spritesheet (visual overview) under `../assets/spritesheets_datacube/`.  
- CSV and XLSX templates under `data_cube/spreadsheets/csv/` and `data_cube/spreadsheets/xlsx/`.  
Headers mirror the corresponding ClickHouse table under `DELIVERABLE_SPRINT_2` (see 6.3).

Dimensions covered:
- `dim_company`: `codi_emp`, `nome`, `cnpj`, `uf`, `regime`.  
  <div align="center">
    <sub>Figure — dim_company spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_company.png" alt="dim_company spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
  </div>  
  
  Files: `data_cube/spreadsheets/csv/dim_company.csv`, `data_cube/spreadsheets/xlsx/dim_company.xlsx`
- `dim_cost_center`: `codi_emp`, `i_ccusto`, `descricao`, `tipo`.  
  <div align="center">
    <sub>Figure — dim_cost_center spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_cost_center.png" alt="dim_cost_center spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
  </div>  

  Files: `data_cube/spreadsheets/csv/dim_cost_center.csv`, `data_cube/spreadsheets/xlsx/dim_cost_center.xlsx`
- `dim_account`: `codi_emp`, `conta_contabil`, `descricao`, `natureza`, `nivel`.  
  <div align="center">
    <sub>Figure — dim_account spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_account.png" alt="dim_account spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
  </div>  

  Files: `data_cube/spreadsheets/csv/dim_account.csv`, `data_cube/spreadsheets/xlsx/dim_account.xlsx`
- `dim_product`: `codi_emp`, `codi_pdi`, `desc_pdi`, `ncm`, `unid_pdi`, `valor_referencia`, `aliquota_icms`.  
  <div align="center">
    <sub>Figure — dim_product spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_product.png" alt="dim_product spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
  </div>  

  Files: `data_cube/spreadsheets/csv/dim_product.csv`, `data_cube/spreadsheets/xlsx/dim_product.xlsx`
- `dim_customer`: `codi_emp`, `codi_cli` (thin).  
  <div align="center">
    <sub>Figure — dim_customer spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_customer.png" alt="dim_customer spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
  </div>  

  Files: `data_cube/spreadsheets/csv/dim_customer.csv`, `data_cube/spreadsheets/xlsx/dim_customer.xlsx`
- `dim_supplier`: `codi_emp`, `codi_for` (thin).  
  <div align="center">
    <sub>Figure — dim_supplier spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_supplier.png" alt="dim_supplier spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
  </div>  

  Files: `data_cube/spreadsheets/csv/dim_supplier.csv`, `data_cube/spreadsheets/xlsx/dim_supplier.xlsx`
- `dim_document`: `codi_emp`, `doc_type`, `doc_id`, `cfop`, `chave_nfe`, `municipio`.  
  <div align="center">
    <sub>Figure — dim_document spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_document.png" alt="dim_document spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
  </div>  

  Files: `data_cube/spreadsheets/csv/dim_document.csv`, `data_cube/spreadsheets/xlsx/dim_document.xlsx`
- `dim_employee`: `codi_emp`, `i_empregados`, `nome`, `cpf`, `data_nascimento`, `admissao`, `salario`, `cargo`, `cidade`, `estado`, `i_ccusto`.  
  <div align="center">
    <sub>Figure — dim_employee spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_employee.png" alt="dim_employee spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  

  Files: `data_cube/spreadsheets/csv/dim_employee.csv`, `data_cube/spreadsheets/xlsx/dim_employee.xlsx`
- `dim_payroll_event`: `codi_emp`, `i_eventos`, `nome_evento`, `tipo`, `base_inss`, `base_fgts`, `base_irrf`.  
  <div align="center">
    <sub>Figure — dim_payroll_event spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_payroll_event.png" alt="dim_payroll_event spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  

  Files: `data_cube/spreadsheets/csv/dim_payroll_event.csv`, `data_cube/spreadsheets/xlsx/dim_payroll_event.xlsx`
- `dim_date`: `date_sk`, `date`, `year`, `quarter`, `month`, `month_name`, `day`, `day_of_week`.  
  <div align="center">
    <sub>Figure — dim_date spritesheet</sub><br>
    <img src="../assets/spritesheets_datacube/dim_date.png" alt="dim_date spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  
    
  Files: `data_cube/spreadsheets/csv/dim_date.csv`, `data_cube/spreadsheets/xlsx/dim_date.xlsx`

Note on fact tables: the assignment’s “spreadsheets” requirement targets dimensions (exploration layer). Fact tables usually aren’t represented as spritesheets. If needed for QA or pedagogy, curated snapshots can be generated from the Data Mart views (see Section 6.5) and exported as PNG/CSV/XLSX.

### 6.4.7 Fact Spritesheets (QA snapshots)
For documentation completeness and QA, we also publish fact spritesheets and CSV/XLSX templates. These are illustrative snapshots; the authoritative data resides in the cube:

- `fact_sales`  
  <div align="center">
    <sub>Figure — fact_sales snapshot</sub><br>
    <img src="../assets/spritesheets_datacube/fact_sales.png" alt="fact_sales spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  

  Files: `data_cube/spreadsheets/facts/csv/fact_sales.csv`, `data_cube/spreadsheets/facts/xlsx/fact_sales.xlsx`

- `fact_purchases`  
  <div align="center">
    <sub>Figure — fact_purchases snapshot</sub><br>
    <img src="../assets/spritesheets_datacube/fact_purchases.png" alt="fact_purchases spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  

  Files: `data_cube/spreadsheets/facts/csv/fact_purchases.csv`, `data_cube/spreadsheets/facts/xlsx/fact_purchases.xlsx`

- `fact_services`  
  <div align="center">
    <sub>Figure — fact_services snapshot</sub><br>
    <img src="../assets/spritesheets_datacube/fact_services.png" alt="fact_services spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  

  Files: `data_cube/spreadsheets/facts/csv/fact_services.csv`, `data_cube/spreadsheets/facts/xlsx/fact_services.xlsx`

- `fact_inventory_movements`  
  <div align="center">
    <sub>Figure — fact_inventory_movements snapshot</sub><br>
    <img src="../assets/spritesheets_datacube/fact_inventory_movements.png" alt="fact_inventory_movements spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  

  Files: `data_cube/spreadsheets/facts/csv/fact_inventory_movements.csv`, `data_cube/spreadsheets/facts/xlsx/fact_inventory_movements.xlsx`

- `fact_accounting_entries`  
  <div align="center">
    <sub>Figure — fact_accounting_entries snapshot</sub><br>
    <img src="../assets/spritesheets_datacube/fact_accounting_entries.png" alt="fact_accounting_entries spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  
    
  Files: `data_cube/spreadsheets/facts/csv/fact_accounting_entries.csv`, `data_cube/spreadsheets/facts/xlsx/fact_accounting_entries.xlsx`

- `fact_payroll`  
  <div align="center">
    <sub>Figure — fact_payroll snapshot</sub><br>
    <img src="../assets/spritesheets_datacube/fact_payroll.png" alt="fact_payroll spritesheet" style="width: 75%;"><br>
    <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
    <sup>Source: material produced by the authors (2025).</sup>
    </div>  

  Files: `data_cube/spreadsheets/facts/csv/fact_payroll.csv`, `data_cube/spreadsheets/facts/xlsx/fact_payroll.xlsx`

### 6.4.3 How the Spreadsheet Integrates with the Data Cube  
Each sheet mirrors its ClickHouse dimension (physical model in [scrips/create_datacube.sql](../scrips/create_datacube.sql)). Values here should match the loaded dimensions after running the loaders ([scrips/load_dimensions.sql](../scrips/load_dimensions.sql)). Stakeholder annotations feed small mapping adjustments (the `JSONExtract*` rules in the loaders).

### 6.4.4 Data Validation, Cleaning and Preparation Steps  
Validation queries live in [scrips/qa_checks.sql](../scrips/qa_checks.sql) (counts per dimension/fact, orphan FKs, daily reconciliations). Discrepancies found in spreadsheets are traced to loaders and corrected at the source mapping level.

### 6.4.5 Key Insights Observed in the Spreadsheet  
Typical checks: duplicated cost centers across companies; suppliers referenced by invoices but missing in `dim_supplier`; inconsistent account levels; employee cost centers not present in `dim_cost_center`.

### 6.4.6 Conclusion: Impact of the Spreadsheet on the Analytical Workflow  
Spritesheets accelerate business validation without compromising governance. They provide a readable lens over an authoritative cube and reduce back‑and‑forth during model review, helping converge to production‑ready dimensional data. 

## 6.5 Data Mart  
The Data Mart is the curated layer that exposes stable, business‑friendly views on top of the cube. It centralizes metric definitions (single source of truth), protects consumers from schema changes in the raw tables, and reduces query complexity for dashboards and analytics.

### 6.5.1 Principles used in our Data Mart
- Stable contracts: views hide physical changes in facts/dimensions while preserving column names and semantics.  
- Clear grains: each view states its level of aggregation (e.g., month x customer).  
- Metric governance: calculations (totals, taxes, rates) are defined once and reused everywhere.  
- Performance: views leverage ClickHouse functions (`toYear`, `toMonth`, grouping keys) and the underlying MergeTree `ORDER BY` for selective scans.

### 6.5.2 Views published and why they matter

1) vw_revenue_by_month_customer  
- Grain: 1 row per `(company, year, month, customer)`  
- Sources: `fact_sales` joined with `dim_company`, `dim_date`, `dim_customer`  
- Measures: `revenue_total`, `tax_icms`, `tax_ipi`  
- Why it exists: tracks revenue seasonality and top‑customer concentration; core KPI for commercial performance.  
- SQL reference: [scrips/datamart_views.sql](../scrips/datamart_views.sql) (section revenue_by_month_customer)
- Example usage:
```sql
SELECT year, month, customer_name, revenue_total
FROM DELIVERABLE_SPRINT_2.vw_revenue_by_month_customer
WHERE codi_emp = 1 AND year = 2024
ORDER BY month, revenue_total DESC
LIMIT 20;
```

2) vw_purchases_tax_load  
- Grain: 1 row per `(company, year, month)`  
- Sources: `fact_purchases` joined with `dim_company`, `dim_date`  
- Measures: `total_purchases`, `total_icms`, `total_ipi`, `effective_tax_load = (icms+ipi)/total`  
- Why it exists: monitors acquisition cost and input‑tax credits by period; supports margin and compliance analysis.  
- SQL reference: [scrips/datamart_views.sql](../scrips/datamart_views.sql) (section purchases_tax_load)
- Example usage:
```sql
SELECT year, month, total_purchases, total_icms, total_ipi,
       if(total_purchases>0,(total_icms+total_ipi)/total_purchases,0) AS effective_tax_load
FROM DELIVERABLE_SPRINT_2.vw_purchases_tax_load
WHERE codi_emp = 1
ORDER BY year, month;
```

3) vw_inventory_by_product  
- Grain: 1 row per `(company, product, year, month)`  
- Sources: `fact_inventory_movements` joined with `dim_product`, `dim_company`, `dim_date`  
- Measures: `qty_moved`, `value_moved`  
- Why it exists: supports stock‑turn analysis and CMV insights; informs procurement and pricing.  
- SQL reference: [scrips/datamart_views.sql](../scrips/datamart_views.sql) (section inventory_by_product)
- Example usage:
```sql
SELECT year, month, codi_pdi, desc_pdi, qty_moved, value_moved
FROM DELIVERABLE_SPRINT_2.vw_inventory_by_product
WHERE codi_emp = 1 AND year = 2024
ORDER BY month, qty_moved DESC
LIMIT 20;
```

4) vw_accounting_by_day_cost_center  
- Grain: 1 row per `(company, date, cost_center)`  
- Sources: `fact_accounting_entries` joined with `dim_company`, `dim_date`, `dim_cost_center`  
- Measures: `total_value`  
- Why it exists: daily financial governance by center of cost; feeds budget variance and allocation reviews.  
- SQL reference: [scrips/datamart_views.sql](../scrips/datamart_views.sql) (section accounting_by_day_cost_center)
- Example usage:
```sql
SELECT date, i_ccusto, total_value
FROM DELIVERABLE_SPRINT_2.vw_accounting_by_day_cost_center
WHERE codi_emp = 1 AND date BETWEEN '2024-01-01' AND '2024-01-31'
ORDER BY date, i_ccusto;
```

5) vw_payroll_by_month_cc_event  
- Grain: 1 row per `(company, year, month, cost_center, payroll_event)`  
- Sources: `fact_payroll` joined with `dim_company`, `dim_date`, `dim_cost_center`, `dim_payroll_event`  
- Measures: `value_total`  
- Why it exists: visibility of personnel costs by period/CC/event; reconciles with accounting and P&L.  
- SQL reference: [scrips/datamart_views.sql](../scrips/datamart_views.sql) (section payroll_by_month_cc_event)
- Example usage:
```sql
SELECT year, month, i_ccusto, nome_evento, value_total
FROM DELIVERABLE_SPRINT_2.vw_payroll_by_month_cc_event
WHERE codi_emp = 1 AND year = 2024
ORDER BY month, i_ccusto, value_total DESC
LIMIT 20;
```

### 6.5.3 Deploy and quick checks
- Deploy file: `scrips/datamart_views.sql` (use `scrips/deploy_clickhouse_sql.ps1`).  
- Smoke tests:
```sql
SELECT 1;
SHOW TABLES FROM DELIVERABLE_SPRINT_2;
SELECT * FROM DELIVERABLE_SPRINT_2.vw_revenue_by_month_customer LIMIT 5;
SELECT * FROM DELIVERABLE_SPRINT_2.vw_purchases_tax_load LIMIT 5;
```

## 6.6 Lineage & Procedures
End‑to‑end lineage and operational steps:

<div align="center">
  <sub>Figure — Data lineage (landing → cube → mart)</sub><br>
  <img src="../assets/lineage_Architecture.png" alt="Lineage" style="width: 75%;"><br>
  <small><a href="https://drive.google.com/drive/folders/1jcuDDA4llEtyT4fIIOmW1gC_Tnhu6PSm?usp=sharing" target="_blank">Backup Image</a></small>
  <sup>Source: material produced by the authors (2025).</sup>
  </div>

**Data Flow Description:**
The data pipeline follows a linear progression from raw ingestion to analytical consumption:
1.  **Source & Landing:** Raw data (JSON/Parquet) is ingested into the Landing Area.
2.  **Staging & Modeling:** Data is loaded into ClickHouse tables, where Surrogate Keys (SKs) are generated via deterministic hashing.
3.  **Star Schema (Cube):** These tables are exposed as Dimensions (`dim_*`) and Facts (`fact_*`), forming the central Data Cube.
4.  **Data Mart:** Specialized views (`vw_*`) aggregate the detailed cube data into business-ready metrics (e.g., Monthly Revenue, Tax Load).
5.  **Consumption:** The application and dashboards query these Data Mart views for high-performance reporting.

**Execution Order (Deployment Guide):**
To rebuild the entire environment from scratch (local or Lab), follow this sequence:

1.  **Landing + DB Setup:**
    - Script: [scrips/landing_create.sql](../scrips/landing_create.sql)
    - *Action:* Creates the database and landing tables.
2.  **Cube DDL (Star Schema Structure):**
    - Script: [scrips/create_datacube.sql](../scrips/create_datacube.sql)
    - *Action:* Defines all Dimension and Fact tables with correct engines and keys.
3.  **Load Dimensions:**
    - Script: [scrips/load_dimensions.sql](../scrips/load_dimensions.sql)
    - *Action:* Populates dimensions (Company, Customer, Product, etc.) and generates SKs.
4.  **Load Facts:**
    - Scripts: [scrips/load_facts_basic.sql](../scrips/load_facts_basic.sql) and [scrips/load_facts_advanced.sql](../scrips/load_facts_advanced.sql)
    - *Action:* Populates transactional tables (Sales, Payroll, Accounting), linking them to dimensions via SKs.
5.  **Publish Data Mart (Business Layer):**
    - Script: [scrips/datamart_views.sql](../scrips/datamart_views.sql)
    - *Action:* Creates the aggregated views used by the frontend.
6.  **Validation & QA:**
    - Script: [scrips/qa_checks.sql](../scrips/qa_checks.sql)
    - *Action:* Verifies row counts, referential integrity, and business rule compliance.

*Helper Tool:* Use [scrips/deploy_clickhouse_sql.ps1](../scrips/deploy_clickhouse_sql.ps1) to execute these SQL files via HTTP if using a remote instance.

## 6.7 Performance & Troubleshooting  
- Performance: filter by `date_sk`/`company_sk` early; leverage MergeTree `ORDER BY` (date/company/document keys); avoid wide selects; paginate.  
- Sampling: for exploratory workloads, sample by period or use views with pre‑aggregations.  
- Optional: materialized views for heavy recurring metrics.  
- Troubleshooting:  
  - 404 Not Found → ensure `?query=` is present in the HTTP URL.  
  - 401/403 → credentials/role; some DDLs require admin.  
  - 500 on long queries → send SQL via POST body; avoid overlong query strings.

## 6.8 Evidences & Reproducibility  
- Existence: `SHOW DATABASES;` and `SHOW TABLES FROM DELIVERABLE_SPRINT_2;`  
- Counts: run `scrips/qa_checks.sql` (dimensions/facts, orphan FKs, reconciliations).  
- Mart preview: `SELECT * FROM DELIVERABLE_SPRINT_2.vw_revenue_by_month_customer LIMIT 5;`  
- Artefacts: spritesheets and diagrams reside under `assets/spritesheets_datacube/` and `assets/star_schema/`.  
- How to re‑generate images: `scrips/render_diagrams.ps1`, `scrips/render_cube_3d.py`, `notebooks/cubo_3d.ipynb`.


# 7.0 Project Budget and Pricing  
Objective: **Present a complete and objective pricing structure**, fully aligned with the artifact (costs, expenses, margin, taxes, and final price justification).

## 7.1 Purpose of the Budget  
Objective: **Explain the role of the budget** within the project — to technically justify the amount charged.  
This section defines *why* costs, expenses, margin, and taxes must be calculated to arrive at a defensible price.

## 7.2 Project Costs  
Objective: **Detail and organize all project costs**, clearly separating direct and indirect components.

### **Table — Costs**
| Cost Type | What It Includes | Why It Matters |
|-----------|------------------|----------------|
| **Direct** | Technical hours, specific licenses, specialized services | Directly impact project execution |
| **Indirect** | Management, infrastructure, shared support | Enable quality delivery and operational stability |

## 7.3 Expenses  
Objective: **List all operational expenses** tied to the project, which must be included in the price formation.

### **Table — Expenses**
| Expense | Purpose |
|---------|---------|
| Administrative | Essential back-office support |
| Communication | Reports and necessary client alignment |
| Operational | Minimum support for execution |

## 7.4 Profit Margin  
Objective: **Define the margin applied** (between 15% and 30%) and explain its role: ensuring financial return and project sustainability.

## 7.5 Taxes  
Objective: **Apply the mandatory 15% tax**, ensuring compliance and transparency in the pricing process.

## 7.6 Final Price Calculation  
Objective: **Present the official formula required by the artifact**, ensuring clarity and traceability of the final price.

\[
\text{Final Price} = (Costs + Expenses) \times (1 + \text{Margin}) \times (1 + 0.15)
\]

### **Table — Calculation Steps**
| Step | Description |
|------|-------------|
| 1 | Sum all costs |
| 2 | Add expenses |
| 3 | Apply margin |
| 4 | Apply taxes |
| **Result** | Final project price |

## 7.7 Budget Conclusion  
Objective: **Close the section showing that the final value is justified**, transparent, and aligned with the required methodology.


# 8.0 Communication Plan  
Objective: **Structure the communication flow** to ensure alignment between the team, client, and management throughout the project.

## 8.1 Objective  
Objective: **Clearly state the purpose of communication**, ensuring consistency, alignment, and predictability during execution.

## 8.2 Stakeholders  
Objective: **Identify all stakeholders and their roles**, making clear who receives what kind of information.

### **Table — Stakeholders**
| Stakeholder | Role |
|-------------|------|
| Internal team | Execution |
| Client | Validation |
| Managers | Monitoring |
| Partners | Technical support, if applicable |

## 8.3 Key Messages  
Objective: **Define the key messages** for each stakeholder group, ensuring clarity and preventing rework.

### **Table — Key Messages**
| Stakeholder | Messages |
|-------------|-----------|
| Team | Tasks, deadlines, dependencies |
| Client | Status, deliverables, risks |
| Managers | Progress and critical points |

## 8.4 Communication Channels  
Objective: **Select and justify the communication channels**, ensuring they fit the project's needs.

### **Table — Channels**
| Channel | Purpose | Frequency |
|---------|----------|-----------|
| Meetings | Status and decision-making | Weekly |
| Reports | Formal documentation | Biweekly |
| Email | Fast alignment | As needed |

## 8.5 Implementation Plan  
Objective: **Explain how the communication plan will be executed** — responsible parties, schedule, templates, and record-keeping.

## 8.6 Measures of Success  
Objective: **Establish measurable indicators** that demonstrate the effectiveness of communication.

### **Table — Indicators**
| Indicator | Metric |
|-----------|--------|
| Understanding | Clarity perceived during interactions |
| Information flow | Timely status updates |
| Alignment | Reduction of rework and misunderstandings |

## 8.7 Feedback and Adjustments  
Objective: **Define how feedback will be collected and used**, ensuring continuous improvement of the communication plan.

## 8.8 Communication Plan Conclusion  
Objective: **Summarize the plan**, highlighting that messages, roles, channels, and indicators were clearly defined according to the artifact.

# 9.0 Final Considerations  
Objective: **Conclude the document**, reinforcing that both the budget and communication plan were developed strictly within the scope demanded by the artifact, with full adherence to the requirements.
