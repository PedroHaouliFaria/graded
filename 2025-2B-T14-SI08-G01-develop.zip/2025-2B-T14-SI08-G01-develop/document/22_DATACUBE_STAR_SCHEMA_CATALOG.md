# DataCube — Star Schema Catalog (G01) 

Source: modeling (file 15), DDL (file 17), and data mapping (`mapeamento_schema_COMPLETO.txt`). All tables reside in the `DELIVERABLE_SPRINT_2` database.

## Conventions
- Prefixes: `G01_dim_*` (dimensions) and `G01_fact_*` (facts).
- Surrogate keys (SK): `*_sk` Int32 columns derived deterministically from business keys.
- `date_sk = YYYYMMDD` (Int32).

## Dimensions

1) `G01_dim_date` (calendar) — grain: 1/day  
Columns: `date_sk (PK)`, `date`, `year`, `quarter`, `month`, `month_name`, `day`, `day_of_week`.

2) `G01_dim_company` (geempre) — grain: 1/company  
BK: `(codi_emp)`  
Columns: `company_sk (PK)`, `codi_emp`, `nome`, `cnpj`, `uf`, `regime`.

3) `G01_dim_cost_center` (ctccusto) — grain: 1/cost_center/company  
BK: `(codi_emp, i_ccusto)`  
Columns: `cost_center_sk (PK)`, `codi_emp`, `i_ccusto`, `descricao`, `tipo`.

4) `G01_dim_account` (ctcontas) — grain: 1/account/company  
BK: `(codi_emp, conta_contabil)`  
Columns: `account_sk (PK)`, `codi_emp`, `conta_contabil`, `descricao`, `natureza`, `nivel`.

5) `G01_dim_product` (efprodutos) — grain: 1/product/company  
BK: `(codi_emp, codi_pdi)`  
Columns: `product_sk (PK)`, `codi_emp`, `codi_pdi`, `desc_pdi`, `ncm`, `unid_pdi`, `valor_referencia`, `aliquota_icms`.

6) `G01_dim_customer` (efsaidas/efservicos — thin) — grain: 1/customer/company  
BK: `(codi_emp, codi_cli)`  
Columns: `customer_sk (PK)`, `codi_emp`, `codi_cli`.

7) `G01_dim_supplier` (efentradas — thin) — grain: 1/supplier/company  
BK: `(codi_emp, codi_for)`  
Columns: `supplier_sk (PK)`, `codi_emp`, `codi_for`.

8) `G01_dim_document` (normalized) — grain: 1/(company,type,doc_id)  
BK: `(codi_emp, doc_type, doc_id)`  
Columns: `document_sk (PK)`, `codi_emp`, `doc_type{SAIDA|ENTRADA|SERVICO}`, `doc_id`, `cfop`, `chave_nfe`, `municipio`.

9) `G01_dim_employee` (foempregados) — grain: 1/employee/company  
BK: `(codi_emp, i_empregados)`  
Columns: `employee_sk (PK)`, `codi_emp`, `i_empregados`, `nome`, `cpf`, `data_nascimento`, `admissao`, `salario`, `cargo`, `cidade`, `estado`, `i_ccusto`.

10) `G01_dim_payroll_event` (foeventos) — grain: 1/event/company  
BK: `(codi_emp, i_eventos)`  
Columns: `event_sk (PK)`, `codi_emp`, `i_eventos`, `nome_evento`, `tipo`, `base_inss`, `base_fgts`, `base_irrf`.

## Facts

A) `G01_fact_sales` (efsaidas) — grain: 1/outbound invoice `(codi_emp, codi_sai)`  
FKs: `company_sk → dim_company`, `date_sk → dim_date`, `customer_sk → dim_customer`, `document_sk → dim_document` (SAIDA).  
Measures: `valor_total`, `valor_icms`, `valor_ipi`.

B) `G01_fact_purchases` (efentradas) — grain: 1/inbound invoice `(codi_emp, codi_ent)`  
FKs: `company_sk → dim_company`, `date_sk → dim_date`, `supplier_sk → dim_supplier`, `document_sk → dim_document` (ENTRADA).  
Measures: `valor_total`, `valor_icms`, `valor_ipi`.

C) `G01_fact_services` (efservicos) — grain: 1/service invoice `(codi_emp, codi_ser)`  
FKs: `company_sk → dim_company`, `date_sk → dim_date`, `customer_sk → dim_customer`, `document_sk → dim_document` (SERVICO).  
Measures: `valor_servico`.

D) `G01_fact_inventory_movements` (efmvepro) — grain: 1/line `(documento, tipo_documento, codi_pdi, sequencia)`  
FKs: `company_sk → dim_company`, `product_sk → dim_product`, `document_sk → dim_document`.  
Measures: `quantidade`, `valor_unitario`, `valor_total`.  
Note: date inferred via linked document (join with invoices).

E) `G01_fact_accounting_entries` (ctlancto) — grain: 1/journal entry `(nume_lan)`  
FKs: `company_sk → dim_company`, `date_sk → dim_date`, `cost_center_sk → dim_cost_center`, `account_debit_sk → dim_account`, `account_credit_sk → dim_account`.  
Measures: `valor`.  
Attributes: `nume_lan`, `origem`.

F) `G01_fact_payroll` (FOMOVTO) — grain: 1/(employee,event,date)  
FKs: `company_sk → dim_company`, `date_sk → dim_date`, `employee_sk → dim_employee`, `event_sk → dim_payroll_event`, `cost_center_sk → dim_cost_center`.  
Measures: `valor`.  
Attribute: `origem`.

## SK Rules (deterministic)
- `company_sk = hash(codi_emp)`  
- `cost_center_sk = hash(codi_emp|i_ccusto)`  
- `account_sk = hash(codi_emp|conta_contabil)`  
- `product_sk = hash(codi_emp|codi_pdi)`  
- `customer_sk = hash(codi_emp|codi_cli)`  
- `supplier_sk = hash(codi_emp|codi_for)`  
- `document_sk = hash(codi_emp|doc_type|doc_id)`  
- `employee_sk = hash(codi_emp|i_empregados)`  
- `event_sk = hash(codi_emp|i_eventos)`  
- `date_sk = YYYYMMDD`

## Sources (landing → cube)
All data is loaded from landing `G01_pipeline_results` using `JSONExtract*`:
`geempre → dim_company`, `ctccusto → dim_cost_center`, `ctcontas → dim_account`, `efprodutos → dim_product`, `efsaidas → fact_sales (+dim_customer, doc=SAIDA)`, `efentradas → fact_purchases (+dim_supplier, doc=ENTRADA)`, `efservicos → fact_services (+dim_customer, doc=SERVICO)`, `efmvepro → fact_inventory_movements (doc via dim_document)`, `foempregados → dim_employee`, `foeventos → dim_payroll_event`, `FOMOVTO → fact_payroll`.


